export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { ensureSchema } = await import("@/db/bootstrap");
    await ensureSchema();
    const { runSeed } = await import("@/db/seed");
    await runSeed();
  }
}
