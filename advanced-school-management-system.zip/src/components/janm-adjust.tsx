"use client";

import { useMemo, useState } from "react";
import { motion } from "motion/react";
import { Check, Clock3, Gem, LoaderCircle, Minus, Plus, Search, TriangleAlert, UserRoundX, X } from "lucide-react";
import { Modal } from "@/components/modal";
import { Avatar } from "@/components/ui";
import { useToast } from "@/components/providers";
import { fa, faNum } from "@/lib/format";
import type { StudentBrief } from "@/lib/types";

export type JanmMode = "increase" | "decrease" | "absence" | "lateness" | "disorder";

const MODES: { key: JanmMode; label: string; desc: string; icon: typeof Plus; cls: string; amount?: number }[] = [
  { key: "increase", label: "افزایش جنم", desc: "پاداش و امتیاز مثبت", icon: Plus, cls: "text-[var(--success)]" },
  { key: "decrease", label: "کاهش جنم", desc: "کسر دستی با دلیل", icon: Minus, cls: "text-[var(--danger)]" },
  { key: "absence", label: "غیبت غیرموجه", desc: "کسر ۱۰ جنم", icon: UserRoundX, cls: "text-[var(--danger)]", amount: -10 },
  { key: "lateness", label: "تأخیر در ورود", desc: "هر ۳ تأخیر = کسر ۵ جنم", icon: Clock3, cls: "text-[var(--gold)]" },
  { key: "disorder", label: "بی‌نظمی", desc: "کسر ۲ جنم", icon: TriangleAlert, cls: "text-[var(--danger)]", amount: -2 },
];

export function JanmAdjustModal({
  open,
  onClose,
  students,
  initialIds,
  onDone,
}: {
  open: boolean;
  onClose: () => void;
  students: StudentBrief[];
  /** اگر پروفایل مشخص باشد، انتخاب‌گر نمایش داده نمی‌شود */
  initialIds?: number[];
  onDone?: () => void;
}) {
  const toast = useToast();
  const [selected, setSelected] = useState<number[]>(initialIds ?? []);
  const [search, setSearch] = useState("");
  const [mode, setMode] = useState<JanmMode>("increase");
  const [amount, setAmount] = useState("1");
  const [reason, setReason] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [lastResult, setLastResult] = useState<string>("");

  const fixed = Boolean(initialIds?.length);

  const pool = useMemo(() => {
    let list = students.filter((s) => s.isApproved && !s.isBlocked);
    if (search.trim()) list = list.filter((s) => s.fullName.includes(search.trim()));
    return list.slice(0, 60);
  }, [students, search]);

  const selectedStudents = students.filter((s) => selected.includes(s.id));

  function toggle(id: number) {
    setSelected((sel) => (sel.includes(id) ? sel.filter((x) => x !== id) : [...sel, id]));
  }

  async function submit() {
    if (loading) return;
    if (!selected.length) {
      toast.push("error", "حداقل یک دانش‌آموز انتخاب کنید.");
      return;
    }
    const amt = Number(amount);
    if ((mode === "increase" || mode === "decrease") && (!Number.isInteger(amt) || amt < 1)) {
      toast.push("error", "میزان جنم معتبر نیست.");
      return;
    }
    setLoading(true);
    setLastResult("");
    try {
      const res = await fetch("/api/janm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userIds: selected,
          mode,
          amount: mode === "increase" || mode === "decrease" ? amt : undefined,
          reason: reason || undefined,
          note: note || undefined,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) {
        toast.push("error", data?.error ?? "ثبت انجام نشد.");
        return;
      }
      const results = data.data.results as { penaltyApplied?: boolean }[];
      const penaltyCount = results.filter((r) => r.penaltyApplied).length;
      let msg =
        mode === "lateness"
          ? `تأخیر برای ${fa(results.length)} دانش‌آموز ثبت شد.`
          : `تغییر جنم برای ${fa(results.length)} دانش‌آموز ثبت شد.`;
      if (penaltyCount > 0) msg += ` برای ${fa(penaltyCount)} نفر، جریمه سه تأخیر (۵- جنم) نیز اعمال شد.`;
      setLastResult(msg);
      toast.push("success", msg);
      if (!fixed) setSelected([]);
      setNote("");
      setReason("");
      onDone?.();
    } catch {
      toast.push("error", "ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  const activeMode = MODES.find((m) => m.key === mode)!;

  return (
    <Modal open={open} onClose={onClose} title="مدیریت جنم" wide>
      <div className="grid gap-5 sm:grid-cols-2">
        {/* انتخاب دانش‌آموزان */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <span className="label mb-0!">دانش‌آموزان {fixed ? "" : `(${fa(selected.length)} انتخاب‌شده)`}</span>
            {selected.length > 0 && !fixed && (
              <button onClick={() => setSelected([])} className="text-faint text-[0.68rem] font-bold hover:text-[var(--danger)]">
                لغو همه
              </button>
            )}
          </div>
          {fixed ? (
            <div className="space-y-2">
              {selectedStudents.map((s) => (
                <div key={s.id} className="panel-inset flex items-center gap-3 px-3 py-2.5">
                  <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={34} />
                  <div className="min-w-0">
                    <div className="truncate text-[0.82rem] font-bold">{s.fullName}</div>
                    <div className="text-faint text-[0.68rem]">{s.className}</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="panel-inset overflow-hidden">
              <div className="relative border-b border-[var(--border)]">
                <Search size={15} className="text-faint absolute top-1/2 right-3 -translate-y-1/2" />
                <input
                  className="w-full bg-transparent py-2.5 ps-4 pe-9 text-[0.82rem] outline-none"
                  placeholder="جست‌وجو…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <div className="max-h-64 overflow-y-auto">
                {pool.map((s) => {
                  const on = selected.includes(s.id);
                  return (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => toggle(s.id)}
                      className={`flex w-full items-center gap-3 px-3 py-2 text-right transition ${on ? "bg-[rgba(79,124,255,.12)]" : "hover:bg-[var(--panel-2)]"}`}
                    >
                      <span
                        className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md border"
                        style={{
                          borderColor: on ? "var(--blue)" : "var(--border-strong)",
                          background: on ? "linear-gradient(150deg,#5d88ff,#2742b8)" : "transparent",
                        }}
                      >
                        {on && <Check size={12} className="text-white" />}
                      </span>
                      <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={30} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[0.8rem] font-bold">{s.fullName}</span>
                        <span className="text-faint text-[0.66rem]">{s.className}</span>
                      </span>
                      <span className="text-faint text-[0.7rem] font-bold" dir="ltr">
                        {faNum(s.janm)}
                      </span>
                    </button>
                  );
                })}
                {pool.length === 0 && <div className="text-faint py-6 text-center text-xs">موردی یافت نشد.</div>}
              </div>
            </div>
          )}
        </div>

        {/* نوع تغییر */}
        <div className="space-y-3">
          <span className="label mb-0!">نوع تغییر</span>
          <div className="grid grid-cols-1 gap-2">
            {MODES.map((m) => {
              const on = mode === m.key;
              return (
                <motion.button
                  key={m.key}
                  type="button"
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setMode(m.key)}
                  className="flex items-center gap-3 rounded-xl border px-3 py-2.5 text-right transition"
                  style={{
                    borderColor: on ? "var(--blue)" : "var(--border)",
                    background: on ? "rgba(79,124,255,.1)" : "transparent",
                  }}
                >
                  <span className={`panel-inset flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${m.cls}`}>
                    <m.icon size={15} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[0.8rem] font-bold">{m.label}</span>
                    <span className="text-faint block text-[0.66rem]">{m.desc}</span>
                  </span>
                  {m.amount !== undefined && (
                    <span className="text-xs font-black" dir="ltr" style={{ color: "var(--danger)" }}>
                      {faNum(m.amount)}
                    </span>
                  )}
                </motion.button>
              );
            })}
          </div>

          {(mode === "increase" || mode === "decrease") && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">میزان جنم</label>
                <input className="input" dir="ltr" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9]/g, ""))} />
              </div>
              <div>
                <label className="label">دلیل</label>
                <input className="input" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="مثلاً: برتری در مسابقه" />
              </div>
            </div>
          )}

          <div>
            <label className="label">توضیحات (اختیاری)</label>
            <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="جزئیات بیشتر…" />
          </div>

          {lastResult && (
            <p className="rounded-xl border border-[rgba(74,222,128,.3)] bg-[rgba(74,222,128,.08)] px-3 py-2 text-[0.72rem] font-bold text-[var(--success)]">
              {lastResult}
            </p>
          )}

          <button onClick={submit} disabled={loading} className="btn btn-gold w-full">
            {loading ? <LoaderCircle size={17} className="animate-spin" /> : <Gem size={16} />}
            {loading ? "در حال ثبت..." : `ثبت «${activeMode.label}»`}
          </button>
        </div>
      </div>
    </Modal>
  );
}
