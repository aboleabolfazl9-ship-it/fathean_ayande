import type { ReactNode } from "react";
import { clsx } from "clsx";
import { fa, faSigned } from "@/lib/format";
import { Inbox } from "lucide-react";

/* ---------------- لوگوی سامانه ---------------- */
export function Logo({ size = 40, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className={className} aria-hidden>
      <defs>
        <linearGradient id="lg-shield" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5d88ff" />
          <stop offset="1" stopColor="#1e38a8" />
        </linearGradient>
        <linearGradient id="lg-star" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#f4d98b" />
          <stop offset="1" stopColor="#c99c33" />
        </linearGradient>
      </defs>
      <path d="M32 4 54 12v16c0 15-9.6 26.4-22 32C19.6 54.4 10 43 10 28V12Z" fill="url(#lg-shield)" />
      <path
        d="M32 14.5 36.6 26l12.4.5-10.4 7.8 3.5 12-10.1-7.2-10.1 7.2 3.5-12L15 26.5l12.4-.5Z"
        fill="url(#lg-star)"
      />
    </svg>
  );
}

/* ---------------- آواتار ---------------- */
const AVATAR_GRADIENTS: Record<string, string> = {
  blue: "linear-gradient(150deg,#5d88ff,#2742b8)",
  indigo: "linear-gradient(150deg,#8b7bff,#4534b8)",
  teal: "linear-gradient(150deg,#2dd4bf,#0f766e)",
  sky: "linear-gradient(150deg,#38bdf8,#0369a1)",
  violet: "linear-gradient(150deg,#c084fc,#7e22ce)",
  slate: "linear-gradient(150deg,#94a3b8,#475569)",
  gold: "linear-gradient(150deg,#f0cd74,#a8791b)",
};

export function Avatar({
  name,
  color = "blue",
  url,
  size = 42,
  ring = false,
  className,
}: {
  name: string;
  color?: string;
  url?: string | null;
  size?: number;
  ring?: boolean;
  className?: string;
}) {
  const initial = name.trim().charAt(0) || "؟";
  return (
    <div
      className={clsx("relative shrink-0 overflow-hidden rounded-2xl flex items-center justify-center font-extrabold text-white select-none", className)}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.42,
        background: AVATAR_GRADIENTS[color] ?? AVATAR_GRADIENTS.blue,
        boxShadow: ring ? "0 0 0 2px var(--bg), 0 0 0 4px rgba(231,189,85,.55)" : "inset 0 1px 0 rgba(255,255,255,.25)",
      }}
    >
      {url ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={url} alt={name} className="absolute inset-0 h-full w-full object-cover" />
      ) : (
        initial
      )}
    </div>
  );
}

/* ---------------- سرصفحه ---------------- */
export function PageHeader({
  title,
  subtitle,
  children,
  icon,
}: {
  title: string;
  subtitle?: string;
  children?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="rise mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="flex items-center gap-3.5">
        {icon ? (
          <div className="panel flex h-12 w-12 items-center justify-center rounded-2xl text-[var(--gold)]">{icon}</div>
        ) : null}
        <div>
          <h1 className="text-xl font-extrabold tracking-tight sm:text-2xl">{title}</h1>
          {subtitle ? <p className="text-muted mt-1 text-sm">{subtitle}</p> : null}
        </div>
      </div>
      {children ? <div className="flex items-center gap-2">{children}</div> : null}
    </div>
  );
}

/* ---------------- حالت خالی ---------------- */
export function EmptyState({ title, hint, icon }: { title: string; hint?: string; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-14 text-center">
      <div className="panel-inset flex h-14 w-14 items-center justify-center rounded-2xl text-[var(--faint)]">
        {icon ?? <Inbox size={26} />}
      </div>
      <p className="font-bold">{title}</p>
      {hint ? <p className="text-muted max-w-sm text-sm leading-7">{hint}</p> : null}
    </div>
  );
}

/* ---------------- قرص جنم ---------------- */
export function JanmValue({ value, size = "md" }: { value: number; size?: "sm" | "md" | "lg" }) {
  const color = value > 0 ? "var(--success)" : value < 0 ? "var(--danger)" : "var(--muted)";
  const cls = size === "lg" ? "text-3xl font-black" : size === "sm" ? "text-sm font-bold" : "text-lg font-extrabold";
  return (
    <span className={cls} style={{ color }} dir="ltr">
      {faSigned(value)}
    </span>
  );
}

/* ---------------- رتبه ---------------- */
export function RankBadge({ rank }: { rank: number }) {
  const styles: Record<number, React.CSSProperties> = {
    1: {
      background: "linear-gradient(150deg,#f6dd9a,#caa038)",
      color: "#241a04",
      boxShadow: "0 6px 18px -6px rgba(212,165,60,.7)",
    },
    2: {
      background: "linear-gradient(150deg,#e2e8f0,#94a3b8)",
      color: "#101828",
      boxShadow: "0 6px 18px -6px rgba(148,163,184,.6)",
    },
    3: {
      background: "linear-gradient(150deg,#e8b98a,#a06a35)",
      color: "#241204",
      boxShadow: "0 6px 18px -6px rgba(180,120,60,.6)",
    },
  };
  const s = styles[rank];
  return (
    <span
      className="inline-flex h-8 w-8 items-center justify-center rounded-xl text-sm font-black"
      style={s ?? { background: "var(--panel-2)", border: "1px solid var(--border)", color: "var(--muted)" }}
    >
      {fa(rank)}
    </span>
  );
}

/* ---------------- مدال مسئولیت ---------------- */
export function TitleBadge({ title }: { title: string }) {
  return (
    <span className="badge badge-gold">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
        <path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7-6.2-3.7-6.2 3.7 1.6-7L2 9.2l7.1-.6z" />
      </svg>
      {title}
    </span>
  );
}
