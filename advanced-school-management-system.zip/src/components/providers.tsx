"use client";

import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import { CheckCircle2, AlertTriangle, Info, X } from "lucide-react";

type Toast = { id: number; type: "success" | "error" | "info"; message: string };
const ToastCtx = createContext<{ push: (type: Toast["type"], message: string) => void }>({ push: () => {} });

export function useToast() {
  return useContext(ToastCtx);
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((type: Toast["type"], message: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, type, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);

  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="pointer-events-none fixed bottom-5 left-1/2 z-[120] flex w-full max-w-md -translate-x-1/2 flex-col items-center gap-2 px-4">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 24, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.96 }}
              transition={{ duration: 0.25, ease: [0.22, 0.9, 0.3, 1] }}
              className="pointer-events-auto flex w-full items-center gap-3 rounded-2xl border px-4 py-3 text-sm font-semibold shadow-soft"
              style={{
                background: "var(--panel-solid)",
                borderColor:
                  t.type === "success"
                    ? "rgba(74,222,128,.4)"
                    : t.type === "error"
                      ? "rgba(255,107,107,.4)"
                      : "var(--border-strong)",
              }}
            >
              {t.type === "success" ? (
                <CheckCircle2 size={18} className="shrink-0 text-[var(--success)]" />
              ) : t.type === "error" ? (
                <AlertTriangle size={18} className="shrink-0 text-[var(--danger)]" />
              ) : (
                <Info size={18} className="shrink-0 text-[var(--blue)]" />
              )}
              <span className="flex-1 leading-6">{t.message}</span>
              <button
                onClick={() => setToasts((x) => x.filter((i) => i.id !== t.id))}
                className="text-faint hover:text-[var(--text)]"
                aria-label="بستن"
              >
                <X size={15} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastCtx.Provider>
  );
}

export type Theme = "dark" | "light";

export function toggleTheme(): Theme {
  const current = document.documentElement.dataset.theme === "light" ? "light" : "dark";
  const next: Theme = current === "light" ? "dark" : "light";
  document.documentElement.dataset.theme = next;
  try {
    localStorage.setItem("fa-theme", next);
  } catch {}
  return next;
}

export function getTheme(): Theme {
  if (typeof document === "undefined") return "dark";
  return document.documentElement.dataset.theme === "light" ? "light" : "dark";
}
