"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import {
  LayoutDashboard,
  ListOrdered,
  Shield,
  GraduationCap,
  Trophy,
  Megaphone,
  Settings,
  Crown,
  LogOut,
  Menu,
  X,
  Sun,
  Moon,
  Bell,
  UserRound,
  CalendarClock,
  ChevronDown,
} from "lucide-react";
import { Logo, Avatar } from "@/components/ui";
import { toggleTheme, getTheme, useToast } from "@/components/providers";
import { faDate } from "@/lib/format";
import type { AnnouncementItem, SessionUser } from "@/lib/types";

const NAV = [
  { href: "/", label: "داشبورد", icon: LayoutDashboard },
  { href: "/list", label: "لیست مدرسه", icon: ListOrdered },
  { href: "/bases", label: "قرارگاه‌ها", icon: Shield },
  { href: "/exams", label: "برنامه امتحانات", icon: CalendarClock },
  { href: "/classes", label: "کلاس‌ها", icon: GraduationCap },
  { href: "/honors", label: "افتخارات", icon: Trophy },
  { href: "/announcements", label: "اطلاعیه‌ها", icon: Megaphone },
  { href: "/settings", label: "تنظیمات", icon: Settings },
];

function RoleLabel({ role }: { role: string }) {
  if (role === "superadmin") return <span className="badge badge-gold">مدیر اصلی</span>;
  if (role === "admin") return <span className="badge badge-blue">مدیر</span>;
  return null;
}

export function AppShell({ user, children }: { user: SessionUser; children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const toast = useToast();
  const [drawer, setDrawer] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [userMenu, setUserMenu] = useState(false);
  const [bell, setBell] = useState(false);
  const [news, setNews] = useState<AnnouncementItem[]>([]);
  const menuRef = useRef<HTMLDivElement>(null);
  const bellRef = useRef<HTMLDivElement>(null);

  const isAdminUser = user.role === "admin" || user.role === "superadmin";

  useEffect(() => {
    setTheme(getTheme());
    fetch("/api/announcements")
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (j?.ok) setNews(j.data.slice(0, 4));
      })
      .catch(() => {});
  }, []);

  useEffect(() => setDrawer(false), [pathname]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setUserMenu(false);
      if (bellRef.current && !bellRef.current.contains(e.target as Node)) setBell(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  async function logout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      toast.push("info", "از حساب خارج شدید.");
      window.location.href = "/login";
    } catch {
      toast.push("error", "خروج انجام نشد؛ دوباره تلاش کنید.");
    }
  }

  const navList = (
    <nav className="flex flex-1 flex-col gap-1 overflow-y-auto px-3 py-4">
      {NAV.map((item) => {
        const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
        return (
          <Link key={item.href} href={item.href} className={`nav-item ${active ? "active" : ""}`}>
            <item.icon size={18} strokeWidth={2.1} />
            {item.label}
          </Link>
        );
      })}
      {isAdminUser && (
        <>
          <div className="text-faint mt-4 mb-1 px-3 text-[0.68rem] font-bold tracking-wider">بخش اختصاصی</div>
          <Link href="/admin" className={`nav-item ${pathname.startsWith("/admin") ? "active" : ""}`}>
            <Crown size={18} strokeWidth={2.1} className="text-[var(--gold)]" />
            <span className={pathname.startsWith("/admin") ? "" : "text-[var(--gold)]"}>پنل مدیریت</span>
          </Link>
        </>
      )}
    </nav>
  );

  const sidebarHead = (
    <div className="flex items-center gap-3 px-5 pt-6 pb-4">
      <Logo size={38} className="float-y" />
      <div>
        <div className="text-[0.98rem] font-black tracking-tight">فاتحان آینده</div>
        <div className="text-faint text-[0.68rem] font-semibold">سامانه یکپارچه مدرسه</div>
      </div>
    </div>
  );

  return (
    <div className="min-h-dvh">
      {/* نوار حالت مدیریت */}
      {isAdminUser && (
        <div className="admin-strip sticky top-0 z-40 flex items-center justify-center gap-2 px-4 py-1.5 text-[0.72rem] font-bold">
          <Crown size={13} />
          حالت مدیریت فعال است — تغییرات شما مستقیماً در سامانه ثبت می‌شود
        </div>
      )}

      {/* سایدبار دسکتاپ */}
      <aside
        className="fixed top-0 right-0 z-30 hidden h-dvh w-64 flex-col lg:flex"
        style={{
          background: "var(--panel)",
          borderLeft: "1px solid var(--border)",
          backdropFilter: "blur(16px)",
          marginTop: isAdminUser ? "30px" : 0,
        }}
      >
        {sidebarHead}
        <hr className="hr-gold mx-5" />
        {navList}
        <div className="border-t border-[var(--border)] p-3">
          <Link href={`/students/${user.id}`} className="nav-item">
            <Avatar name={user.fullName} color={user.avatarColor} url={user.avatarUrl} size={30} ring={isAdminUser} />
            <div className="min-w-0">
              <div className="truncate text-[0.82rem] font-bold">{user.fullName}</div>
              <div className="text-faint truncate text-[0.68rem]">{user.className ?? user.title ?? "—"}</div>
            </div>
          </Link>
        </div>
      </aside>

      {/* منوی موبایل */}
      <AnimatePresence>
        {drawer && (
          <>
            <motion.div
              className="fixed inset-0 z-50 lg:hidden"
              style={{ background: "rgba(3,6,14,.6)", backdropFilter: "blur(6px)" }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawer(false)}
            />
            <motion.aside
              className="fixed top-0 right-0 z-50 flex h-dvh w-72 flex-col lg:hidden"
              style={{ background: "var(--panel-solid)", borderLeft: "1px solid var(--border)" }}
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
            >
              <div className="flex items-center justify-between pe-2">
                {sidebarHead}
                <button
                  onClick={() => setDrawer(false)}
                  className="panel-inset ms-auto me-3 flex h-9 w-9 items-center justify-center rounded-xl"
                  aria-label="بستن منو"
                >
                  <X size={17} />
                </button>
              </div>
              <hr className="hr-gold mx-5" />
              {navList}
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* محتوا */}
      <div className="lg:mr-64">
        {/* نوار بالایی */}
        <header
          className="sticky top-0 z-30 flex items-center gap-2 px-4 py-3 sm:px-6"
          style={{
            background: "var(--bg)",
            backgroundImage: "linear-gradient(var(--bg), color-mix(in srgb, var(--bg) 82%, transparent))",
            borderBottom: "1px solid var(--border)",
            backdropFilter: "blur(14px)",
            marginTop: isAdminUser ? "-1px" : 0,
          }}
        >
          <button
            onClick={() => setDrawer(true)}
            className="panel-inset flex h-10 w-10 items-center justify-center rounded-xl lg:hidden"
            aria-label="باز کردن منو"
          >
            <Menu size={19} />
          </button>

          <div className="flex items-center gap-2 lg:hidden">
            <Logo size={30} />
            <span className="text-sm font-black">فاتحان آینده</span>
          </div>

          <div className="ms-auto flex items-center gap-2">
            {/* اعلان‌ها */}
            <div className="relative" ref={bellRef}>
              <button
                onClick={() => setBell((b) => !b)}
                className="panel-inset relative flex h-10 w-10 items-center justify-center rounded-xl transition hover:border-[var(--border-strong)]"
                aria-label="اعلان‌ها"
              >
                <Bell size={18} />
                {news.length > 0 && (
                  <span className="glow-dot absolute -top-0.5 -left-0.5 h-2.5 w-2.5 rounded-full bg-[var(--gold)]" />
                )}
              </button>
              <AnimatePresence>
                {bell && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 6, scale: 0.98 }}
                    transition={{ duration: 0.18 }}
                    className="glass-strong absolute left-0 top-12 w-80 overflow-hidden p-2"
                  >
                    <div className="px-3 pt-2 pb-1 text-xs font-extrabold">آخرین اطلاعیه‌ها</div>
                    {news.length === 0 && <div className="text-muted px-3 py-4 text-xs">اطلاعیه‌ای وجود ندارد.</div>}
                    {news.map((n) => (
                      <Link
                        key={n.id}
                        href="/announcements"
                        onClick={() => setBell(false)}
                        className="block rounded-xl px-3 py-2.5 transition hover:bg-[var(--panel-2)]"
                      >
                        <div className="truncate text-[0.82rem] font-bold">{n.title}</div>
                        <div className="text-faint mt-0.5 text-[0.68rem]">{faDate(n.createdAt)}</div>
                      </Link>
                    ))}
                    <Link
                      href="/announcements"
                      onClick={() => setBell(false)}
                      className="text-muted mt-1 block border-t border-[var(--border)] px-3 py-2 text-center text-[0.72rem] font-bold hover:text-[var(--text)]"
                    >
                      مشاهده همه
                    </Link>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* تم */}
            <button
              onClick={() => setTheme(toggleTheme())}
              className="panel-inset flex h-10 w-10 items-center justify-center rounded-xl transition hover:border-[var(--border-strong)]"
              aria-label="تغییر تم"
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {/* منوی کاربر */}
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setUserMenu((m) => !m)}
                className="panel-inset flex h-10 items-center gap-2 rounded-xl pe-2 ps-1.5 transition hover:border-[var(--border-strong)]"
              >
                <Avatar name={user.fullName} color={user.avatarColor} url={user.avatarUrl} size={30} ring={isAdminUser} />
                <span className="hidden max-w-28 truncate text-xs font-bold sm:block">{user.fullName}</span>
                <ChevronDown size={14} className="text-faint" />
              </button>
              <AnimatePresence>
                {userMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 6, scale: 0.98 }}
                    transition={{ duration: 0.18 }}
                    className="glass-strong absolute left-0 top-12 w-60 overflow-hidden p-2"
                  >
                    <div className="px-3 pt-2 pb-2">
                      <div className="truncate text-sm font-extrabold">{user.fullName}</div>
                      <div className="mt-1 flex items-center gap-2">
                        <RoleLabel role={user.role} />
                        {user.title && <span className="badge badge-gold">{user.title}</span>}
                        {!user.title && user.role === "student" && (
                          <span className="badge">{user.className ?? "دانش‌آموز"}</span>
                        )}
                      </div>
                    </div>
                    <div className="my-1 border-t border-[var(--border)]" />
                    {user.role === "student" && (
                      <Link
                        href={`/students/${user.id}`}
                        onClick={() => setUserMenu(false)}
                        className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[0.82rem] font-bold transition hover:bg-[var(--panel-2)]"
                      >
                        <UserRound size={16} className="text-faint" />
                        پروفایل من
                      </Link>
                    )}
                    <Link
                      href="/settings"
                      onClick={() => setUserMenu(false)}
                      className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[0.82rem] font-bold transition hover:bg-[var(--panel-2)]"
                    >
                      <Settings size={16} className="text-faint" />
                      تنظیمات حساب
                    </Link>
                    <button
                      onClick={logout}
                      className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-right text-[0.82rem] font-bold text-[var(--danger)] transition hover:bg-[rgba(255,107,107,.1)]"
                    >
                      <LogOut size={16} />
                      خروج امن از حساب
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-4 py-6 pb-20 sm:px-6">{children}</main>
      </div>
    </div>
  );
}
