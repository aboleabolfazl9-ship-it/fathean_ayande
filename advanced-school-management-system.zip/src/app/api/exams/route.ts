import { z } from "zod";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { exams } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { parseJalaliString } from "@/lib/format";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

export async function GET() {
  try {
    const me = await getSessionUser();
    if (!me) return fail("ابتدا وارد شوید.", 401);
    const rows = await db.select().from(exams).orderBy(asc(exams.examDate));
    return ok(
      rows.map((e) => ({
        id: e.id,
        title: e.title,
        description: e.description,
        examDate: e.examDate.toISOString(),
      })),
    );
  } catch (e) {
    return handleError(e);
  }
}

const createSchema = z.object({
  title: z.string().trim().min(2, "عنوان امتحان را وارد کنید.").max(160),
  description: z.string().trim().max(600).optional().default(""),
  date: z.string().trim().min(8, "تاریخ را وارد کنید."),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "exams")) return fail("دسترسی مدیریت امتحانات را ندارید.", 403);
    const body = createSchema.parse(await req.json());

    const examDate = parseJalaliString(body.date) ?? (isNaN(Date.parse(body.date)) ? null : new Date(body.date));
    if (!examDate) return fail("تاریخ معتبر نیست. نمونه: 1404/09/15", 422);

    const [row] = await db
      .insert(exams)
      .values({ title: body.title, description: body.description, examDate })
      .returning();
    await logActivity(me!.id, me!.fullName, "افزودن امتحان", `امتحان «${body.title}» ثبت شد.`);
    return ok({ id: row.id, title: row.title, description: row.description, examDate: row.examDate.toISOString() });
  } catch (e) {
    return handleError(e);
  }
}
