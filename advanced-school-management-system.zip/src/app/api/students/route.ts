import { z } from "zod";
import { asc, desc, eq, ilike, ne, and, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { getSessionUser, hasPerm, isAdmin } from "@/lib/auth";
import { hashPassword } from "@/lib/crypto";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

function toBrief(u: typeof users.$inferSelect, className: string | null, classCode: string | null) {
  return {
    id: u.id,
    fullName: u.fullName,
    username: u.username,
    classId: u.classId,
    className,
    classCode,
    role: u.role,
    title: u.title,
    janm: u.janm,
    isApproved: u.isApproved,
    isBlocked: u.isBlocked,
    avatarColor: u.avatarColor,
    avatarUrl: u.avatarUrl,
  };
}

/** لیست دانش‌آموزان با رتبه‌بندی — فقط برای کاربران واردشده */
export async function GET(req: Request) {
  try {
    const me = await getSessionUser();
    if (!me) return fail("ابتدا وارد شوید.", 401);

    const url = new URL(req.url);
    const q = url.searchParams.get("q")?.trim() ?? "";
    const classId = url.searchParams.get("classId");
    const pending = url.searchParams.get("pending") === "1";

    const conds: SQL[] = [ne(users.role, "superadmin")];
    if (q) conds.push(ilike(users.fullName, `%${q}%`));
    if (classId && !isNaN(Number(classId))) conds.push(eq(users.classId, Number(classId)));
    if (pending) {
      if (!isAdmin(me)) return fail("دسترسی ندارید.", 403);
      conds.push(eq(users.isApproved, false));
    }

    const rows = await db
      .select({ u: users, className: classes.name, classCode: classes.code })
      .from(users)
      .leftJoin(classes, eq(classes.id, users.classId))
      .where(and(...conds))
      .orderBy(desc(users.janm), asc(users.fullName));

    const items = rows.map((r) => toBrief(r.u, r.className, r.classCode));

    // رتبه‌بندی رقابتی (رتبه‌های مساوی در نظر گرفته می‌شود)
    let rank = 0;
    let prev: number | null = null;
    items.forEach((s, i) => {
      if (prev === null || s.janm !== prev) {
        rank = i + 1;
        prev = s.janm;
      }
      (s as { rank?: number }).rank = rank;
    });

    return ok(items);
  } catch (e) {
    return handleError(e);
  }
}

const createSchema = z.object({
  fullName: z.string().trim().min(5, "نام و نام خانوادگی را کامل وارد کنید.").max(140),
  username: z
    .string()
    .trim()
    .min(4, "نام کاربری حداقل ۴ کاراکتر.")
    .max(40)
    .regex(/^[a-zA-Z0-9_.-]+$/, "نام کاربری فقط حروف انگلیسی، عدد و نقطه."),
  password: z.string().min(6, "رمز عبور حداقل ۶ کاراکتر.").max(100),
  classId: z.coerce.number().int().positive(),
  title: z.string().trim().max(80).optional().nullable(),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "students")) return fail("دسترسی مدیریت دانش‌آموزان را ندارید.", 403);
    const body = createSchema.parse(await req.json());

    const username = body.username.toLowerCase();
    const dup = await db.select({ id: users.id }).from(users).where(eq(users.username, username)).limit(1);
    if (dup.length) return fail("این نام کاربری قبلاً استفاده شده است.", 409);

    const [row] = await db
      .insert(users)
      .values({
        username,
        passwordHash: hashPassword(body.password),
        fullName: body.fullName,
        classId: body.classId,
        title: body.title ?? null,
        role: "student",
        janm: 0,
        isApproved: true,
        avatarColor: "blue",
      })
      .returning();
    await logActivity(me!.id, me!.fullName, "افزودن دانش‌آموز", `دانش‌آموز «${body.fullName}» با نام کاربری ${username} ایجاد شد.`);
    const [cls] = await db.select().from(classes).where(eq(classes.id, row.classId!)).limit(1);
    return ok(toBrief(row, cls?.name ?? null, cls?.code ?? null));
  } catch (e) {
    return handleError(e);
  }
}
