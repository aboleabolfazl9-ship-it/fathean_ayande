import { z } from "zod";
import { desc, eq, ne, and } from "drizzle-orm";
import { db } from "@/db";
import { baseMembers, bases, classes, honors, janmTransactions, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { hashPassword, randomTempPassword } from "@/lib/crypto";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

/** پروفایل کامل دانش‌آموز — کاربران واردشده */
export async function GET(_req: Request, ctx: Ctx) {
  try {
    const me = await getSessionUser();
    if (!me) return fail("ابتدا وارد شوید.", 401);
    const { id } = await ctx.params;
    const uid = Number(id);
    if (!Number.isInteger(uid)) return fail("شناسه نامعتبر است.", 422);

    const [row] = await db
      .select({ u: users, className: classes.name, classCode: classes.code })
      .from(users)
      .leftJoin(classes, eq(classes.id, users.classId))
      .where(eq(users.id, uid))
      .limit(1);
    if (!row || row.u.role === "superadmin") return fail("دانش‌آموز یافت نشد.", 404);

    // رتبه: ۱ + تعداد کسانی که جنم بیشتری دارند
    const all = await db
      .select({ id: users.id, janm: users.janm })
      .from(users)
      .where(and(ne(users.role, "superadmin"), eq(users.isApproved, true)));
    const myJanm = row.u.janm;
    const myRank = 1 + all.filter((x) => x.janm > myJanm).length;

    const txs = await db
      .select()
      .from(janmTransactions)
      .where(eq(janmTransactions.userId, uid))
      .orderBy(desc(janmTransactions.createdAt), desc(janmTransactions.id))
      .limit(60);

    const honorsList = await db
      .select()
      .from(honors)
      .where(eq(honors.userId, uid))
      .orderBy(desc(honors.awardDate), desc(honors.id))
      .limit(40);

    const membership = await db
      .select({ id: bases.id, name: bases.name, icon: bases.icon, hue: bases.hue })
      .from(baseMembers)
      .innerJoin(bases, eq(bases.id, baseMembers.baseId))
      .where(eq(baseMembers.userId, uid));

    return ok({
      student: {
        id: row.u.id,
        fullName: row.u.fullName,
        username: row.u.username,
        classId: row.u.classId,
        className: row.className,
        classCode: row.classCode,
        role: row.u.role,
        title: row.u.title,
        janm: row.u.janm,
        isApproved: row.u.isApproved,
        isBlocked: row.u.isBlocked,
        avatarColor: row.u.avatarColor,
        avatarUrl: row.u.avatarUrl,
        rank: myRank,
      },
      transactions: txs.map((t) => ({
        id: t.id,
        userId: t.userId,
        amount: t.amount,
        kind: t.kind,
        reason: t.reason,
        note: t.note,
        actorName: t.actorName,
        status: t.status,
        correctsId: t.correctsId,
        createdAt: t.createdAt.toISOString(),
      })),
      honors: honorsList.map((h) => ({
        id: h.id,
        userId: h.userId,
        userName: row.u.fullName,
        title: h.title,
        description: h.description,
        awardDate: h.awardDate.toISOString(),
        createdByName: h.createdByName,
        createdAt: h.createdAt.toISOString(),
      })),
      bases: membership,
    });
  } catch (e) {
    return handleError(e);
  }
}

const patchSchema = z.object({
  fullName: z.string().trim().min(5).max(140).optional(),
  username: z
    .string()
    .trim()
    .min(4)
    .max(40)
    .regex(/^[a-zA-Z0-9_.-]+$/)
    .optional(),
  classId: z.coerce.number().int().positive().nullable().optional(),
  title: z.string().trim().max(80).nullable().optional(),
  isBlocked: z.boolean().optional(),
  isApproved: z.boolean().optional(),
  resetPassword: z.boolean().optional(),
});

export async function PATCH(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "students")) return fail("دسترسی مدیریت دانش‌آموزان را ندارید.", 403);
    const { id } = await ctx.params;
    const uid = Number(id);

    const [target] = await db.select().from(users).where(eq(users.id, uid)).limit(1);
    if (!target) return fail("دانش‌آموز یافت نشد.", 404);
    if (target.role === "superadmin") return fail("حساب مدیر اصلی از این مسیر قابل تغییر نیست.", 403);

    const body = patchSchema.parse(await req.json());
    const values: Record<string, unknown> = {};
    let tempPassword: string | null = null;
    const actions: string[] = [];

    if (body.fullName && body.fullName !== target.fullName) {
      values.fullName = body.fullName;
      actions.push("ویرایش نام");
    }
    if (body.username) {
      const uname = body.username.toLowerCase();
      if (uname !== target.username) {
        const dup = await db.select({ id: users.id }).from(users).where(eq(users.username, uname)).limit(1);
        if (dup.length) return fail("این نام کاربری قبلاً استفاده شده است.", 409);
        values.username = uname;
        actions.push("تغییر نام کاربری");
      }
    }
    if (body.classId !== undefined && body.classId !== target.classId) {
      values.classId = body.classId;
      actions.push("انتقال کلاس");
    }
    if (body.title !== undefined && body.title !== target.title) {
      values.title = body.title;
      actions.push("تغییر مسئولیت");
    }
    if (body.isBlocked !== undefined && body.isBlocked !== target.isBlocked) {
      values.isBlocked = body.isBlocked;
      actions.push(body.isBlocked ? "مسدودسازی حساب" : "رفع مسدودیت");
    }
    if (body.isApproved !== undefined && body.isApproved !== target.isApproved) {
      values.isApproved = body.isApproved;
      actions.push(body.isApproved ? "تأیید حساب" : "تعلیق حساب");
    }
    if (body.resetPassword) {
      tempPassword = randomTempPassword();
      values.passwordHash = hashPassword(tempPassword);
      actions.push("بازنشانی رمز عبور");
    }

    if (!Object.keys(values).length) return fail("هیچ تغییری ارسال نشد.", 422);

    const [updated] = await db.update(users).set(values).where(eq(users.id, uid)).returning({
      id: users.id,
      fullName: users.fullName,
      username: users.username,
      classId: users.classId,
    });
    await logActivity(
      me!.id,
      me!.fullName,
      "مدیریت دانش‌آموز",
      `${actions.join("، ")} برای «${target.fullName}» انجام شد.`,
    );
    return ok({ student: updated, tempPassword });
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "students")) return fail("دسترسی مدیریت دانش‌آموزان را ندارید.", 403);
    const { id } = await ctx.params;
    const uid = Number(id);

    const [target] = await db.select().from(users).where(eq(users.id, uid)).limit(1);
    if (!target) return fail("دانش‌آموز یافت نشد.", 404);
    if (target.role === "superadmin") return fail("حساب مدیر اصلی قابل حذف نیست.", 403);
    if (target.id === me!.id) return fail("نمی‌توانید حساب خودتان را حذف کنید.", 403);

    await db.delete(users).where(eq(users.id, uid));
    await logActivity(me!.id, me!.fullName, "حذف دانش‌آموز", `دانش‌آموز «${target.fullName}» (${target.username}) حذف شد.`);
    return ok({ message: "دانش‌آموز حذف شد." });
  } catch (e) {
    return handleError(e);
  }
}
