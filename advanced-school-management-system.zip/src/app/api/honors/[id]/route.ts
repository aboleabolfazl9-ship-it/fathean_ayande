import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { honors } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { parseJalaliString } from "@/lib/format";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  title: z.string().trim().min(2).max(180).optional(),
  description: z.string().trim().max(800).optional(),
  date: z.string().trim().min(8).optional(),
});

export async function PATCH(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "content")) return fail("دسترسی ویرایش افتخار را ندارید.", 403);
    const { id } = await ctx.params;
    const body = patchSchema.parse(await req.json());

    const values: Record<string, unknown> = {};
    if (body.title) values.title = body.title;
    if (body.description !== undefined) values.description = body.description;
    if (body.date) {
      const d = parseJalaliString(body.date) ?? (isNaN(Date.parse(body.date)) ? null : new Date(body.date));
      if (!d) return fail("تاریخ معتبر نیست.", 422);
      values.awardDate = d;
    }
    if (!Object.keys(values).length) return fail("تغییری ارسال نشد.", 422);

    const [row] = await db.update(honors).set(values).where(eq(honors.id, Number(id))).returning();
    if (!row) return fail("افتخار یافت نشد.", 404);
    await logActivity(me!.id, me!.fullName, "ویرایش افتخار", `افتخار «${row.title}» ویرایش شد.`);
    return ok({ id: row.id });
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "content")) return fail("دسترسی حذف افتخار را ندارید.", 403);
    const { id } = await ctx.params;
    const [row] = await db.delete(honors).where(eq(honors.id, Number(id))).returning();
    if (!row) return fail("افتخار یافت نشد.", 404);
    await logActivity(me!.id, me!.fullName, "حذف افتخار", `افتخار «${row.title}» حذف شد.`);
    return ok({ message: "افتخار حذف شد." });
  } catch (e) {
    return handleError(e);
  }
}
