import { z } from "zod";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { classes, honors, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { parseJalaliString } from "@/lib/format";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

export async function GET() {
  try {
    const me = await getSessionUser();
    if (!me) return fail("ابتدا وارد شوید.", 401);
    const rows = await db
      .select({
        h: honors,
        userName: users.fullName,
        className: classes.name,
      })
      .from(honors)
      .innerJoin(users, eq(users.id, honors.userId))
      .leftJoin(classes, eq(classes.id, users.classId))
      .orderBy(desc(honors.awardDate), desc(honors.id))
      .limit(100);

    return ok(
      rows.map(({ h, userName, className }) => ({
        id: h.id,
        userId: h.userId,
        userName,
        className,
        title: h.title,
        description: h.description,
        awardDate: h.awardDate.toISOString(),
        createdByName: h.createdByName,
        createdAt: h.createdAt.toISOString(),
      })),
    );
  } catch (e) {
    return handleError(e);
  }
}

const createSchema = z.object({
  userId: z.number().int().positive("دانش‌آموز را انتخاب کنید."),
  title: z.string().trim().min(2, "عنوان افتخار را وارد کنید.").max(180),
  description: z.string().trim().max(800).optional().default(""),
  date: z.string().trim().optional(),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "content")) return fail("دسترسی ثبت افتخار را ندارید.", 403);
    const body = createSchema.parse(await req.json());

    const [target] = await db.select().from(users).where(eq(users.id, body.userId)).limit(1);
    if (!target || target.role === "superadmin") return fail("دانش‌آموز یافت نشد.", 404);

    let awardDate = new Date();
    if (body.date) {
      const d = parseJalaliString(body.date) ?? (isNaN(Date.parse(body.date)) ? null : new Date(body.date));
      if (!d) return fail("تاریخ معتبر نیست. نمونه: 1404/08/20", 422);
      awardDate = d;
    }

    const [row] = await db
      .insert(honors)
      .values({
        userId: body.userId,
        title: body.title,
        description: body.description,
        awardDate,
        createdById: me!.id,
        createdByName: me!.fullName,
      })
      .returning();
    await logActivity(me!.id, me!.fullName, "ثبت افتخار", `افتخار «${body.title}» برای ${target.fullName} ثبت شد.`);
    return ok({ id: row.id });
  } catch (e) {
    return handleError(e);
  }
}
