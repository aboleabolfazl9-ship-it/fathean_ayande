import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError } from "@/lib/api";

const ALLOWED: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};
const MAX_SIZE = 2 * 1024 * 1024;

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const user = await getSessionUser();
    if (!user) return fail("ابتدا وارد شوید.", 401);

    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return fail("فایلی ارسال نشد.", 422);
    const ext = ALLOWED[file.type];
    if (!ext) return fail("فقط فرمت‌های JPG، PNG یا WebP مجاز است.", 422);
    if (file.size > MAX_SIZE) return fail("حجم تصویر باید کمتر از ۲ مگابایت باشد.", 422);

    const dir = path.join(process.cwd(), "public", "uploads", "avatars");
    await mkdir(dir, { recursive: true });
    const filename = `u${user.id}-${Date.now()}.${ext}`;
    await writeFile(path.join(dir, filename), Buffer.from(await file.arrayBuffer()));

    const url = `/uploads/avatars/${filename}`;
    await db.update(users).set({ avatarUrl: url }).where(eq(users.id, user.id));
    return ok({ url });
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const user = await getSessionUser();
    if (!user) return fail("ابتدا وارد شوید.", 401);
    await db.update(users).set({ avatarUrl: null }).where(eq(users.id, user.id));
    return ok({ message: "تصویر پروفایل حذف شد." });
  } catch (e) {
    return handleError(e);
  }
}
