import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError } from "@/lib/api";

/** وضعیت نشست فعلی — برای بررسی ذخیره‌شدن کوکی پس از ورود */
export async function GET() {
  const user = await getSessionUser();
  if (!user) return fail("نشستی وجود ندارد.", 401);
  return ok({ id: user.id, fullName: user.fullName, role: user.role });
}

const patchSchema = z.object({
  notifyPrefs: z
    .object({
      announcements: z.boolean(),
      janm: z.boolean(),
      exams: z.boolean(),
    })
    .optional(),
  avatarColor: z.string().max(20).optional(),
});

export async function PATCH(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const user = await getSessionUser();
    if (!user) return fail("ابتدا وارد شوید.", 401);
    const body = patchSchema.parse(await req.json());

    const values: Record<string, unknown> = {};
    if (body.notifyPrefs) values.notifyPrefs = body.notifyPrefs;
    if (body.avatarColor) values.avatarColor = body.avatarColor;
    if (!Object.keys(values).length) return fail("تغییری ارسال نشد.", 422);

    await db.update(users).set(values).where(eq(users.id, user.id));
    return ok({ message: "تنظیمات ذخیره شد." });
  } catch (e) {
    return handleError(e);
  }
}
