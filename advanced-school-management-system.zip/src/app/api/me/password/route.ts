import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser, destroySession } from "@/lib/auth";
import { hashPassword, verifyPassword } from "@/lib/crypto";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

const schema = z.object({
  current: z.string().min(1, "رمز فعلی را وارد کنید."),
  next: z.string().min(6, "رمز جدید باید حداقل ۶ کاراکتر باشد.").max(100),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const user = await getSessionUser();
    if (!user) return fail("ابتدا وارد شوید.", 401);
    const body = schema.parse(await req.json());

    if (!verifyPassword(body.current, user.passwordHash)) {
      return fail("رمز فعلی اشتباه است.", 401);
    }
    if (body.current === body.next) {
      return fail("رمز جدید باید با رمز فعلی متفاوت باشد.", 422);
    }

    await db.update(users).set({ passwordHash: hashPassword(body.next) }).where(eq(users.id, user.id));
    await logActivity(user.id, user.fullName, "تغییر رمز عبور", "کاربر رمز عبور خود را تغییر داد.");
    // نشست فعلی به‌روز می‌ماند؛ نشست‌های دیگر با ایجاد نشست جدید در ورود بعدی ساخته می‌شوند
    void destroySession; // عمداً نشست فعلی حفظ می‌شود
    return ok({ message: "رمز عبور با موفقیت تغییر کرد." });
  } catch (e) {
    return handleError(e);
  }
}
