import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { verifyPassword } from "@/lib/crypto";
import { createSession } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError } from "@/lib/api";

const schema = z.object({
  username: z.string().trim().min(3, "نام کاربری را کامل وارد کنید.").max(60),
  password: z.string().min(1, "رمز عبور را وارد کنید.").max(100),
});

/* محدودکننده ساده تلاش‌های ورود */
const attempts = new Map<string, { count: number; until: number }>();
function rateLimited(key: string): boolean {
  const now = Date.now();
  const rec = attempts.get(key);
  if (rec && rec.until > now && rec.count >= 8) return true;
  return false;
}
function recordAttempt(key: string) {
  const now = Date.now();
  const rec = attempts.get(key);
  if (!rec || rec.until < now) attempts.set(key, { count: 1, until: now + 10 * 60 * 1000 });
  else rec.count++;
}

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const body = schema.parse(await req.json());
    const key = body.username.toLowerCase();
    if (rateLimited(key)) {
      return fail("به دلیل تلاش‌های ناموفق متعدد، ورود برای چند دقیقه محدود شد.", 429);
    }

    const [user] = await db.select().from(users).where(eq(users.username, key)).limit(1);
    if (!user || !verifyPassword(body.password, user.passwordHash)) {
      recordAttempt(key);
      return fail("نام کاربری یا رمز عبور اشتباه است.", 401);
    }
    if (!user.isApproved) {
      return fail("حساب شما هنوز توسط مدیر تأیید نشده است. پس از تأیید می‌توانید وارد شوید.", 403);
    }
    if (user.isBlocked) {
      return fail("حساب شما مسدود شده است. برای رفع مسدودیت به مدیر مدرسه مراجعه کنید.", 403);
    }

    await createSession(user.id);
    return ok({ id: user.id, fullName: user.fullName, role: user.role });
  } catch (e) {
    return handleError(e);
  }
}
