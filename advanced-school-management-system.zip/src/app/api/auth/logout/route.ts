import { destroySession } from "@/lib/auth";
import { ok, csrfGuard } from "@/lib/api";

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  await destroySession();
  return ok({ message: "خروج انجام شد." });
}
