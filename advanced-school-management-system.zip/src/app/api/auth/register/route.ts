import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { hashPassword } from "@/lib/crypto";
import { ok, fail, csrfGuard, handleError } from "@/lib/api";

const schema = z.object({
  fullName: z.string().trim().min(5, "نام و نام خانوادگی را کامل وارد کنید.").max(140),
  username: z
    .string()
    .trim()
    .min(4, "نام کاربری باید حداقل ۴ کاراکتر باشد.")
    .max(40, "نام کاربری طولانی است.")
    .regex(/^[a-zA-Z0-9_.-]+$/, "نام کاربری فقط می‌تواند شامل حروف انگلیسی، عدد و نقطه باشد."),
  password: z.string().min(6, "رمز عبور باید حداقل ۶ کاراکتر باشد.").max(100),
  classId: z.coerce.number().int().positive("کلاس را انتخاب کنید."),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const body = schema.parse(await req.json());

    const [cls] = await db.select({ id: classes.id }).from(classes).where(eq(classes.id, body.classId)).limit(1);
    if (!cls) return fail("کلاس انتخاب‌شده معتبر نیست.", 422);

    const username = body.username.toLowerCase();
    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.username, username)).limit(1);
    if (existing) return fail("این نام کاربری قبلاً ثبت شده است. نام کاربری دیگری انتخاب کنید.", 409);

    await db.insert(users).values({
      username,
      passwordHash: hashPassword(body.password),
      fullName: body.fullName,
      classId: body.classId,
      role: "student",
      janm: 0,
      isApproved: false,
      avatarColor: "blue",
    });

    return ok({ message: "ثبت‌نام انجام شد. حساب شما پس از تأیید مدیر فعال می‌شود." });
  } catch (e) {
    return handleError(e);
  }
}
