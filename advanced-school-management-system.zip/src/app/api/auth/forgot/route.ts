import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import { ok, csrfGuard, handleError } from "@/lib/api";

const schema = z.object({
  username: z.string().trim().min(3, "نام کاربری را وارد کنید.").max(60),
  note: z.string().trim().max(300).optional().default(""),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const body = schema.parse(await req.json());
    const username = body.username.toLowerCase();

    const [user] = await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (user) {
      const [pending] = await db
        .select({ id: passwordResets.id })
        .from(passwordResets)
        .where(and(eq(passwordResets.username, username), eq(passwordResets.status, "pending")))
        .limit(1);
      if (!pending) {
        await db.insert(passwordResets).values({
          username,
          fullName: user.fullName,
          note: body.note,
        });
      }
    }
    // پیام یکسان برای جلوگیری از افشای وجود حساب
    return ok({
      message: "درخواست بازیابی ثبت شد. مدیر پس از بررسی، رمز جدید را از مسیر امن به شما اعلام می‌کند.",
    });
  } catch (e) {
    return handleError(e);
  }
}
