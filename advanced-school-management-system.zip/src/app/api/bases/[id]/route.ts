import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { baseMembers, bases, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  name: z.string().trim().min(3).max(80).optional(),
  managerName: z.string().trim().min(3).max(140).optional(),
  managerUserId: z.number().int().positive().nullable().optional(),
  description: z.string().trim().max(800).optional(),
  icon: z.string().trim().max(40).optional(),
  hue: z.string().trim().max(40).optional(),
});

export async function PATCH(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "bases")) return fail("دسترسی مدیریت قرارگاه‌ها را ندارید.", 403);
    const { id } = await ctx.params;
    const baseId = Number(id);
    const body = patchSchema.parse(await req.json());

    const [row] = await db.update(bases).set(body).where(eq(bases.id, baseId)).returning();
    if (!row) return fail("قرارگاه یافت نشد.", 404);
    await logActivity(me!.id, me!.fullName, "ویرایش قرارگاه", `قرارگاه «${row.name}» به‌روزرسانی شد.`);
    return ok(row);
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "bases")) return fail("دسترسی مدیریت قرارگاه‌ها را ندارید.", 403);
    const { id } = await ctx.params;
    const url = new URL(req.url);
    const memberUserId = url.searchParams.get("userId");

    if (memberUserId) {
      // حذف یک عضو
      const uid = Number(memberUserId);
      const [target] = await db.select().from(users).where(eq(users.id, uid)).limit(1);
      await db
        .delete(baseMembers)
        .where(and(eq(baseMembers.baseId, Number(id)), eq(baseMembers.userId, uid)));
      await logActivity(me!.id, me!.fullName, "حذف عضو قرارگاه", `«${target?.fullName ?? uid}» از قرارگاه حذف شد.`);
      return ok({ message: "عضو حذف شد." });
    }

    const [row] = await db.delete(bases).where(eq(bases.id, Number(id))).returning();
    if (!row) return fail("قرارگاه یافت نشد.", 404);
    await logActivity(me!.id, me!.fullName, "حذف قرارگاه", `قرارگاه «${row.name}» حذف شد.`);
    return ok({ message: "قرارگاه حذف شد." });
  } catch (e) {
    return handleError(e);
  }
}

const addMemberSchema = z.object({ userId: z.number().int().positive() });

export async function POST(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "bases")) return fail("دسترسی مدیریت قرارگاه‌ها را ندارید.", 403);
    const { id } = await ctx.params;
    const baseId = Number(id);
    const body = addMemberSchema.parse(await req.json());

    const [base] = await db.select().from(bases).where(eq(bases.id, baseId)).limit(1);
    if (!base) return fail("قرارگاه یافت نشد.", 404);
    const [target] = await db.select().from(users).where(eq(users.id, body.userId)).limit(1);
    if (!target || target.role === "superadmin") return fail("دانش‌آموز یافت نشد.", 404);

    await db.insert(baseMembers).values({ baseId, userId: body.userId }).onConflictDoNothing();
    await logActivity(me!.id, me!.fullName, "افزودن عضو قرارگاه", `«${target.fullName}» به ${base.name} اضافه شد.`);
    return ok({ message: "عضو اضافه شد." });
  } catch (e) {
    return handleError(e);
  }
}
