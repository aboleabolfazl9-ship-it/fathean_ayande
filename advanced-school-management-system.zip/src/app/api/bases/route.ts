import { z } from "zod";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { baseMembers, bases, classes, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

/** فهرست قرارگاه‌ها به‌همراه اعضا — برای کاربران واردشده */
export async function GET() {
  try {
    const me = await getSessionUser();
    if (!me) return fail("ابتدا وارد شوید.", 401);

    const baseRows = await db.select().from(bases).orderBy(asc(bases.id));
    const memberRows = await db
      .select({
        baseId: baseMembers.baseId,
        id: users.id,
        fullName: users.fullName,
        className: classes.name,
        avatarColor: users.avatarColor,
        avatarUrl: users.avatarUrl,
      })
      .from(baseMembers)
      .innerJoin(users, eq(users.id, baseMembers.userId))
      .leftJoin(classes, eq(classes.id, users.classId))
      .orderBy(asc(users.fullName));

    return ok(
      baseRows.map((b) => ({
        id: b.id,
        slug: b.slug,
        name: b.name,
        managerName: b.managerName,
        managerUserId: b.managerUserId,
        description: b.description,
        icon: b.icon,
        hue: b.hue,
        members: memberRows
          .filter((m) => m.baseId === b.id)
          .map((m) => ({
            id: m.id,
            fullName: m.fullName,
            className: m.className,
            avatarColor: m.avatarColor,
            avatarUrl: m.avatarUrl,
          })),
      })),
    );
  } catch (e) {
    return handleError(e);
  }
}

const createSchema = z.object({
  name: z.string().trim().min(3, "نام قرارگاه را وارد کنید.").max(80),
  managerName: z.string().trim().min(3, "نام مدیر را وارد کنید.").max(140),
  description: z.string().trim().max(800).optional().default(""),
  icon: z.string().trim().max(40).optional().default("shield"),
  hue: z.string().trim().max(40).optional().default("blue"),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "bases")) return fail("دسترسی مدیریت قرارگاه‌ها را ندارید.", 403);
    const body = createSchema.parse(await req.json());
    const slug = `base-${Date.now().toString(36)}`;
    const [row] = await db.insert(bases).values({ ...body, slug }).returning();
    await logActivity(me!.id, me!.fullName, "ایجاد قرارگاه", `قرارگاه «${body.name}» ایجاد شد.`);
    return ok(row);
  } catch (e) {
    return handleError(e);
  }
}
