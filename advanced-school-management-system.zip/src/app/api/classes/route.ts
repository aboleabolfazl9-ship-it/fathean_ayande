import { z } from "zod";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

/** لیست کلاس‌ها + تعداد دانش‌آموز (برای عموم واردشده‌ها و ثبت‌نام آزاد است) */
export async function GET() {
  const rows = await db
    .select({
      id: classes.id,
      name: classes.name,
      code: classes.code,
      studentCount: sql<number>`(select count(*)::int from ${users} where ${users.classId} = ${classes.id} and ${users.role} != 'superadmin')`,
    })
    .from(classes)
    .orderBy(desc(classes.code));
  return ok(rows.sort((a, b) => a.code.localeCompare(b.code)));
}

const createSchema = z.object({
  name: z.string().trim().min(2, "نام کلاس را وارد کنید.").max(40),
  code: z.string().trim().min(1, "کد کلاس را وارد کنید.").max(8),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const user = await getSessionUser();
    if (!hasPerm(user, "classes")) return fail("دسترسی مدیریت کلاس‌ها را ندارید.", 403);
    const body = createSchema.parse(await req.json());

    const dup = await db.select({ id: classes.id }).from(classes).where(eq(classes.name, body.name)).limit(1);
    if (dup.length) return fail("کلاسی با این نام وجود دارد.", 409);

    const [row] = await db.insert(classes).values(body).returning();
    await logActivity(user!.id, user!.fullName, "ایجاد کلاس", `کلاس «${body.name}» ایجاد شد.`);
    return ok(row);
  } catch (e) {
    return handleError(e);
  }
}
