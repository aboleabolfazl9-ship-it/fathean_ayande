import { z } from "zod";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  name: z.string().trim().min(2).max(40).optional(),
  code: z.string().trim().min(1).max(8).optional(),
});

export async function PATCH(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const user = await getSessionUser();
    if (!hasPerm(user, "classes")) return fail("دسترسی مدیریت کلاس‌ها را ندارید.", 403);
    const { id } = await ctx.params;
    const clsId = Number(id);
    const body = patchSchema.parse(await req.json());

    const [row] = await db.update(classes).set(body).where(eq(classes.id, clsId)).returning();
    if (!row) return fail("کلاس یافت نشد.", 404);
    await logActivity(user!.id, user!.fullName, "ویرایش کلاس", `کلاس «${row.name}» به‌روزرسانی شد.`);
    return ok(row);
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const user = await getSessionUser();
    if (!hasPerm(user, "classes")) return fail("دسترسی مدیریت کلاس‌ها را ندارید.", 403);
    const { id } = await ctx.params;
    const clsId = Number(id);

    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(eq(users.classId, clsId));
    if (count > 0) {
      return fail("این کلاس دانش‌آموز دارد؛ ابتدا دانش‌آموزان را به کلاس دیگری منتقل کنید.", 409);
    }

    const [row] = await db.delete(classes).where(eq(classes.id, clsId)).returning();
    if (!row) return fail("کلاس یافت نشد.", 404);
    await logActivity(user!.id, user!.fullName, "حذف کلاس", `کلاس «${row.name}» حذف شد.`);
    return ok({ message: "کلاس حذف شد." });
  } catch (e) {
    return handleError(e);
  }
}
