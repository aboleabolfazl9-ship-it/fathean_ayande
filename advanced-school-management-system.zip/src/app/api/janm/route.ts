import { z } from "zod";
import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { janmTransactions, users } from "@/db/schema";
import { getSessionUser, hasPerm, isAdmin } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

const RULES = {
  absence: { amount: -10, label: "غیبت غیرموجه" },
  lateness: { amount: 0, label: "تأخیر در ورود به مدرسه" },
  lateness_penalty: { amount: -5, label: "سه بار تأخیر در ورود به مدرسه" },
  disorder: { amount: -2, label: "بی‌نظمی" },
} as const;

/** تاریخچه جنم — دانش‌آموز فقط سوابق خودش را می‌بیند */
export async function GET(req: Request) {
  try {
    const me = await getSessionUser();
    if (!me) return fail("ابتدا وارد شوید.", 401);
    const url = new URL(req.url);
    const userId = Number(url.searchParams.get("userId"));
    const limit = Math.min(Number(url.searchParams.get("limit")) || 50, 200);

    const where = isAdmin(me)
      ? userId
        ? eq(janmTransactions.userId, userId)
        : undefined // مدیر بدون userId همه را می‌بیند
      : eq(janmTransactions.userId, me.id); // دانش‌آموز فقط سوابق خودش

    const rows = await db
      .select({ t: janmTransactions, userName: users.fullName })
      .from(janmTransactions)
      .innerJoin(users, eq(users.id, janmTransactions.userId))
      .where(where)
      .orderBy(desc(janmTransactions.createdAt), desc(janmTransactions.id))
      .limit(limit);

    return ok(
      rows.map(({ t, userName }) => ({
        id: t.id,
        userId: t.userId,
        userName,
        amount: t.amount,
        kind: t.kind,
        reason: t.reason,
        note: t.note,
        actorName: t.actorName,
        status: t.status,
        correctsId: t.correctsId,
        createdAt: t.createdAt.toISOString(),
      })),
    );
  } catch (e) {
    return handleError(e);
  }
}

const postSchema = z.object({
  userIds: z.array(z.number().int().positive()).min(1, "حداقل یک دانش‌آموز انتخاب کنید.").max(120),
  mode: z.enum(["absence", "lateness", "disorder", "increase", "decrease"]),
  amount: z.coerce.number().int().min(1).max(1000).optional(),
  reason: z.string().trim().max(220).optional(),
  note: z.string().trim().max(500).optional().default(""),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "janm")) return fail("دسترسی مدیریت جنم را ندارید.", 403);
    const body = postSchema.parse(await req.json());

    if ((body.mode === "increase" || body.mode === "decrease") && !body.amount) {
      return fail("میزان جنم را وارد کنید.", 422);
    }

    const results: { userId: number; newJanm: number; penaltyApplied?: boolean }[] = [];

    for (const userId of body.userIds) {
      const [target] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
      if (!target || target.role === "superadmin") return fail(`دانش‌آموز با شناسه ${userId} یافت نشد.`, 404);

      let penaltyApplied = false;

      const newJanm = await db.transaction(async (tx) => {
        let delta = 0;

        if (body.mode === "lateness") {
          // ثبت رویداد تأخیر (بدون تغییر جنم)
          await tx.insert(janmTransactions).values({
            userId,
            amount: 0,
            kind: "lateness",
            reason: RULES.lateness.label,
            note: body.note,
            actorId: me!.id,
            actorName: me!.fullName,
          });
          // شمارش تأخیرهای فعال این دانش‌آموز
          const [{ count }] = await tx
            .select({ count: sql<number>`count(*)::int` })
            .from(janmTransactions)
            .where(
              and(
                eq(janmTransactions.userId, userId),
                eq(janmTransactions.kind, "lateness"),
                eq(janmTransactions.status, "active"),
              ),
            );
          if (count % 3 === 0) {
            await tx.insert(janmTransactions).values({
              userId,
              amount: RULES.lateness_penalty.amount,
              kind: "lateness_penalty",
              reason: RULES.lateness_penalty.label,
              note: body.note,
              actorId: me!.id,
              actorName: me!.fullName,
            });
            delta += RULES.lateness_penalty.amount;
            penaltyApplied = true;
          }
        } else if (body.mode === "absence" || body.mode === "disorder") {
          const rule = RULES[body.mode];
          await tx.insert(janmTransactions).values({
            userId,
            amount: rule.amount,
            kind: body.mode,
            reason: rule.label,
            note: body.note,
            actorId: me!.id,
            actorName: me!.fullName,
          });
          delta = rule.amount;
        } else {
          const amt = body.mode === "increase" ? body.amount! : -body.amount!;
          const reason =
            body.reason?.trim() || (body.mode === "increase" ? "افزایش جنم" : "کاهش جنم");
          await tx.insert(janmTransactions).values({
            userId,
            amount: amt,
            kind: "manual",
            reason,
            note: body.note,
            actorId: me!.id,
            actorName: me!.fullName,
          });
          delta = amt;
        }

        const [updated] = await tx
          .update(users)
          .set({ janm: sql`${users.janm} + ${delta}` })
          .where(eq(users.id, userId))
          .returning({ janm: users.janm });
        return updated.janm;
      });

      results.push({ userId, newJanm, penaltyApplied });
      await logActivity(
        me!.id,
        me!.fullName,
        "ثبت جنم",
        `${target.fullName}: ${body.mode}${penaltyApplied ? " (با جریمه سه تأخیر)" : ""}`,
      );
    }

    return ok({ results });
  } catch (e) {
    return handleError(e);
  }
}

/** اصلاح تراکنش: ابطال با ثبت سابقه اصلاح (حذف نمی‌شود) */
const patchSchema = z.object({
  id: z.number().int().positive(),
  note: z.string().trim().max(300).optional().default(""),
});

export async function PATCH(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "janm")) return fail("دسترسی مدیریت جنم را ندارید.", 403);
    const body = patchSchema.parse(await req.json());

    const [original] = await db.select().from(janmTransactions).where(eq(janmTransactions.id, body.id)).limit(1);
    if (!original) return fail("تراکنش یافت نشد.", 404);
    if (original.status !== "active") return fail("این تراکنش قبلاً اصلاح شده است.", 409);

    await db.transaction(async (tx) => {
      await tx
        .update(janmTransactions)
        .set({ status: "corrected" })
        .where(eq(janmTransactions.id, original.id));
      await tx.insert(janmTransactions).values({
        userId: original.userId,
        amount: -original.amount,
        kind: "correction",
        reason: `اصلاح: ${original.reason}`,
        note: body.note || "ابطال تراکنش اشتباه",
        actorId: me!.id,
        actorName: me!.fullName,
        correctsId: original.id,
      });
      if (original.amount !== 0) {
        await tx
          .update(users)
          .set({ janm: sql`${users.janm} - ${original.amount}` })
          .where(eq(users.id, original.userId));
      }
    });

    await logActivity(me!.id, me!.fullName, "اصلاح تراکنش جنم", `تراکنش #${original.id} ابطال و اصلاح شد.`);
    return ok({ message: "تراکنش اصلاح شد و سابقه اصلاح ثبت گردید." });
  } catch (e) {
    return handleError(e);
  }
}
