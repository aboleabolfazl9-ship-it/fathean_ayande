import { and, desc, eq, gte, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  activityLogs,
  announcements,
  classes,
  janmTransactions,
  passwordResets,
  users,
} from "@/db/schema";
import { getSessionUser, isAdmin } from "@/lib/auth";
import { ok, fail, handleError } from "@/lib/api";

export async function GET() {
  try {
    const me = await getSessionUser();
    if (!isAdmin(me)) return fail("دسترسی ندارید.", 403);

    const [studentCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(and(ne(users.role, "superadmin"), eq(users.isApproved, true)));
    const [pendingUsers] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(and(ne(users.role, "superadmin"), eq(users.isApproved, false)));
    const [classCount] = await db.select({ count: sql<number>`count(*)::int` }).from(classes);
    const [janmSum] = await db
      .select({ sum: sql<number>`coalesce(sum(${users.janm}),0)::int` })
      .from(users)
      .where(ne(users.role, "superadmin"));
    const [txCount] = await db.select({ count: sql<number>`count(*)::int` }).from(janmTransactions);
    const [announcementCount] = await db.select({ count: sql<number>`count(*)::int` }).from(announcements);
    const [pendingResetCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(passwordResets)
      .where(eq(passwordResets.status, "pending"));

    const recentTx = await db
      .select({ t: janmTransactions, userName: users.fullName })
      .from(janmTransactions)
      .innerJoin(users, eq(users.id, janmTransactions.userId))
      .orderBy(desc(janmTransactions.createdAt), desc(janmTransactions.id))
      .limit(8);

    const recentLogs = await db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(8);

    const violations = await db
      .select({ kind: janmTransactions.kind, count: sql<number>`count(*)::int` })
      .from(janmTransactions)
      .where(eq(janmTransactions.status, "active"))
      .groupBy(janmTransactions.kind);

    const since = new Date(Date.now() - 13 * 24 * 60 * 60 * 1000);
    since.setHours(0, 0, 0, 0);
    const daily = await db
      .select({
        day: sql<string>`to_char(${janmTransactions.createdAt} at time zone 'UTC', 'YYYY-MM-DD')`,
        total: sql<number>`coalesce(sum(${janmTransactions.amount}),0)::int`,
      })
      .from(janmTransactions)
      .where(and(gte(janmTransactions.createdAt, since), eq(janmTransactions.status, "active")))
      .groupBy(sql`1`)
      .orderBy(sql`1`);

    const topStudents = await db
      .select({ id: users.id, fullName: users.fullName, janm: users.janm, avatarColor: users.avatarColor })
      .from(users)
      .where(and(ne(users.role, "superadmin"), eq(users.isApproved, true)))
      .orderBy(desc(users.janm))
      .limit(5);

    return ok({
      stats: {
        students: studentCount.count,
        classes: classCount.count,
        totalJanm: janmSum.sum,
        transactions: txCount.count,
        announcements: announcementCount.count,
        pendingUsers: pendingUsers.count,
        pendingResets: pendingResetCount.count,
      },
      recentTx: recentTx.map(({ t, userName }) => ({
        id: t.id,
        userId: t.userId,
        userName,
        amount: t.amount,
        kind: t.kind,
        reason: t.reason,
        note: t.note,
        actorName: t.actorName,
        status: t.status,
        correctsId: t.correctsId,
        createdAt: t.createdAt.toISOString(),
      })),
      recentLogs: recentLogs.map((l) => ({
        id: l.id,
        actorName: l.actorName,
        action: l.action,
        detail: l.detail,
        createdAt: l.createdAt.toISOString(),
      })),
      violations: Object.fromEntries(violations.map((v) => [v.kind, v.count])),
      dailyJanm: daily,
      topStudents,
    });
  } catch (e) {
    return handleError(e);
  }
}
