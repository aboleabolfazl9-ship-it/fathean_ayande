import { desc } from "drizzle-orm";
import { db } from "@/db";
import { activityLogs } from "@/db/schema";
import { getSessionUser, isAdmin } from "@/lib/auth";
import { ok, fail, handleError } from "@/lib/api";

export async function GET() {
  try {
    const me = await getSessionUser();
    if (!isAdmin(me)) return fail("دسترسی ندارید.", 403);
    const rows = await db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(80);
    return ok(
      rows.map((l) => ({
        id: l.id,
        actorName: l.actorName,
        action: l.action,
        detail: l.detail,
        createdAt: l.createdAt.toISOString(),
      })),
    );
  } catch (e) {
    return handleError(e);
  }
}
