import { z } from "zod";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { getSessionUser, isSuperAdmin } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

/** فهرست مدیران و سطح دسترسی — فقط مدیر اصلی */
export async function GET() {
  try {
    const me = await getSessionUser();
    if (!isSuperAdmin(me)) return fail("فقط مدیر اصلی به این بخش دسترسی دارد.", 403);
    const rows = await db
      .select({
        id: users.id,
        fullName: users.fullName,
        username: users.username,
        role: users.role,
        title: users.title,
        permissions: users.permissions,
        className: classes.name,
      })
      .from(users)
      .leftJoin(classes, eq(classes.id, users.classId))
      .orderBy(asc(users.role), asc(users.fullName));
    return ok(
      rows
        .filter((r) => r.role !== "superadmin")
        .map((r) => ({
          id: r.id,
          fullName: r.fullName,
          username: r.username,
          role: r.role,
          title: r.title,
          permissions: r.permissions,
          className: r.className,
        })),
    );
  } catch (e) {
    return handleError(e);
  }
}

const patchSchema = z.object({
  userId: z.number().int().positive(),
  action: z.enum(["grant", "revoke"]),
  permissions: z.array(z.string()).max(10).optional().default([]),
});

export async function PATCH(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!isSuperAdmin(me)) return fail("فقط مدیر اصلی می‌تواند سطح دسترسی را تعیین کند.", 403);
    const body = patchSchema.parse(await req.json());

    const [target] = await db.select().from(users).where(eq(users.id, body.userId)).limit(1);
    if (!target || target.role === "superadmin") return fail("کاربر یافت نشد.", 404);
    if (target.id === me!.id) return fail("نمی‌توانید سطح دسترسی خودتان را تغییر دهید.", 403);

    if (body.action === "grant") {
      await db
        .update(users)
        .set({ role: "admin", permissions: body.permissions })
        .where(eq(users.id, target.id));
      await logActivity(me!.id, me!.fullName, "اعطای دسترسی مدیریت", `به «${target.fullName}» دسترسی مدیریت داده شد.`);
      return ok({ message: `دسترسی مدیریت به «${target.fullName}» اعطا شد.` });
    }

    await db.update(users).set({ role: "student", permissions: null }).where(eq(users.id, target.id));
    await logActivity(me!.id, me!.fullName, "لغو دسترسی مدیریت", `دسترسی مدیریت «${target.fullName}» لغو شد.`);
    return ok({ message: `دسترسی مدیریت «${target.fullName}» لغو شد.` });
  } catch (e) {
    return handleError(e);
  }
}
