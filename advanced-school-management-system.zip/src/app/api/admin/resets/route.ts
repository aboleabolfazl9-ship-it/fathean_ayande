import { z } from "zod";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { hashPassword, randomTempPassword } from "@/lib/crypto";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

export async function GET() {
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "students")) return fail("دسترسی ندارید.", 403);
    const rows = await db.select().from(passwordResets).orderBy(desc(passwordResets.createdAt)).limit(50);
    return ok(
      rows.map((r) => ({
        id: r.id,
        username: r.username,
        fullName: r.fullName,
        note: r.note,
        status: r.status,
        handledByName: r.handledByName,
        createdAt: r.createdAt.toISOString(),
      })),
    );
  } catch (e) {
    return handleError(e);
  }
}

const patchSchema = z.object({
  id: z.number().int().positive(),
  action: z.enum(["approve", "reject"]),
});

export async function PATCH(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "students")) return fail("دسترسی ندارید.", 403);
    const body = patchSchema.parse(await req.json());

    const [request] = await db.select().from(passwordResets).where(eq(passwordResets.id, body.id)).limit(1);
    if (!request) return fail("درخواست یافت نشد.", 404);
    if (request.status !== "pending") return fail("این درخواست قبلاً رسیدگی شده است.", 409);

    if (body.action === "reject") {
      await db
        .update(passwordResets)
        .set({ status: "rejected", handledByName: me!.fullName, handledAt: new Date() })
        .where(eq(passwordResets.id, body.id));
      await logActivity(me!.id, me!.fullName, "رد درخواست بازیابی رمز", `درخواست ${request.username} رد شد.`);
      return ok({ message: "درخواست رد شد." });
    }

    const [target] = await db.select().from(users).where(eq(users.username, request.username)).limit(1);
    if (!target) return fail("حساب کاربری مربوط به این درخواست یافت نشد.", 404);

    const tempPassword = randomTempPassword();
    await db.transaction(async (tx) => {
      await tx.update(users).set({ passwordHash: hashPassword(tempPassword) }).where(eq(users.id, target.id));
      await tx
        .update(passwordResets)
        .set({ status: "done", handledByName: me!.fullName, handledAt: new Date() })
        .where(eq(passwordResets.id, body.id));
    });
    await logActivity(me!.id, me!.fullName, "تأیید بازیابی رمز", `رمز جدید برای «${target.fullName}» صادر شد.`);
    // رمز موقت فقط یک‌بار به مدیر نمایش داده می‌شود
    return ok({ tempPassword, username: target.username });
  } catch (e) {
    return handleError(e);
  }
}
