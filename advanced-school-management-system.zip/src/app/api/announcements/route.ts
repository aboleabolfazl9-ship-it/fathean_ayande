import { z } from "zod";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { announcements } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

export async function GET() {
  try {
    const me = await getSessionUser();
    if (!me) return fail("ابتدا وارد شوید.", 401);
    const rows = await db.select().from(announcements).orderBy(desc(announcements.createdAt)).limit(60);
    return ok(
      rows.map((a) => ({
        id: a.id,
        title: a.title,
        body: a.body,
        createdByName: a.createdByName ?? "مدیر",
        createdAt: a.createdAt.toISOString(),
        updatedAt: a.updatedAt?.toISOString() ?? null,
      })),
    );
  } catch (e) {
    return handleError(e);
  }
}

const createSchema = z.object({
  title: z.string().trim().min(3, "عنوان اطلاعیه را وارد کنید.").max(180),
  body: z.string().trim().min(5, "متن اطلاعیه را وارد کنید.").max(4000),
});

export async function POST(req: Request) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "content")) return fail("دسترسی انتشار اطلاعیه را ندارید.", 403);
    const body = createSchema.parse(await req.json());

    const [row] = await db
      .insert(announcements)
      .values({ title: body.title, body: body.body, createdById: me!.id, createdByName: me!.fullName })
      .returning();
    await logActivity(me!.id, me!.fullName, "انتشار اطلاعیه", `اطلاعیه «${body.title}» منتشر شد.`);
    return ok({ id: row.id });
  } catch (e) {
    return handleError(e);
  }
}
