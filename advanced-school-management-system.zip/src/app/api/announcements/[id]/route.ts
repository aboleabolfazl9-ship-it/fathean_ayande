import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { announcements } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import { ok, fail, csrfGuard, handleError, logActivity } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  title: z.string().trim().min(3).max(180).optional(),
  body: z.string().trim().min(5).max(4000).optional(),
});

export async function PATCH(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "content")) return fail("دسترسی ویرایش اطلاعیه را ندارید.", 403);
    const { id } = await ctx.params;
    const body = patchSchema.parse(await req.json());
    if (!body.title && !body.body) return fail("تغییری ارسال نشد.", 422);

    const [row] = await db
      .update(announcements)
      .set({ ...(body.title ? { title: body.title } : {}), ...(body.body ? { body: body.body } : {}), updatedAt: new Date() })
      .where(eq(announcements.id, Number(id)))
      .returning();
    if (!row) return fail("اطلاعیه یافت نشد.", 404);
    await logActivity(me!.id, me!.fullName, "ویرایش اطلاعیه", `اطلاعیه «${row.title}» ویرایش شد.`);
    return ok({ id: row.id });
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request, ctx: Ctx) {
  const blocked = csrfGuard(req);
  if (blocked) return blocked;
  try {
    const me = await getSessionUser();
    if (!hasPerm(me, "content")) return fail("دسترسی حذف اطلاعیه را ندارید.", 403);
    const { id } = await ctx.params;
    const [row] = await db.delete(announcements).where(eq(announcements.id, Number(id))).returning();
    if (!row) return fail("اطلاعیه یافت نشد.", 404);
    await logActivity(me!.id, me!.fullName, "حذف اطلاعیه", `اطلاعیه «${row.title}» حذف شد.`);
    return ok({ message: "اطلاعیه حذف شد." });
  } catch (e) {
    return handleError(e);
  }
}
