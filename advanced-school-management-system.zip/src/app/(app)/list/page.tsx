import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { asc, desc, eq, ne, and } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { getSessionUser, isAdmin } from "@/lib/auth";
import ListClient from "./list-client";
import type { StudentBrief } from "@/lib/types";

export const metadata: Metadata = { title: "لیست مدرسه" };

export default async function SchoolListPage() {
  const me = await getSessionUser();
  if (!me) redirect("/login");

  const rows = await db
    .select({ u: users, className: classes.name, classCode: classes.code })
    .from(users)
    .leftJoin(classes, eq(classes.id, users.classId))
    .where(and(ne(users.role, "superadmin"), eq(users.isApproved, true)))
    .orderBy(desc(users.janm), asc(users.fullName));

  let rank = 0;
  let prev: number | null = null;
  const students: StudentBrief[] = rows.map((r, i) => {
    if (prev === null || r.u.janm !== prev) {
      rank = i + 1;
      prev = r.u.janm;
    }
    return {
      id: r.u.id,
      fullName: r.u.fullName,
      username: r.u.username,
      classId: r.u.classId,
      className: r.className,
      classCode: r.classCode,
      role: r.u.role,
      title: r.u.title,
      janm: r.u.janm,
      isApproved: r.u.isApproved,
      isBlocked: r.u.isBlocked,
      avatarColor: r.u.avatarColor,
      avatarUrl: r.u.avatarUrl,
      rank,
    };
  });

  const classRows = await db.select().from(classes).orderBy(asc(classes.code));

  return (
    <ListClient
      students={students}
      classes={classRows.map((c) => ({ id: c.id, name: c.name, code: c.code }))}
      meId={me.id}
      canManage={isAdmin(me)}
    />
  );
}
