"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "motion/react";
import { Search, ListOrdered, Users } from "lucide-react";
import { Avatar, EmptyState, PageHeader, RankBadge, TitleBadge } from "@/components/ui";
import { fa, faNum } from "@/lib/format";
import type { ClassItem, StudentBrief } from "@/lib/types";

const SORTS = [
  { key: "rank", label: "بیشترین جنم" },
  { key: "rankAsc", label: "کمترین جنم" },
  { key: "name", label: "الفبا" },
] as const;

export default function ListClient({
  students,
  classes,
  meId,
  canManage,
}: {
  students: StudentBrief[];
  classes: ClassItem[];
  meId: number;
  canManage: boolean;
}) {
  const [q, setQ] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [sort, setSort] = useState<(typeof SORTS)[number]["key"]>("rank");

  const filtered = useMemo(() => {
    let list = students;
    if (classFilter !== "all") list = list.filter((s) => String(s.classId) === classFilter);
    if (q.trim()) list = list.filter((s) => s.fullName.includes(q.trim()) || s.username.includes(q.trim().toLowerCase()));
    const sorted = [...list];
    if (sort === "rank") sorted.sort((a, b) => (b.janm - a.janm) || a.fullName.localeCompare(b.fullName, "fa"));
    if (sort === "rankAsc") sorted.sort((a, b) => (a.janm - b.janm) || a.fullName.localeCompare(b.fullName, "fa"));
    if (sort === "name") sorted.sort((a, b) => a.fullName.localeCompare(b.fullName, "fa"));
    return sorted;
  }, [students, q, classFilter, sort]);

  const top3 = useMemo(() => {
    if (q.trim() || classFilter !== "all") return [];
    return [...students].sort((a, b) => b.janm - a.janm).slice(0, 3);
  }, [students, q, classFilter]);

  const showPodium = top3.length === 3 && top3.some((s) => s.janm !== 0);

  return (
    <div>
      <PageHeader
        title="لیست مدرسه"
        subtitle={`${fa(students.length)} دانش‌آموز • رتبه‌بندی بر اساس میزان جنم — به‌روزرسانی خودکار`}
        icon={<ListOrdered size={22} />}
      />

      {/* سکوی افتخار */}
      {showPodium && (
        <div className="rise mb-6 grid grid-cols-3 items-end gap-3 sm:gap-5">
          {[top3[1], top3[0], top3[2]].map((s, i) => {
            const place = i === 1 ? 1 : i === 0 ? 2 : 3;
            const height = place === 1 ? "pt-8 pb-7" : "pt-6 pb-5";
            const ring =
              place === 1
                ? "0 0 0 2px var(--bg), 0 0 0 4px rgba(231,189,85,.7)"
                : place === 2
                  ? "0 0 0 2px var(--bg), 0 0 0 4px rgba(148,163,184,.6)"
                  : "0 0 0 2px var(--bg), 0 0 0 4px rgba(180,120,60,.55)";
            return (
              <motion.div
                key={s.id}
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: place * 0.08 }}
              >
                <Link
                  href={`/students/${s.id}`}
                  className={`panel group flex flex-col items-center ${height} relative overflow-hidden px-2 text-center transition hover:border-[var(--border-strong)]`}
                >
                  {place === 1 && (
                    <div
                      className="pointer-events-none absolute inset-0"
                      style={{ background: "radial-gradient(240px 120px at 50% 0%, rgba(231,189,85,.16), transparent 70%)" }}
                    />
                  )}
                  <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={place === 1 ? 64 : 52} className="shadow-soft" />
                  <span
                    className="absolute top-3 right-3 flex h-7 w-7 items-center justify-center rounded-xl text-[0.72rem] font-black"
                    style={{
                      background:
                        place === 1
                          ? "linear-gradient(150deg,#f6dd9a,#caa038)"
                          : place === 2
                            ? "linear-gradient(150deg,#e2e8f0,#94a3b8)"
                            : "linear-gradient(150deg,#e8b98a,#a06a35)",
                      color: "#1a1206",
                      boxShadow: ring.includes("231,189") ? "" : undefined,
                    }}
                  >
                    {fa(place)}
                  </span>
                  <div className="relative mt-3 max-w-full truncate text-[0.8rem] font-extrabold sm:text-sm">{s.fullName}</div>
                  <div className="text-faint mt-0.5 text-[0.66rem] font-bold">{s.className}</div>
                  <div className={`mt-2 text-lg font-black sm:text-xl ${place === 1 ? "gold-text" : ""}`} dir="ltr">
                    {faNum(s.janm)}
                  </div>
                  <div className="text-faint text-[0.6rem] font-bold">جنم</div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* ابزار فیلتر */}
      <div className="panel rise rise-1 mb-4 flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={16} className="text-faint absolute top-1/2 right-3 -translate-y-1/2" />
          <input
            className="input pe-10"
            placeholder="جست‌وجوی دانش‌آموز…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <select className="select sm:w-44" value={classFilter} onChange={(e) => setClassFilter(e.target.value)}>
          <option value="all">همه کلاس‌ها</option>
          {classes.map((c) => (
            <option key={c.id} value={String(c.id)}>
              {c.name}
            </option>
          ))}
        </select>
        <select className="select sm:w-40" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)}>
          {SORTS.map((s) => (
            <option key={s.key} value={s.key}>
              {s.label}
            </option>
          ))}
        </select>
      </div>

      {/* جدول */}
      <div className="panel rise rise-2 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="table-pro min-w-[560px]">
            <thead>
              <tr>
                <th className="w-16">رتبه</th>
                <th>نام و نام خانوادگی</th>
                <th>کلاس</th>
                <th className="text-left!">جنم</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence initial={false}>
                {filtered.map((s) => (
                  <motion.tr
                    key={s.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    style={s.id === meId ? { background: "rgba(231,189,85,.06)" } : undefined}
                  >
                    <td>
                      <RankBadge rank={s.rank ?? 0} />
                    </td>
                    <td>
                      <Link href={`/students/${s.id}`} className="group flex items-center gap-3">
                        <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={36} />
                        <span className="min-w-0">
                          <span className="flex flex-wrap items-center gap-2">
                            <span className="truncate font-bold transition group-hover:text-[var(--gold)]">
                              {s.fullName}
                            </span>
                            {s.title && <TitleBadge title={s.title} />}
                            {s.isBlocked && <span className="badge badge-red">مسدود</span>}
                            {s.id === meId && <span className="badge badge-gold">شما</span>}
                          </span>
                        </span>
                      </Link>
                    </td>
                    <td>
                      <span className="badge">{s.className ?? "—"}</span>
                    </td>
                    <td className="text-left!">
                      <span className="text-base font-black" dir="ltr" style={{ color: s.janm > 0 ? "var(--gold)" : s.janm < 0 ? "var(--danger)" : "var(--muted)" }}>
                        {faNum(s.janm)}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <EmptyState icon={<Users size={26} />} title="دانش‌آموزی یافت نشد" hint="عبارت جست‌وجو یا فیلتر کلاس را تغییر دهید." />
        )}
      </div>

      {canManage && (
        <p className="text-faint rise rise-3 mt-4 text-center text-[0.68rem] font-semibold">
          در حالت مدیریت، برای تغییر جنم یا ویرایش، روی نام دانش‌آموز کلیک کنید.
        </p>
      )}
    </div>
  );
}
