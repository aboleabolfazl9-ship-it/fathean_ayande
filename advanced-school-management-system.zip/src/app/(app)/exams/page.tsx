import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { exams } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import ExamsClient from "./exams-client";
import type { ExamItem } from "@/lib/types";

export const metadata: Metadata = { title: "برنامه امتحانات" };

export default async function ExamsPage() {
  const me = await getSessionUser();
  if (!me) redirect("/login");

  const rows = await db.select().from(exams).orderBy(asc(exams.examDate));
  const items: ExamItem[] = rows.map((e) => ({
    id: e.id,
    title: e.title,
    description: e.description,
    examDate: e.examDate.toISOString(),
  }));

  return <ExamsClient exams={items} canManage={hasPerm(me, "exams")} />;
}
