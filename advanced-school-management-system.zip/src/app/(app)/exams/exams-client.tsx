"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "motion/react";
import { CalendarClock, Check, LoaderCircle, Pencil, Plus, Trash2 } from "lucide-react";
import { EmptyState, PageHeader } from "@/components/ui";
import { Modal } from "@/components/modal";
import { useToast } from "@/components/providers";
import { fa, faDate, faWeekday, todayJalali, faDateInputValue } from "@/lib/format";
import * as jalaali from "jalaali-js";
import type { ExamItem } from "@/lib/types";

function jalaliParts(iso: string) {
  const d = new Date(iso);
  return jalaali.toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

function daysUntil(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  const a = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const b = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((a.getTime() - b.getTime()) / 86400000);
}

export default function ExamsClient({ exams, canManage }: { exams: ExamItem[]; canManage: boolean }) {
  const router = useRouter();
  const toast = useToast();
  const [modal, setModal] = useState<"none" | "add" | "edit">("none");
  const [deleting, setDeleting] = useState<ExamItem | null>(null);
  const [target, setTarget] = useState<ExamItem | null>(null);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [date, setDate] = useState("");
  const [busy, setBusy] = useState(false);

  const today = todayJalali();

  function openAdd() {
    setTitle("");
    setDesc("");
    setDate(`${today.jy}/`);
    setModal("add");
  }
  function openEdit(e: ExamItem) {
    setTarget(e);
    setTitle(e.title);
    setDesc(e.description);
    setDate(faDateInputValue(e.examDate));
    setModal("edit");
  }

  function toEnDigits(s: string) {
    return s.replace(/[۰-۹]/g, (ch) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(ch)));
  }

  async function save() {
    if (busy) return;
    setBusy(true);
    try {
      const isEdit = modal === "edit" && target;
      const res = await fetch(isEdit ? `/api/exams/${target!.id}` : "/api/exams", {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description: desc, date: toEnDigits(date) }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا در ذخیره");
      toast.push("success", isEdit ? "امتحان ویرایش شد." : "امتحان جدید ثبت شد.");
      setModal("none");
      setTarget(null);
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!deleting || busy) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/exams/${deleting.id}`, { method: "DELETE", headers: { "Content-Type": "application/json" } });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا در حذف");
      toast.push("success", "امتحان حذف شد.");
      setDeleting(null);
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="برنامه امتحانات"
        subtitle="تاریخ‌های رسمی ارزشیابی مدرسه"
        icon={<CalendarClock size={22} />}
      >
        {canManage && (
          <button onClick={openAdd} className="btn btn-primary">
            <Plus size={16} />
            افزودن امتحان
          </button>
        )}
      </PageHeader>

      {exams.length === 0 ? (
        <div className="panel rise">
          <EmptyState
            icon={<CalendarClock size={26} />}
            title="امتحانی ثبت نشده است"
            hint="وقتی مدیر امتحانی ثبت کند، اینجا نمایش داده می‌شود."
          />
        </div>
      ) : (
        <div className="relative">
          <div className="absolute top-2 bottom-2 right-[27px] w-px sm:right-[35px]" style={{ background: "linear-gradient(var(--border-strong), transparent)" }} />
          <div className="space-y-5">
            {exams.map((e, i) => {
              const j = jalaliParts(e.examDate);
              const dLeft = daysUntil(e.examDate);
              return (
                <motion.div
                  key={e.id}
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className="relative flex items-start gap-4 pe-2 sm:gap-5"
                >
                  {/* نشان تاریخ */}
                  <div className="panel shadow-soft relative z-10 flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-2xl sm:h-[70px] sm:w-[70px]">
                    <span className="gold-text text-lg leading-none font-black sm:text-2xl">{fa(j.jd)}</span>
                    <span className="text-faint mt-1 text-[0.58rem] font-bold sm:text-[0.66rem]">
                      {["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"][j.jm - 1]}
                    </span>
                  </div>

                  <div className="panel flex-1 p-5 transition hover:border-[var(--border-strong)]">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h3 className="text-[0.95rem] font-extrabold">{e.title}</h3>
                      <div className="flex items-center gap-2">
                        <span className={`badge ${dLeft < 0 ? "" : dLeft <= 7 ? "badge-red" : "badge-blue"}`}>
                          {dLeft > 0 ? `${fa(dLeft)} روز مانده` : dLeft === 0 ? "امروز" : "برگزار شد"}
                        </span>
                        {canManage && (
                          <>
                            <button onClick={() => openEdit(e)} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--gold)]" aria-label="ویرایش">
                              <Pencil size={14} />
                            </button>
                            <button onClick={() => setDeleting(e)} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--danger)]" aria-label="حذف">
                              <Trash2 size={14} />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="text-faint mt-1.5 text-[0.72rem] font-semibold">
                      {faWeekday(e.examDate)} • {faDate(e.examDate)}
                    </div>
                    {e.description && <p className="text-muted mt-2 text-[0.8rem] leading-7">{e.description}</p>}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {!canManage && exams.length > 0 && (
        <p className="text-faint rise mt-6 text-center text-[0.68rem] font-semibold">
          تاریخ‌ها توسط مدیریت مدرسه تنظیم می‌شوند؛ در صورت تغییر، همین صفحه به‌روزرسانی می‌شود.
        </p>
      )}

      {/* افزودن / ویرایش */}
      <Modal open={modal !== "none"} onClose={() => setModal("none")} title={modal === "edit" ? "ویرایش امتحان" : "افزودن امتحان جدید"}>
        <div className="space-y-4">
          <div>
            <label className="label">عنوان امتحان</label>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: امتحان مبتکران" />
          </div>
          <div>
            <label className="label">تاریخ (شمسی)</label>
            <input className="input" dir="ltr" style={{ textAlign: "left" }} value={date} onChange={(e) => setDate(e.target.value)} placeholder="1404/08/20" />
            <p className="text-faint mt-1.5 text-[0.66rem]">قالب: ۱۴۰۴/۰۸/۲۰</p>
          </div>
          <div>
            <label className="label">توضیحات</label>
            <textarea className="textarea" value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="جزئیات، حیطه و زمان برگزاری…" />
          </div>
          <button onClick={save} disabled={busy} className="btn btn-gold w-full">
            {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
            {modal === "edit" ? "ذخیره تغییرات" : "ثبت امتحان"}
          </button>
        </div>
      </Modal>

      {/* حذف */}
      <Modal open={deleting !== null} onClose={() => setDeleting(null)} title="حذف امتحان">
        <p className="text-muted text-sm leading-7">
          آیا از حذف امتحان «{deleting?.title}» مطمئن هستید؟ این عمل قابل بازگشت نیست.
        </p>
        <div className="mt-5 flex gap-2">
          <button onClick={() => setDeleting(null)} className="btn btn-ghost flex-1">
            انصراف
          </button>
          <button onClick={remove} disabled={busy} className="btn btn-danger flex-1">
            {busy ? <LoaderCircle size={15} className="animate-spin" /> : <Trash2 size={15} />}
            حذف قطعی
          </button>
        </div>
      </Modal>
    </div>
  );
}
