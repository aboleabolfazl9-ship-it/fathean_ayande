"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Crown, LoaderCircle, Lock, Search, ShieldOff, UserCog } from "lucide-react";
import { Avatar } from "@/components/ui";
import { Modal } from "@/components/modal";
import { useToast } from "@/components/providers";
import { PERMS } from "@/lib/permissions";
import { fa } from "@/lib/format";
import { apiCall } from "./shared";
import type { StudentBrief } from "@/lib/types";

type AccessRow = {
  id: number;
  fullName: string;
  username: string;
  role: string;
  title: string | null;
  permissions: string[] | null;
  className: string | null;
};

export default function AccessTab({ students, meId }: { students: StudentBrief[]; meId: number }) {
  const router = useRouter();
  const toast = useToast();
  const [rows, setRows] = useState<AccessRow[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [grantTarget, setGrantTarget] = useState<AccessRow | null>(null);
  const [grantPerms, setGrantPerms] = useState<string[]>(PERMS.map((p) => p.key));
  const [editPerms, setEditPerms] = useState<AccessRow | null>(null);
  const [editPermList, setEditPermList] = useState<string[]>([]);

  const load = async () => {
    const r = await apiCall("/api/admin/access");
    if (r.ok) setRows(r.data as AccessRow[]);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const admins = (rows ?? []).filter((r) => r.role === "admin");
  const candidates = (rows ?? []).filter(
    (r) => r.role === "student" && (!search.trim() || r.fullName.includes(search.trim())),
  );

  async function revoke(r: AccessRow) {
    if (busy) return;
    setBusy(true);
    const res = await apiCall("/api/admin/access", { method: "PATCH", body: JSON.stringify({ userId: r.id, action: "revoke" }) });
    setBusy(false);
    if (!res.ok) return toast.push("error", res.error!);
    toast.push("success", `دسترسی مدیریت «${r.fullName}» لغو شد.`);
    load();
    router.refresh();
  }

  async function grant() {
    if (!grantTarget || busy) return;
    setBusy(true);
    const res = await apiCall("/api/admin/access", {
      method: "PATCH",
      body: JSON.stringify({ userId: grantTarget.id, action: "grant", permissions: grantPerms }),
    });
    setBusy(false);
    if (!res.ok) return toast.push("error", res.error!);
    toast.push("success", `دسترسی مدیریت به «${grantTarget.fullName}» اعطا شد.`);
    setGrantTarget(null);
    load();
    router.refresh();
  }

  async function savePerms() {
    if (!editPerms || busy) return;
    setBusy(true);
    const res = await apiCall("/api/admin/access", {
      method: "PATCH",
      body: JSON.stringify({ userId: editPerms.id, action: "grant", permissions: editPermList }),
    });
    setBusy(false);
    if (!res.ok) return toast.push("error", res.error!);
    toast.push("success", "سطح دسترسی به‌روزرسانی شد.");
    setEditPerms(null);
    load();
    router.refresh();
  }

  function togglePerm(list: string[], key: string, set: (v: string[]) => void) {
    set(list.includes(key) ? list.filter((x) => x !== key) : [...list, key]);
  }

  return (
    <div className="space-y-5">
      <section className="panel border-[rgba(231,189,85,.35)] p-5" style={{ borderColor: "rgba(231,189,85,.4)" }}>
        <h3 className="flex items-center gap-2 text-sm font-extrabold text-[var(--gold)]">
          <Crown size={16} />
          سیاست دسترسی مدیریت
        </h3>
        <p className="text-muted mt-2 text-[0.76rem] leading-7">
          دارندگان «عنوان رسمی» (مانند مدیر ارشد یا مسئول آمار) به‌صورت خودکار دسترسی مدیریت ندارند؛ دسترسی فقط با مجوز مدیر
          اصلی از همین بخش فعال می‌شود و تمام بررسی‌ها سمت سرور انجام می‌گیرد.
        </p>
      </section>

      {/* مدیران فعلی */}
      <section className="panel p-5">
        <h3 className="mb-4 flex items-center justify-between text-sm font-extrabold">
          <span className="flex items-center gap-2">
            <UserCog size={16} style={{ color: "#8facff" }} />
            مدیران مجاز فعلی
          </span>
          {admins.length > 0 && <span className="badge badge-blue">{fa(admins.length)} نفر</span>}
        </h3>
        {rows === null ? (
          <div className="flex items-center justify-center gap-2 py-8 text-[var(--muted)]">
            <LoaderCircle size={18} className="animate-spin" />
          </div>
        ) : admins.length === 0 ? (
          <p className="text-muted py-6 text-center text-sm">مدیر فرعی‌ای تعریف نشده است.</p>
        ) : (
          <ul className="space-y-2.5">
            {admins.map((r) => (
              <li key={r.id} className="panel-inset flex flex-wrap items-center gap-3 px-4 py-3">
                <Avatar name={r.fullName} color="gold" size={36} />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[0.85rem] font-bold">{r.fullName}</span>
                    {r.title && <span className="badge badge-gold">{r.title}</span>}
                  </div>
                  <div className="text-faint mt-0.5 text-[0.66rem]">
                    {r.className ?? ""} • <span dir="ltr">{r.username}</span>
                  </div>
                </div>
                <div className="hidden flex-wrap gap-1 sm:flex">
                  {(r.permissions ?? []).map((p) => (
                    <span key={p} className="badge">
                      {PERMS.find((x) => x.key === p)?.label ?? p}
                    </span>
                  ))}
                </div>
                <div className="ms-auto flex gap-1.5 sm:ms-0">
                  <button
                    onClick={() => {
                      setEditPerms(r);
                      setEditPermList(r.permissions ?? []);
                    }}
                    className="btn btn-ghost btn-sm"
                  >
                    <Lock size={13} />
                    سطح دسترسی
                  </button>
                  {r.id !== meId && (
                    <button onClick={() => revoke(r)} disabled={busy} className="btn btn-danger btn-sm">
                      <ShieldOff size={13} />
                      لغو دسترسی
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* اعطای دسترسی */}
      <section className="panel p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-extrabold">
          <UserCog size={16} className="text-[var(--success)]" />
          اعطای دسترسی مدیریت به دانش‌آموز
        </h3>
        <div className="panel-inset overflow-hidden">
          <div className="relative border-b border-[var(--border)]">
            <Search size={15} className="text-faint absolute top-1/2 right-3 -translate-y-1/2" />
            <input
              className="w-full bg-transparent py-2.5 ps-4 pe-9 text-[0.82rem] outline-none"
              placeholder="جست‌وجوی دانش‌آموز…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="max-h-56 overflow-y-auto">
            {candidates.slice(0, 25).map((r) => (
              <button
                key={r.id}
                onClick={() => {
                  setGrantTarget(r);
                  setGrantPerms(PERMS.map((p) => p.key));
                }}
                className="flex w-full items-center gap-3 px-3.5 py-2.5 text-right transition hover:bg-[var(--panel-2)]"
              >
                <Avatar name={r.fullName} color="blue" size={30} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[0.8rem] font-bold">{r.fullName}</span>
                  <span className="text-faint text-[0.66rem]">{r.className}{r.title ? ` • ${r.title}` : ""}</span>
                </span>
                <span className="badge badge-green">اعطای دسترسی</span>
              </button>
            ))}
            {candidates.length === 0 && <div className="text-faint py-5 text-center text-xs">موردی یافت نشد.</div>}
          </div>
        </div>
      </section>

      {/* مودال اعطا */}
      <Modal open={grantTarget !== null} onClose={() => setGrantTarget(null)} title="اعطای دسترسی مدیریت">
        {grantTarget && (
          <div className="space-y-4">
            <p className="text-muted text-sm leading-7">
              به «{grantTarget.fullName}» دسترسی مدیریت با سطوح زیر داده شود؟
            </p>
            <div className="grid grid-cols-2 gap-2">
              {PERMS.map((p) => (
                <button
                  key={p.key}
                  onClick={() => togglePerm(grantPerms, p.key, setGrantPerms)}
                  className="flex items-center gap-2 rounded-xl border px-3 py-2.5 text-right text-[0.76rem] font-bold transition"
                  style={{
                    borderColor: grantPerms.includes(p.key) ? "rgba(231,189,85,.5)" : "var(--border)",
                    background: grantPerms.includes(p.key) ? "rgba(231,189,85,.08)" : "transparent",
                  }}
                >
                  {grantPerms.includes(p.key) && <Check size={13} className="text-[var(--gold)]" />}
                  {p.label}
                </button>
              ))}
            </div>
            <button onClick={grant} disabled={busy} className="btn btn-gold w-full">
              {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Crown size={15} />}
              فعال‌سازی دسترسی مدیریت
            </button>
          </div>
        )}
      </Modal>

      {/* مودال ویرایش سطح */}
      <Modal open={editPerms !== null} onClose={() => setEditPerms(null)} title={`سطح دسترسی «${editPerms?.fullName}»`}>
        {editPerms && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              {PERMS.map((p) => (
                <button
                  key={p.key}
                  onClick={() => togglePerm(editPermList, p.key, setEditPermList)}
                  className="flex items-center gap-2 rounded-xl border px-3 py-2.5 text-right text-[0.76rem] font-bold transition"
                  style={{
                    borderColor: editPermList.includes(p.key) ? "rgba(79,124,255,.55)" : "var(--border)",
                    background: editPermList.includes(p.key) ? "rgba(79,124,255,.1)" : "transparent",
                  }}
                >
                  {editPermList.includes(p.key) && <Check size={13} style={{ color: "#8facff" }} />}
                  {p.label}
                </button>
              ))}
            </div>
            <button onClick={savePerms} disabled={busy} className="btn btn-primary w-full">
              {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
              ذخیره سطح دسترسی
            </button>
          </div>
        )}
      </Modal>

      {/* نکته */}
      <p className="text-faint pb-2 text-center text-[0.66rem] font-semibold">
        {students.length > 0 ? `${fa(students.length)} حساب دانش‌آموزی در سامانه` : ""}
      </p>
    </div>
  );
}
