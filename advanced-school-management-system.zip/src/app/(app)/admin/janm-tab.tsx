"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { BookOpenCheck, Clock3, Gem, LoaderCircle, RefreshCw, ShieldAlert, Undo2 } from "lucide-react";
import { Avatar } from "@/components/ui";
import { Modal } from "@/components/modal";
import { JanmAdjustModal } from "@/components/janm-adjust";
import { useToast } from "@/components/providers";
import { fa, faDateTime } from "@/lib/format";
import { apiCall } from "./shared";
import { TX_KIND_LABELS, type JanmTx, type StudentBrief } from "@/lib/types";

const RULES = [
  { icon: Undo2, label: "غیبت غیرموجه", amount: "۱۰-", desc: "کسر خودکار ۱۰ جنم" },
  { icon: Clock3, label: "سه تأخیر در ورود", amount: "۵-", desc: "فقط پس از سومین تأخیر اعمال می‌شود" },
  { icon: ShieldAlert, label: "بی‌نظمی", amount: "۲-", desc: "کسر خودکار ۲ جنم" },
];

export default function JanmTab({ students }: { students: StudentBrief[] }) {
  const router = useRouter();
  const toast = useToast();
  const [adjustOpen, setAdjustOpen] = useState(false);
  const [txs, setTxs] = useState<(JanmTx & { userName: string })[] | null>(null);
  const [correctionTarget, setCorrectionTarget] = useState<(JanmTx & { userName: string }) | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const r = await apiCall("/api/janm?limit=40");
    if (r.ok) setTxs(r.data as (JanmTx & { userName: string })[]);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function correct() {
    if (!correctionTarget || busy) return;
    setBusy(true);
    const r = await apiCall("/api/janm", { method: "PATCH", body: JSON.stringify({ id: correctionTarget.id, note }) });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    toast.push("success", "تراکنش اصلاح شد.");
    setCorrectionTarget(null);
    setNote("");
    load();
    router.refresh();
  }

  return (
    <div className="space-y-5">
      {/* قوانین */}
      <section className="panel p-5">
        <h3 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
          <BookOpenCheck size={16} className="text-[var(--gold)]" />
          قوانین انضباطی جنم
        </h3>
        <div className="grid gap-3 sm:grid-cols-3">
          {RULES.map((r) => (
            <div key={r.label} className="panel-inset flex items-center gap-3 px-4 py-3.5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl" style={{ background: "rgba(255,107,107,.1)", color: "var(--danger)" }}>
                <r.icon size={17} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-[0.8rem] font-extrabold">{r.label}</div>
                <div className="text-faint text-[0.64rem]">{r.desc}</div>
              </div>
              <span className="text-lg font-black text-[var(--danger)]" dir="ltr">
                {r.amount}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* ثبت تغییر */}
      <section className="panel relative overflow-hidden p-6 text-center">
        <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(400px 160px at 50% 0%, rgba(231,189,85,.09), transparent 70%)" }} />
        <Gem size={30} className="gold-text mx-auto" style={{ color: "var(--gold)" }} />
        <h3 className="relative mt-2 text-base font-black">ثبت تغییر جنم برای یک یا چند دانش‌آموز</h3>
        <p className="text-muted relative mx-auto mt-1.5 max-w-md text-[0.76rem] leading-6">
          هر تغییر با دلیل، تاریخ، ساعت و نام مدیر ثبت می‌شود و در تاریخچه دانش‌آموز قابل مشاهده است.
        </p>
        <button onClick={() => setAdjustOpen(true)} className="btn btn-gold relative mt-4">
          <Gem size={16} />
          شروع ثبت جنم
        </button>
      </section>

      {/* تراکنش‌های اخیر */}
      <section className="panel overflow-hidden">
        <div className="flex items-center justify-between border-b border-[var(--border)] px-5 py-4">
          <h3 className="text-sm font-extrabold">آخرین تراکنش‌های ثبت‌شده</h3>
          <button onClick={load} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--text)]" aria-label="به‌روزرسانی">
            <RefreshCw size={14} />
          </button>
        </div>
        {txs === null ? (
          <div className="flex items-center justify-center gap-2 py-12 text-[var(--muted)]">
            <LoaderCircle size={18} className="animate-spin" />
          </div>
        ) : txs.length === 0 ? (
          <p className="text-muted py-12 text-center text-sm">هنوز تراکنشی ثبت نشده است.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="table-pro min-w-[720px]">
              <thead>
                <tr>
                  <th>دانش‌آموز</th>
                  <th>دلیل</th>
                  <th>نوع</th>
                  <th>مقدار</th>
                  <th>مدیر ثبت‌کننده</th>
                  <th>زمان</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {txs.map((t) => (
                  <tr key={t.id} style={t.status === "corrected" ? { opacity: 0.55 } : undefined}>
                    <td>
                      <Link href={`/students/${t.userId}`} className="font-bold hover:text-[var(--gold)]">
                        {t.userName}
                      </Link>
                    </td>
                    <td className="max-w-52 truncate">{t.reason}</td>
                    <td>
                      <span className={`badge ${t.kind === "correction" ? "badge-gold" : t.amount < 0 ? "badge-red" : t.amount > 0 ? "badge-green" : ""}`}>
                        {TX_KIND_LABELS[t.kind] ?? t.kind}
                      </span>
                      {t.status === "corrected" && <span className="badge badge-red ms-1">ابطال‌شده</span>}
                    </td>
                    <td>
                      <span className="font-black" dir="ltr" style={{ color: t.amount > 0 ? "var(--success)" : t.amount < 0 ? "var(--danger)" : "var(--muted)" }}>
                        {t.amount > 0 ? "+" : ""}
                        {fa(t.amount)}
                      </span>
                    </td>
                    <td className="text-muted text-xs">{t.actorName}</td>
                    <td className="text-faint text-xs">{faDateTime(t.createdAt)}</td>
                    <td className="text-left!">
                      {t.status === "active" && (
                        <button onClick={() => setCorrectionTarget(t)} className="btn btn-ghost btn-sm">
                          <Undo2 size={13} />
                          اصلاح
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <JanmAdjustModal
        open={adjustOpen}
        onClose={() => setAdjustOpen(false)}
        students={students}
        onDone={() => {
          load();
          router.refresh();
        }}
      />

      <Modal open={correctionTarget !== null} onClose={() => setCorrectionTarget(null)} title="اصلاح تراکنش">
        {correctionTarget && (
          <div className="space-y-4">
            <div className="panel-inset px-4 py-3 text-sm">
              <div className="font-bold">{correctionTarget.reason}</div>
              <div className="text-faint mt-1 text-[0.7rem]">
                {correctionTarget.userName} • <span dir="ltr">{correctionTarget.amount}</span> جنم
              </div>
            </div>
            <p className="text-muted text-[0.76rem] leading-6">
              تراکنش حذف نمی‌شود؛ ابطال می‌گردد و یک سابقه اصلاح معکوس با نام شما ثبت می‌شود.
            </p>
            <div>
              <label className="label">دلیل اصلاح</label>
              <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="مثلاً: ثبت اشتباه بوده است" />
            </div>
            <button onClick={correct} disabled={busy} className="btn btn-gold w-full">
              {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Undo2 size={15} />}
              تأیید و اصلاح
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
}
