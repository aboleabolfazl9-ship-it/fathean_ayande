"use client";

export async function apiCall(path: string, init?: RequestInit): Promise<{ ok: boolean; data?: unknown; error?: string }> {
  try {
    const res = await fetch(path, init ? { ...init, headers: { "Content-Type": "application/json", ...(init.headers ?? {}) } } : undefined);
    const json = await res.json().catch(() => null);
    if (!res.ok || !json?.ok) return { ok: false, error: json?.error ?? "خطا در انجام عملیات" };
    return { ok: true, data: json.data };
  } catch {
    return { ok: false, error: "ارتباط با سرور برقرار نشد." };
  }
}
