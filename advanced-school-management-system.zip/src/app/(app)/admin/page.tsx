import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { asc, desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { getSessionUser, isAdmin, isSuperAdmin } from "@/lib/auth";
import AdminClient from "./admin-client";
import type { ClassItem, StudentBrief } from "@/lib/types";

export const metadata: Metadata = { title: "پنل مدیریت" };

export default async function AdminPage() {
  const me = await getSessionUser();
  if (!me) redirect("/login");
  if (!isAdmin(me)) redirect("/");

  const classRows = await db.select().from(classes).orderBy(asc(classes.code));
  const studentRows = await db
    .select({ u: users, className: classes.name, classCode: classes.code })
    .from(users)
    .leftJoin(classes, eq(classes.id, users.classId))
    .where(ne(users.role, "superadmin"))
    .orderBy(desc(users.janm), asc(users.fullName));

  const students: StudentBrief[] = studentRows.map((r) => ({
    id: r.u.id,
    fullName: r.u.fullName,
    username: r.u.username,
    classId: r.u.classId,
    className: r.className,
    classCode: r.classCode,
    role: r.u.role,
    title: r.u.title,
    janm: r.u.janm,
    isApproved: r.u.isApproved,
    isBlocked: r.u.isBlocked,
    avatarColor: r.u.avatarColor,
    avatarUrl: r.u.avatarUrl,
  }));

  return (
    <AdminClient
      meId={me.id}
      isSuper={isSuperAdmin(me)}
      permissions={(me.permissions as string[] | null) ?? null}
      role={me.role}
      students={students}
      classes={classRows.map((c) => ({ id: c.id, name: c.name, code: c.code })) as ClassItem[]}
    />
  );
}
