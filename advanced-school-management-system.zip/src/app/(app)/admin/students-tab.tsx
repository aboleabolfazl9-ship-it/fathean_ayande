"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Ban,
  Check,
  CheckCircle2,
  KeyRound,
  LoaderCircle,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Trash2,
  UserCheck,
  Users,
  XCircle,
} from "lucide-react";
import { Avatar, EmptyState, TitleBadge } from "@/components/ui";
import { Modal } from "@/components/modal";
import { useToast } from "@/components/providers";
import { fa, faNum, faRelative } from "@/lib/format";
import { apiCall } from "./shared";
import type { ClassItem, StudentBrief } from "@/lib/types";

type ResetReq = {
  id: number;
  username: string;
  fullName: string;
  note: string;
  status: string;
  createdAt: string;
};

export default function StudentsTab({
  students,
  classes,
  meId,
}: {
  students: StudentBrief[];
  classes: ClassItem[];
  meId: number;
}) {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [resets, setResets] = useState<ResetReq[]>([]);
  const [tempPass, setTempPass] = useState<{ username: string; password: string } | null>(null);

  const [editTarget, setEditTarget] = useState<StudentBrief | null>(null);
  const [fName, setFName] = useState("");
  const [fUsername, setFUsername] = useState("");
  const [fClassId, setFClassId] = useState("");
  const [fTitle, setFTitle] = useState("");

  const [addOpen, setAddOpen] = useState(false);
  const [aName, setAName] = useState("");
  const [aUsername, setAUsername] = useState("");
  const [aPassword, setAPassword] = useState("");
  const [aClassId, setAClassId] = useState("");

  const [deleteTarget, setDeleteTarget] = useState<StudentBrief | null>(null);

  useEffect(() => {
    apiCall("/api/admin/resets").then((r) => {
      if (r.ok) setResets((r.data as ResetReq[]).filter((x) => x.status === "pending"));
    });
  }, []);

  const pending = students.filter((s) => !s.isApproved);
  const filtered = useMemo(() => {
    let list = students.filter((s) => s.isApproved);
    if (classFilter !== "all") list = list.filter((s) => String(s.classId) === classFilter);
    if (q.trim()) list = list.filter((s) => s.fullName.includes(q.trim()) || s.username.includes(q.trim().toLowerCase()));
    return list;
  }, [students, q, classFilter]);

  function openEdit(s: StudentBrief) {
    setEditTarget(s);
    setFName(s.fullName);
    setFUsername(s.username);
    setFClassId(String(s.classId ?? ""));
    setFTitle(s.title ?? "");
  }

  async function saveEdit() {
    if (!editTarget || busy) return;
    setBusy(true);
    const r = await apiCall(`/api/students/${editTarget.id}`, {
      method: "PATCH",
      body: JSON.stringify({
        fullName: fName,
        username: fUsername,
        classId: fClassId ? Number(fClassId) : null,
        title: fTitle || null,
      }),
    });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    toast.push("success", "مشخصات دانش‌آموز به‌روزرسانی شد.");
    setEditTarget(null);
    router.refresh();
  }

  async function toggleBlock(s: StudentBrief) {
    if (busy) return;
    setBusy(true);
    const r = await apiCall(`/api/students/${s.id}`, { method: "PATCH", body: JSON.stringify({ isBlocked: !s.isBlocked }) });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    toast.push("success", s.isBlocked ? "حساب رفع مسدودیت شد." : "حساب مسدود شد.");
    router.refresh();
  }

  async function approve(s: StudentBrief, okApprove: boolean) {
    if (busy) return;
    setBusy(true);
    const r = await apiCall(
      okApprove ? `/api/students/${s.id}` : `/api/students/${s.id}`,
      okApprove ? { method: "PATCH", body: JSON.stringify({ isApproved: true }) } : { method: "DELETE", body: "{}" },
    );
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    toast.push("success", okApprove ? "حساب تأیید و فعال شد." : "درخواست ثبت‌نام رد شد.");
    router.refresh();
  }

  async function resetPassword(s: StudentBrief) {
    if (busy) return;
    setBusy(true);
    const r = await apiCall(`/api/students/${s.id}`, { method: "PATCH", body: JSON.stringify({ resetPassword: true }) });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    const d = r.data as { tempPassword: string };
    setTempPass({ username: s.username, password: d.tempPassword });
    toast.push("success", "رمز موقت صادر شد.");
  }

  async function removeStudent() {
    if (!deleteTarget || busy) return;
    setBusy(true);
    const r = await apiCall(`/api/students/${deleteTarget.id}`, { method: "DELETE", body: "{}" });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    toast.push("success", "دانش‌آموز حذف شد.");
    setDeleteTarget(null);
    router.refresh();
  }

  async function addStudent() {
    if (busy) return;
    setBusy(true);
    const r = await apiCall("/api/students", {
      method: "POST",
      body: JSON.stringify({ fullName: aName, username: aUsername, password: aPassword, classId: Number(aClassId) }),
    });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    toast.push("success", "دانش‌آموز جدید ایجاد شد.");
    setAddOpen(false);
    setAName("");
    setAUsername("");
    setAPassword("");
    router.refresh();
  }

  async function handleResetRequest(reqItem: ResetReq, action: "approve" | "reject") {
    if (busy) return;
    setBusy(true);
    const r = await apiCall("/api/admin/resets", { method: "PATCH", body: JSON.stringify({ id: reqItem.id, action }) });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    if (action === "approve") {
      const d = r.data as { tempPassword: string; username: string };
      setTempPass({ username: d.username, password: d.tempPassword });
    } else {
      toast.push("info", "درخواست رد شد.");
    }
    setResets((x) => x.filter((i) => i.id !== reqItem.id));
  }

  return (
    <div className="space-y-5">
      {/* درخواست‌های در انتظار */}
      {(pending.length > 0 || resets.length > 0) && (
        <div className="grid gap-4 lg:grid-cols-2">
          {pending.length > 0 && (
            <section className="panel border-[rgba(231,189,85,.35)] p-5" style={{ borderColor: "rgba(231,189,85,.4)" }}>
              <h3 className="mb-3 flex items-center gap-2 text-sm font-extrabold text-[var(--gold)]">
                <UserCheck size={16} />
                درخواست‌های ثبت‌نام ({fa(pending.length)})
              </h3>
              <ul className="space-y-2">
                {pending.map((s) => (
                  <li key={s.id} className="panel-inset flex flex-wrap items-center gap-2.5 px-3.5 py-2.5">
                    <Avatar name={s.fullName} color={s.avatarColor} size={30} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[0.8rem] font-bold">{s.fullName}</div>
                      <div className="text-faint text-[0.64rem]">{s.className ?? "بدون کلاس"} • <span dir="ltr">{s.username}</span></div>
                    </div>
                    <button onClick={() => approve(s, true)} disabled={busy} className="btn btn-primary btn-sm">
                      <CheckCircle2 size={13} />
                      تأیید
                    </button>
                    <button onClick={() => approve(s, false)} disabled={busy} className="btn btn-danger btn-sm">
                      <XCircle size={13} />
                      رد
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          )}
          {resets.length > 0 && (
            <section className="panel p-5" style={{ borderColor: "rgba(56,189,248,.35)" }}>
              <h3 className="mb-3 flex items-center gap-2 text-sm font-extrabold" style={{ color: "#38bdf8" }}>
                <KeyRound size={16} />
                درخواست‌های بازیابی رمز ({fa(resets.length)})
              </h3>
              <ul className="space-y-2">
                {resets.map((r) => (
                  <li key={r.id} className="panel-inset flex flex-wrap items-center gap-2.5 px-3.5 py-2.5">
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[0.8rem] font-bold">{r.fullName || r.username}</div>
                      <div className="text-faint text-[0.64rem]">
                        <span dir="ltr">{r.username}</span> • {faRelative(r.createdAt)} {r.note && `• ${r.note}`}
                      </div>
                    </div>
                    <button onClick={() => handleResetRequest(r, "approve")} disabled={busy} className="btn btn-primary btn-sm">
                      <Check size={13} />
                      صدور رمز جدید
                    </button>
                    <button onClick={() => handleResetRequest(r, "reject")} disabled={busy} className="btn btn-danger btn-sm">
                      رد
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      )}

      {/* ابزار */}
      <div className="panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={16} className="text-faint absolute top-1/2 right-3 -translate-y-1/2" />
          <input className="input pe-10" placeholder="جست‌وجوی نام یا نام کاربری…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select className="select sm:w-44" value={classFilter} onChange={(e) => setClassFilter(e.target.value)}>
          <option value="all">همه کلاس‌ها</option>
          {classes.map((c) => (
            <option key={c.id} value={String(c.id)}>
              {c.name}
            </option>
          ))}
        </select>
        <button onClick={() => setAddOpen(true)} className="btn btn-gold">
          <Plus size={16} />
          افزودن دانش‌آموز
        </button>
      </div>

      {/* جدول */}
      <div className="panel overflow-hidden">
        <div className="overflow-x-auto">
          <table className="table-pro min-w-[720px]">
            <thead>
              <tr>
                <th>دانش‌آموز</th>
                <th>کلاس</th>
                <th>نام کاربری</th>
                <th>جنم</th>
                <th>وضعیت</th>
                <th className="text-left!">اقدامات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => (
                <tr key={s.id}>
                  <td>
                    <Link href={`/students/${s.id}`} className="flex items-center gap-2.5">
                      <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={34} />
                      <span className="flex flex-wrap items-center gap-1.5">
                        <span className="font-bold">{s.fullName}</span>
                        {s.title && <TitleBadge title={s.title} />}
                      </span>
                    </Link>
                  </td>
                  <td>
                    <span className="badge">{s.className ?? "—"}</span>
                  </td>
                  <td>
                    <span className="text-muted text-xs" dir="ltr">
                      {s.username}
                    </span>
                  </td>
                  <td>
                    <span className="font-black" dir="ltr" style={{ color: s.janm > 0 ? "var(--gold)" : s.janm < 0 ? "var(--danger)" : "var(--muted)" }}>
                      {faNum(s.janm)}
                    </span>
                  </td>
                  <td>
                    {s.isBlocked ? (
                      <span className="badge badge-red">مسدود</span>
                    ) : (
                      <span className="badge badge-green">فعال</span>
                    )}
                  </td>
                  <td className="text-left!">
                    <div className="flex justify-end gap-1.5">
                      <button onClick={() => openEdit(s)} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--gold)]" title="ویرایش">
                        <Pencil size={13} />
                      </button>
                      <button onClick={() => resetPassword(s)} disabled={busy} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[#38bdf8]" title="صدور رمز موقت">
                        <KeyRound size={13} />
                      </button>
                      {s.id !== meId && (
                        <>
                          <button onClick={() => toggleBlock(s)} disabled={busy} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--danger)]" title={s.isBlocked ? "رفع مسدودیت" : "مسدودسازی"}>
                            <Ban size={13} />
                          </button>
                          <button onClick={() => setDeleteTarget(s)} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--danger)]" title="حذف">
                            <Trash2 size={13} />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <EmptyState icon={<Users size={26} />} title="دانش‌آموزی یافت نشد" />}
      </div>

      {/* ویرایش */}
      <Modal open={editTarget !== null} onClose={() => setEditTarget(null)} title="ویرایش دانش‌آموز">
        {editTarget && (
          <div className="space-y-4">
            <div>
              <label className="label">نام و نام خانوادگی</label>
              <input className="input" value={fName} onChange={(e) => setFName(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">نام کاربری</label>
                <input className="input" dir="ltr" style={{ textAlign: "left" }} value={fUsername} onChange={(e) => setFUsername(e.target.value)} />
              </div>
              <div>
                <label className="label">کلاس</label>
                <select className="select" value={fClassId} onChange={(e) => setFClassId(e.target.value)}>
                  <option value="">بدون کلاس</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="label">مسئولیت رسمی (اختیاری)</label>
              <input className="input" value={fTitle} onChange={(e) => setFTitle(e.target.value)} placeholder="مثلاً: مدیر ارشد" />
            </div>
            <button onClick={saveEdit} disabled={busy} className="btn btn-gold w-full">
              {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
              ذخیره تغییرات
            </button>
          </div>
        )}
      </Modal>

      {/* افزودن */}
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="افزودن دانش‌آموز جدید">
        <div className="space-y-4">
          <div>
            <label className="label">نام و نام خانوادگی</label>
            <input className="input" value={aName} onChange={(e) => setAName(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">نام کاربری</label>
              <input className="input" dir="ltr" style={{ textAlign: "left" }} value={aUsername} onChange={(e) => setAUsername(e.target.value)} />
            </div>
            <div>
              <label className="label">رمز عبور اولیه</label>
              <input className="input" dir="ltr" style={{ textAlign: "left" }} value={aPassword} onChange={(e) => setAPassword(e.target.value)} placeholder="حداقل ۶ کاراکتر" />
            </div>
          </div>
          <div>
            <label className="label">کلاس</label>
            <select className="select" value={aClassId} onChange={(e) => setAClassId(e.target.value)}>
              <option value="">انتخاب کلاس…</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <p className="text-faint text-[0.68rem] leading-5">جنم اولیه صفر است و حساب بلافاصله فعال می‌شود.</p>
          <button onClick={addStudent} disabled={busy || !aName || !aUsername || !aPassword || !aClassId} className="btn btn-gold w-full">
            {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Plus size={15} />}
            ایجاد حساب
          </button>
        </div>
      </Modal>

      {/* حذف */}
      <Modal open={deleteTarget !== null} onClose={() => setDeleteTarget(null)} title="حذف دانش‌آموز">
        <p className="text-muted text-sm leading-7">
          «{deleteTarget?.fullName}» و تمام سوابق جنم و افتخارات او برای همیشه حذف می‌شود. این عمل قابل بازگشت نیست.
        </p>
        <div className="mt-5 flex gap-2">
          <button onClick={() => setDeleteTarget(null)} className="btn btn-ghost flex-1">
            انصراف
          </button>
          <button onClick={removeStudent} disabled={busy} className="btn btn-danger flex-1">
            {busy ? <LoaderCircle size={15} className="animate-spin" /> : <Trash2 size={15} />}
            حذف قطعی
          </button>
        </div>
      </Modal>

      {/* نمایش رمز موقت */}
      <Modal open={tempPass !== null} onClose={() => setTempPass(null)} title="رمز موقت صادر شد">
        {tempPass && (
          <div className="space-y-4">
            <p className="text-muted text-sm leading-7">
              رمز جدید حساب <b>{tempPass.username}</b> صادر شد. این رمز فقط همین یک‌بار نمایش داده می‌شود؛ آن را از مسیر امن به
              دانش‌آموز اعلام کنید.
            </p>
            <div className="panel-inset flex items-center justify-center px-4 py-4">
              <span className="gold-text text-xl font-black tracking-wider" dir="ltr">
                {tempPass.password}
              </span>
            </div>
            <button
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(tempPass.password);
                  toast.push("success", "رمز کپی شد.");
                } catch {
                  toast.push("error", "کپی ممکن نشد؛ دستی یادداشت کنید.");
                }
              }}
              className="btn btn-ghost w-full"
            >
              <ShieldCheck size={15} />
              کپی رمز موقت
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
}
