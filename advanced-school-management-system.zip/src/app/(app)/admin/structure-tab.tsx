"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Check, GraduationCap, LoaderCircle, Pencil, Plus, Shield, Trash2, Users } from "lucide-react";
import { Modal } from "@/components/modal";
import { useToast } from "@/components/providers";
import { fa, faNum } from "@/lib/format";
import { apiCall } from "./shared";
import type { BaseItem, ClassItem, StudentBrief } from "@/lib/types";

export default function StructureTab({
  classes,
  students,
  canClasses,
}: {
  classes: ClassItem[];
  students: StudentBrief[];
  canClasses: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [bases, setBases] = useState<BaseItem[] | null>(null);

  const [modal, setModal] = useState<"none" | "add" | "edit">("none");
  const [target, setTarget] = useState<ClassItem | null>(null);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [deleting, setDeleting] = useState<ClassItem | null>(null);

  useEffect(() => {
    apiCall("/api/bases").then((r) => {
      if (r.ok) setBases(r.data as BaseItem[]);
    });
  }, []);

  const countOf = (id: number) => students.filter((s) => s.classId === id && s.isApproved).length;

  async function save() {
    if (busy) return;
    setBusy(true);
    const isEdit = modal === "edit" && target;
    const r = await apiCall(isEdit ? `/api/classes/${target!.id}` : "/api/classes", {
      method: isEdit ? "PATCH" : "POST",
      body: JSON.stringify({ name, code }),
    });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    toast.push("success", isEdit ? "کلاس ویرایش شد." : "کلاس ایجاد شد.");
    setModal("none");
    router.refresh();
  }

  async function remove() {
    if (!deleting || busy) return;
    setBusy(true);
    const r = await apiCall(`/api/classes/${deleting.id}`, { method: "DELETE", body: "{}" });
    setBusy(false);
    if (!r.ok) return toast.push("error", r.error!);
    toast.push("success", "کلاس حذف شد.");
    setDeleting(null);
    router.refresh();
  }

  return (
    <div className="space-y-5">
      {/* کلاس‌ها */}
      <section className="panel p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-sm font-extrabold">
            <GraduationCap size={16} style={{ color: "#38bdf8" }} />
            مدیریت کلاس‌ها
          </h3>
          {canClasses && (
            <button
              onClick={() => {
                setName("");
                setCode("");
                setModal("add");
              }}
              className="btn btn-primary btn-sm"
            >
              <Plus size={14} />
              کلاس جدید
            </button>
          )}
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {classes.map((c) => {
            const count = countOf(c.id);
            const sum = students.filter((s) => s.classId === c.id && s.isApproved).reduce((t, s) => t + s.janm, 0);
            return (
              <div key={c.id} className="panel-inset flex items-center gap-3 px-4 py-3.5">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-extrabold">{c.name}</span>
                    <span className="text-faint text-[0.64rem]" dir="ltr">
                      {c.code}
                    </span>
                  </div>
                  <div className="text-faint mt-1 flex items-center gap-2 text-[0.66rem] font-bold">
                    <span className="flex items-center gap-1">
                      <Users size={11} />
                      {fa(count)} دانش‌آموز
                    </span>
                    <span>
                      مجموع جنم:{" "}
                      <span dir="ltr" style={{ color: sum > 0 ? "var(--gold)" : sum < 0 ? "var(--danger)" : "var(--muted)" }}>
                        {faNum(sum)}
                      </span>
                    </span>
                  </div>
                </div>
                {canClasses && (
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => {
                        setTarget(c);
                        setName(c.name);
                        setCode(c.code);
                        setModal("edit");
                      }}
                      className="panel flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--gold)]"
                      aria-label="ویرایش کلاس"
                    >
                      <Pencil size={13} />
                    </button>
                    <button onClick={() => setDeleting(c)} className="panel flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--danger)]" aria-label="حذف کلاس">
                      <Trash2 size={13} />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <p className="text-faint mt-3 text-[0.66rem] font-semibold">
          برای انتقال دانش‌آموز بین کلاس‌ها از برگه «دانش‌آموزان» یا صفحه کلاس‌ها استفاده کنید.
        </p>
      </section>

      {/* قرارگاه‌ها */}
      <section className="panel p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-sm font-extrabold">
            <Shield size={16} className="text-[var(--gold)]" />
            مدیریت قرارگاه‌ها
          </h3>
          <Link href="/bases" className="btn btn-ghost btn-sm">
            مدیریت در صفحه قرارگاه‌ها
            <ArrowLeft size={13} />
          </Link>
        </div>
        {bases === null ? (
          <div className="flex items-center justify-center gap-2 py-8 text-[var(--muted)]">
            <LoaderCircle size={18} className="animate-spin" />
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {bases.map((b) => (
              <div key={b.id} className="panel-inset px-4 py-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-extrabold">{b.name}</span>
                  <span className="badge">{fa(b.members.length)} عضو</span>
                </div>
                <div className="text-faint mt-1 text-[0.68rem] font-semibold">مدیر: {b.managerName}</div>
              </div>
            ))}
          </div>
        )}
      </section>

      <Modal open={modal !== "none"} onClose={() => setModal("none")} title={modal === "edit" ? "ویرایش کلاس" : "افزودن کلاس جدید"}>
        <div className="space-y-4">
          <div>
            <label className="label">نام کلاس</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً: کلاس ۱۰/۱" />
          </div>
          <div>
            <label className="label">کد کلاس (انگلیسی)</label>
            <input className="input" dir="ltr" style={{ textAlign: "left" }} value={code} onChange={(e) => setCode(e.target.value)} placeholder="101" />
          </div>
          <button onClick={save} disabled={busy} className="btn btn-gold w-full">
            {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
            {modal === "edit" ? "ذخیره تغییرات" : "ایجاد کلاس"}
          </button>
        </div>
      </Modal>

      <Modal open={deleting !== null} onClose={() => setDeleting(null)} title="حذف کلاس">
        <p className="text-muted text-sm leading-7">حذف «{deleting?.name}» فقط در صورت خالی بودن کلاس ممکن است.</p>
        <div className="mt-5 flex gap-2">
          <button onClick={() => setDeleting(null)} className="btn btn-ghost flex-1">
            انصراف
          </button>
          <button onClick={remove} disabled={busy} className="btn btn-danger flex-1">
            {busy ? <LoaderCircle size={15} className="animate-spin" /> : <Trash2 size={15} />}
            حذف قطعی
          </button>
        </div>
      </Modal>
    </div>
  );
}
