"use client";

import { useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Crown, Gauge, GraduationCap, Gem, Layers3, Lock } from "lucide-react";
import { PageHeader } from "@/components/ui";
import type { ClassItem, StudentBrief } from "@/lib/types";
import OverviewTab from "./overview-tab";
import StudentsTab from "./students-tab";
import JanmTab from "./janm-tab";
import StructureTab from "./structure-tab";
import AccessTab from "./access-tab";

const TABS = [
  { key: "overview", label: "نمای کلی", icon: Gauge, perm: null },
  { key: "students", label: "دانش‌آموزان", icon: GraduationCap, perm: "students" },
  { key: "janm", label: "مدیریت جنم", icon: Gem, perm: "janm" },
  { key: "structure", label: "کلاس‌ها و قرارگاه‌ها", icon: Layers3, perm: null },
  { key: "access", label: "دسترسی‌ها", icon: Lock, perm: "access" },
] as const;

type TabKey = (typeof TABS)[number]["key"];

export default function AdminClient({
  meId,
  isSuper,
  permissions,
  role,
  students,
  classes,
}: {
  meId: number;
  isSuper: boolean;
  permissions: string[] | null;
  role: string;
  students: StudentBrief[];
  classes: ClassItem[];
}) {
  const searchParams = useSearchParams();
  const router = useRouter();
  const initialTab = (searchParams.get("tab") as TabKey) || "overview";
  const [tab, setTab] = useState<TabKey>(TABS.some((t) => t.key === initialTab) ? initialTab : "overview");

  const can = (perm: string | null) => {
    if (perm === null) return true;
    if (perm === "access") return isSuper;
    if (isSuper) return true;
    return (permissions ?? []).includes(perm);
  };

  const available = TABS.filter((t) => can(t.perm));
  const activeTab = available.some((t) => t.key === tab) ? tab : available[0].key;

  function select(key: TabKey) {
    setTab(key);
    router.replace(`/admin?tab=${key}`, { scroll: false });
  }

  return (
    <div>
      <PageHeader
        title="پنل مدیریت"
        subtitle={role === "superadmin" ? "مدیر اصلی سامانه — دسترسی کامل" : "مدیر مجاز — بر اساس سطح دسترسی"}
        icon={<Crown size={22} />}
      />

      <div className="rise rise-1 mb-5 flex flex-wrap gap-2">
        {available.map((t) => {
          const on = t.key === activeTab;
          return (
            <button
              key={t.key}
              onClick={() => select(t.key)}
              className="btn btn-sm"
              style={
                on
                  ? {
                      background: "linear-gradient(160deg,rgba(231,189,85,.25),rgba(231,189,85,.08))",
                      borderColor: "rgba(231,189,85,.5)",
                      color: "var(--gold)",
                      fontWeight: 800,
                    }
                  : { background: "var(--panel-2)", borderColor: "var(--border)", color: "var(--muted)" }
              }
            >
              <t.icon size={15} />
              {t.label}
            </button>
          );
        })}
      </div>

      {activeTab === "overview" && <OverviewTab />}
      {activeTab === "students" && <StudentsTab students={students} classes={classes} meId={meId} />}
      {activeTab === "janm" && <JanmTab students={students} />}
      {activeTab === "structure" && <StructureTab classes={classes} students={students} canClasses={isSuper || (permissions ?? []).includes("classes")} />}
      {activeTab === "access" && isSuper && <AccessTab students={students} meId={meId} />}
    </div>
  );
}
