"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Activity,
  CalendarClock,
  Gem,
  GraduationCap,
  LoaderCircle,
  Megaphone,
  Users,
  TriangleAlert,
  KeyRound,
  UserPlus,
} from "lucide-react";
import { Avatar } from "@/components/ui";
import { fa, faDateTime, faNum, faRelative } from "@/lib/format";
import { apiCall } from "./shared";
import type { JanmTx } from "@/lib/types";

type OverviewData = {
  stats: {
    students: number;
    classes: number;
    totalJanm: number;
    transactions: number;
    announcements: number;
    pendingUsers: number;
    pendingResets: number;
  };
  recentTx: (JanmTx & { userName: string })[];
  recentLogs: { id: number; actorName: string; action: string; detail: string; createdAt: string }[];
  violations: Record<string, number>;
  dailyJanm: { day: string; total: number }[];
  topStudents: { id: number; fullName: string; janm: number; avatarColor: string }[];
};

const VIOLATION_LABELS: { key: string; label: string }[] = [
  { key: "absence", label: "غیبت غیرموجه" },
  { key: "lateness", label: "تأخیر" },
  { key: "lateness_penalty", label: "جریمه سه تأخیر" },
  { key: "disorder", label: "بی‌نظمی" },
];

export default function OverviewTab() {
  const [data, setData] = useState<OverviewData | null>(null);

  useEffect(() => {
    apiCall("/api/admin/overview").then((r) => {
      if (r.ok) setData(r.data as OverviewData);
    });
  }, []);

  if (!data) {
    return (
      <div className="panel flex items-center justify-center gap-3 py-20 text-[var(--muted)]">
        <LoaderCircle size={20} className="animate-spin" />
        در حال بارگیری آمار…
      </div>
    );
  }

  const { stats } = data;
  const maxViolation = Math.max(1, ...VIOLATION_LABELS.map((v) => data.violations[v.key] ?? 0));
  const days = data.dailyJanm;
  const maxDay = Math.max(1, ...days.map((d) => Math.abs(d.total)));

  const cards = [
    { label: "دانش‌آموزان", value: stats.students, icon: Users, hue: "#8facff", href: "/list" },
    { label: "کلاس‌ها", value: stats.classes, icon: GraduationCap, hue: "#38bdf8", href: "/classes" },
    { label: "مجموع جنم", value: stats.totalJanm, icon: Gem, hue: "var(--gold)", gold: true, href: "/admin?tab=janm" },
    { label: "تراکنش‌های جنم", value: stats.transactions, icon: Activity, hue: "#c084fc", href: "/admin?tab=janm" },
    { label: "اطلاعیه‌های فعال", value: stats.announcements, icon: Megaphone, hue: "#4ade80", href: "/announcements" },
    { label: "در انتظار تأیید", value: stats.pendingUsers + stats.pendingResets, icon: UserPlus, hue: "#fb923c", href: "/admin?tab=students" },
  ];

  return (
    <div className="space-y-5">
      {/* کارت‌های آماری */}
      <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 xl:grid-cols-6">
        {cards.map((c) => (
          <Link key={c.label} href={c.href} className="panel group p-4 transition hover:border-[var(--border-strong)]">
            <span className="panel-inset flex h-9 w-9 items-center justify-center rounded-xl transition group-hover:scale-105" style={{ color: c.hue }}>
              <c.icon size={17} />
            </span>
            <div className={`mt-3 text-2xl font-black ${c.gold ? "gold-text" : ""}`}>{faNum(c.value)}</div>
            <div className="text-faint mt-0.5 text-[0.66rem] font-bold">{c.label}</div>
          </Link>
        ))}
      </div>

      <div className="grid items-start gap-5 lg:grid-cols-3">
        {/* سوابق اخیر جنم */}
        <section className="panel p-5 lg:col-span-2">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
            <Gem size={16} className="text-[var(--gold)]" />
            آخرین تغییرات جنم
          </h3>
          {data.recentTx.length === 0 ? (
            <p className="text-muted py-8 text-center text-sm">هنوز تراکنشی ثبت نشده است.</p>
          ) : (
            <ul className="divide-y divide-[var(--border)]">
              {data.recentTx.map((t) => (
                <li key={t.id} className="flex items-center gap-3 py-2.5">
                  <span
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[0.68rem] font-black"
                    style={{
                      background: t.amount > 0 ? "rgba(74,222,128,.1)" : t.amount < 0 ? "rgba(255,107,107,.09)" : "var(--panel-2)",
                      color: t.amount > 0 ? "var(--success)" : t.amount < 0 ? "var(--danger)" : "var(--muted)",
                    }}
                    dir="ltr"
                  >
                    {t.amount > 0 ? "+" : ""}
                    {fa(t.amount)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <span className="text-[0.8rem] font-bold">
                      {t.userName}
                    </span>
                    <span className="text-muted text-[0.74rem]"> — {t.reason}</span>
                    <div className="text-faint text-[0.64rem]">{faRelative(t.createdAt)} • {t.actorName}</div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* آمار تخلفات + نمودار روزانه */}
        <section className="panel p-5">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
            <TriangleAlert size={16} className="text-[var(--danger)]" />
            آمار انضباطی
          </h3>
          <div className="space-y-3">
            {VIOLATION_LABELS.map((v) => {
              const count = data.violations[v.key] ?? 0;
              return (
                <div key={v.key}>
                  <div className="flex justify-between text-[0.72rem] font-bold">
                    <span>{v.label}</span>
                    <span className="text-muted">{fa(count)}</span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--panel-2)" }}>
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${Math.round((count / maxViolation) * 100)}%`,
                        background: "linear-gradient(to left,#ff8a8a,#ff6b6b)",
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <h4 className="text-faint mt-5 mb-2 text-[0.68rem] font-extrabold">خالص جنم ۱۴ روز گذشته</h4>
          {days.length === 0 ? (
            <p className="text-faint py-3 text-center text-xs">داده‌ای نیست.</p>
          ) : (
            <div className="flex h-20 items-end gap-1" dir="ltr">
              {days.map((d) => (
                <div key={d.day} className="group relative flex-1" title={`${d.day}: ${d.total}`}>
                  <div
                    className="w-full rounded-t-sm transition group-hover:opacity-100"
                    style={{
                      height: `${Math.max(3, Math.round((Math.abs(d.total) / maxDay) * 76))}px`,
                      background: d.total >= 0 ? "linear-gradient(#4ade80,#16a34a)" : "linear-gradient(#ff8a8a,#dc2626)",
                      opacity: 0.8,
                    }}
                  />
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      <div className="grid items-start gap-5 lg:grid-cols-2">
        {/* فعالیت مدیران */}
        <section className="panel p-5">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
            <Activity size={16} style={{ color: "#c084fc" }} />
            آخرین فعالیت مدیران
          </h3>
          {data.recentLogs.length === 0 ? (
            <p className="text-muted py-6 text-center text-sm">فعالیتی ثبت نشده است.</p>
          ) : (
            <ul className="space-y-2.5">
              {data.recentLogs.map((l) => (
                <li key={l.id} className="panel-inset px-3.5 py-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[0.76rem] font-extrabold">{l.action}</span>
                    <span className="text-faint text-[0.62rem]">{faRelative(l.createdAt)}</span>
                  </div>
                  <p className="text-muted mt-1 truncate text-[0.72rem]">{l.detail}</p>
                  <div className="text-faint mt-0.5 text-[0.62rem] font-bold">{l.actorName}</div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* برترین‌ها */}
        <section className="panel p-5">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
            <KeyRound size={16} className="text-[var(--gold)]" />
            برترین‌های جنم
          </h3>
          <ul className="space-y-2">
            {data.topStudents.map((s, i) => (
              <li key={s.id}>
                <Link href={`/students/${s.id}`} className="panel-inset flex items-center gap-3 px-3.5 py-2.5 transition hover:border-[var(--border-strong)]">
                  <span className={`w-5 text-center text-xs font-black ${i === 0 ? "gold-text" : "text-faint"}`}>{fa(i + 1)}</span>
                  <Avatar name={s.fullName} color={s.avatarColor} size={30} />
                  <span className="min-w-0 flex-1 truncate text-[0.82rem] font-bold">{s.fullName}</span>
                  <span className="text-sm font-black" dir="ltr" style={{ color: s.janm > 0 ? "var(--gold)" : "var(--muted)" }}>
                    {faNum(s.janm)}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex items-center gap-2 text-[0.68rem] font-bold text-[var(--muted)]">
            <CalendarClock size={13} />
            آمار لحظه‌ای — {faDateTime(new Date().toISOString())}
          </div>
        </section>
      </div>
    </div>
  );
}
