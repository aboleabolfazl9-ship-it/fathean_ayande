"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "motion/react";
import { Check, LoaderCircle, Megaphone, Pencil, Plus, Trash2 } from "lucide-react";
import { EmptyState, PageHeader } from "@/components/ui";
import { Modal } from "@/components/modal";
import { useToast } from "@/components/providers";
import { fa, faDateTime, faRelative } from "@/lib/format";
import type { AnnouncementItem } from "@/lib/types";

export default function AnnouncementsClient({
  announcements,
  canManage,
}: {
  announcements: AnnouncementItem[];
  canManage: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [modal, setModal] = useState<"none" | "add" | "edit">("none");
  const [target, setTarget] = useState<AnnouncementItem | null>(null);
  const [deleting, setDeleting] = useState<AnnouncementItem | null>(null);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  function openAdd() {
    setTarget(null);
    setTitle("");
    setBody("");
    setModal("add");
  }
  function openEdit(a: AnnouncementItem) {
    setTarget(a);
    setTitle(a.title);
    setBody(a.body);
    setModal("edit");
  }

  async function save() {
    if (busy) return;
    setBusy(true);
    try {
      const isEdit = modal === "edit" && target;
      const res = await fetch(isEdit ? `/api/announcements/${target!.id}` : "/api/announcements", {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, body }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا در ذخیره");
      toast.push("success", isEdit ? "اطلاعیه ویرایش شد." : "اطلاعیه منتشر شد.");
      setModal("none");
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!deleting || busy) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/announcements/${deleting.id}`, { method: "DELETE", headers: { "Content-Type": "application/json" } });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا در حذف");
      toast.push("success", "اطلاعیه حذف شد.");
      setDeleting(null);
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="اطلاعیه‌ها"
        subtitle={`اطلاعیه‌های رسمی مدرسه • ${fa(announcements.length)} مورد`}
        icon={<Megaphone size={22} />}
      >
        {canManage && (
          <button onClick={openAdd} className="btn btn-primary">
            <Plus size={16} />
            انتشار اطلاعیه
          </button>
        )}
      </PageHeader>

      {announcements.length === 0 ? (
        <div className="panel rise">
          <EmptyState icon={<Megaphone size={26} />} title="اطلاعیه‌ای منتشر نشده است" hint="اطلاعیه‌های رسمی مدرسه اینجا نمایش داده می‌شوند." />
        </div>
      ) : (
        <div className="space-y-4">
          {announcements.map((a, i) => (
            <motion.article
              key={a.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.05, 0.35) }}
              className="panel shadow-soft relative overflow-hidden p-6"
            >
              <div className="absolute top-0 right-0 h-full w-1" style={{ background: "linear-gradient(#5d88ff,#2742b8)" }} />
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex items-start gap-3.5">
                  <span className="panel-inset flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-[var(--gold)]">
                    <Megaphone size={19} />
                  </span>
                  <div>
                    <h2 className="text-[1rem] font-extrabold">{a.title}</h2>
                    <div className="text-faint mt-1 flex flex-wrap items-center gap-2 text-[0.68rem] font-semibold">
                      <span className="badge">{faRelative(a.createdAt)}</span>
                      <span>{faDateTime(a.createdAt)}</span>
                      <span>• {a.createdByName}</span>
                      {a.updatedAt && <span className="badge badge-blue">ویرایش‌شده</span>}
                    </div>
                  </div>
                </div>
                {canManage && (
                  <div className="flex gap-1.5">
                    <button onClick={() => openEdit(a)} className="panel-inset flex h-9 w-9 items-center justify-center rounded-xl text-[var(--muted)] transition hover:text-[var(--gold)]" aria-label="ویرایش">
                      <Pencil size={15} />
                    </button>
                    <button onClick={() => setDeleting(a)} className="panel-inset flex h-9 w-9 items-center justify-center rounded-xl text-[var(--muted)] transition hover:text-[var(--danger)]" aria-label="حذف">
                      <Trash2 size={15} />
                    </button>
                  </div>
                )}
              </div>
              <p className="text-muted mt-4 text-[0.86rem] leading-8 whitespace-pre-wrap">{a.body}</p>
            </motion.article>
          ))}
        </div>
      )}

      <Modal open={modal !== "none"} onClose={() => setModal("none")} title={modal === "edit" ? "ویرایش اطلاعیه" : "انتشار اطلاعیه جدید"}>
        <div className="space-y-4">
          <div>
            <label className="label">عنوان اطلاعیه</label>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: برنامه هفته دفاع مقدس" />
          </div>
          <div>
            <label className="label">متن اطلاعیه</label>
            <textarea className="textarea" style={{ minHeight: 140 }} value={body} onChange={(e) => setBody(e.target.value)} placeholder="متن کامل اطلاعیه…" />
          </div>
          <button onClick={save} disabled={busy} className="btn btn-gold w-full">
            {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
            {modal === "edit" ? "ذخیره تغییرات" : "انتشار"}
          </button>
        </div>
      </Modal>

      <Modal open={deleting !== null} onClose={() => setDeleting(null)} title="حذف اطلاعیه">
        <p className="text-muted text-sm leading-7">اطلاعیه «{deleting?.title}» برای همیشه حذف شود؟</p>
        <div className="mt-5 flex gap-2">
          <button onClick={() => setDeleting(null)} className="btn btn-ghost flex-1">
            انصراف
          </button>
          <button onClick={remove} disabled={busy} className="btn btn-danger flex-1">
            {busy ? <LoaderCircle size={15} className="animate-spin" /> : <Trash2 size={15} />}
            حذف قطعی
          </button>
        </div>
      </Modal>
    </div>
  );
}
