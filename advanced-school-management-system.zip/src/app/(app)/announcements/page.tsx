import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { announcements } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import AnnouncementsClient from "./announcements-client";
import type { AnnouncementItem } from "@/lib/types";

export const metadata: Metadata = { title: "اطلاعیه‌ها" };

export default async function AnnouncementsPage() {
  const me = await getSessionUser();
  if (!me) redirect("/login");

  const rows = await db.select().from(announcements).orderBy(desc(announcements.createdAt)).limit(60);
  const items: AnnouncementItem[] = rows.map((a) => ({
    id: a.id,
    title: a.title,
    body: a.body,
    createdByName: a.createdByName ?? "مدیر",
    createdAt: a.createdAt.toISOString(),
    updatedAt: a.updatedAt?.toISOString() ?? null,
  }));

  return <AnnouncementsClient announcements={items} canManage={hasPerm(me, "content")} />;
}
