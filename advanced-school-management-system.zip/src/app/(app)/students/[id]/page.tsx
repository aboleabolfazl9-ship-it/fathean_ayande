import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, desc, eq, ne } from "drizzle-orm";
import { ArrowRight, Award, Clock3, Gem, GraduationCap, Hash, Shield, UserRound } from "lucide-react";
import { db } from "@/db";
import { baseMembers, bases, classes, honors, janmTransactions, users } from "@/db/schema";
import { getSessionUser, hasPerm, isAdmin } from "@/lib/auth";
import { fa, faDate, faDateTime } from "@/lib/format";
import { Avatar, JanmValue, TitleBadge } from "@/components/ui";
import { TX_KIND_LABELS } from "@/lib/types";
import ProfileActions from "./profile-actions";

export const metadata: Metadata = { title: "پروفایل دانش‌آموز" };

type Ctx = { params: Promise<{ id: string }> };

export default async function StudentProfilePage({ params }: Ctx) {
  const me = await getSessionUser();
  if (!me) redirect("/login");
  const { id } = await params;
  const uid = Number(id);
  if (!Number.isInteger(uid)) notFound();

  const [row] = await db
    .select({ u: users, className: classes.name, classCode: classes.code })
    .from(users)
    .leftJoin(classes, eq(classes.id, users.classId))
    .where(eq(users.id, uid))
    .limit(1);
  if (!row || row.u.role === "superadmin") notFound();
  const s = row.u;

  const all = await db
    .select({ id: users.id, janm: users.janm })
    .from(users)
    .where(and(ne(users.role, "superadmin"), eq(users.isApproved, true)));
  const rank = 1 + all.filter((x) => x.janm > s.janm).length;

  const txs = await db
    .select()
    .from(janmTransactions)
    .where(eq(janmTransactions.userId, uid))
    .orderBy(desc(janmTransactions.createdAt), desc(janmTransactions.id))
    .limit(50);

  const honorRows = await db
    .select()
    .from(honors)
    .where(eq(honors.userId, uid))
    .orderBy(desc(honors.awardDate), desc(honors.id))
    .limit(30);

  const membership = await db
    .select({ id: bases.id, name: bases.name, icon: bases.icon, hue: bases.hue, managerUserId: bases.managerUserId })
    .from(baseMembers)
    .innerJoin(bases, eq(bases.id, baseMembers.baseId))
    .where(eq(baseMembers.userId, uid));

  const admin = isAdmin(me);
  const canJanm = hasPerm(me, "janm");

  return (
    <div className="space-y-5">
      <Link href="/list" className="text-faint inline-flex items-center gap-1.5 text-xs font-bold hover:text-[var(--text)]">
        <ArrowRight size={14} />
        بازگشت به لیست مدرسه
      </Link>

      {/* کارت پروفایل */}
      <section className="panel shadow-soft rise relative overflow-hidden p-6 sm:p-8">
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(500px 200px at 85% 0%, rgba(79,124,255,.13), transparent 60%), radial-gradient(300px 160px at 5% 100%, rgba(231,189,85,.08), transparent 60%)",
          }}
        />
        <div className="relative flex flex-wrap items-center gap-5">
          <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={84} ring={admin && s.role !== "student"} className="shadow-soft" />
          <div className="min-w-0 flex-1">
            <h1 className="flex flex-wrap items-center gap-2.5 text-xl font-black tracking-tight sm:text-2xl">
              {s.fullName}
              {s.title && <TitleBadge title={s.title} />}
              {s.isBlocked && <span className="badge badge-red">حساب مسدود</span>}
            </h1>
            <div className="text-muted mt-2 flex flex-wrap items-center gap-2 text-xs font-semibold">
              <span className="badge badge-blue">
                <GraduationCap size={12} />
                {row.className ?? "بدون کلاس"}
              </span>
              <span className="badge" dir="ltr">
                <Hash size={11} />
                {s.username}
              </span>
              {s.role !== "student" && <span className="badge badge-gold">دسترسی مدیریتی</span>}
            </div>
          </div>
          {/* امتیاز */}
          <div className="flex items-center gap-6">
            <div className="text-center">
              <div className="gold-text text-4xl font-black" dir="ltr">
                {s.janm > 0 ? "+" : ""}
                {s.janm.toLocaleString("en-US").replace(/,/g, "٬").replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)])}
              </div>
              <div className="text-faint mt-1 flex items-center justify-center gap-1 text-[0.68rem] font-bold">
                <Gem size={11} className="text-[var(--gold)]" />
                جنم فعلی
              </div>
            </div>
            <div className="h-12 w-px bg-[var(--border)]" />
            <div className="text-center">
              <div className="text-4xl font-black">{fa(rank)}</div>
              <div className="text-faint mt-1 text-[0.68rem] font-bold">رتبه مدرسه</div>
            </div>
          </div>
        </div>

        {/* قرارگاه‌ها */}
        {membership.length > 0 && (
          <div className="relative mt-5 flex flex-wrap items-center gap-2">
            {membership.map((b) => (
              <Link key={b.id} href="/bases" className="badge badge-blue !py-1.5">
                <Shield size={11} />
                {b.name}
                {b.managerUserId === s.id && <span className="text-[var(--gold)]">(مدیر)</span>}
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* اقدامات مدیریتی */}
      {(canJanm || admin) && (
        <ProfileActions
          student={{
            id: s.id,
            fullName: s.fullName,
            username: s.username,
            classId: s.classId,
            className: row.className,
            classCode: row.classCode,
            role: s.role,
            title: s.title,
            janm: s.janm,
            isApproved: s.isApproved,
            isBlocked: s.isBlocked,
            avatarColor: s.avatarColor,
            avatarUrl: s.avatarUrl,
          }}
          canJanm={canJanm}
          canStudents={hasPerm(me, "students")}
        />
      )}

      <div className="grid items-start gap-5 lg:grid-cols-5">
        {/* افتخارات */}
        <section className="panel rise rise-2 p-5 lg:col-span-2">
          <h2 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
            <Award size={16} className="text-[var(--gold)]" />
            افتخارات
            <span className="badge ms-auto">{fa(honorRows.length)}</span>
          </h2>
          {honorRows.length === 0 ? (
            <div className="text-muted flex flex-col items-center gap-2 py-10 text-center text-sm">
              <Award size={24} className="text-faint" />
              هنوز افتخاری ثبت نشده است.
            </div>
          ) : (
            <ul className="space-y-3">
              {honorRows.map((h) => (
                <li key={h.id} className="panel-inset relative overflow-hidden px-4 py-3.5">
                  <div className="absolute top-0 right-0 h-full w-1" style={{ background: "linear-gradient(#f0cd74,#a8791b)" }} />
                  <div className="text-[0.86rem] font-extrabold">{h.title}</div>
                  {h.description && <p className="text-muted mt-1 text-[0.74rem] leading-6">{h.description}</p>}
                  <div className="text-faint mt-1.5 text-[0.66rem] font-bold">
                    {faDate(h.awardDate)}
                    {h.createdByName ? ` • ثبت: ${h.createdByName}` : ""}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* تاریخچه جنم */}
        <section className="panel rise rise-3 p-5 lg:col-span-3">
          <h2 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
            <Clock3 size={16} className="text-[var(--gold)]" />
            تاریخچه جنم
            <span className="badge ms-auto">{fa(txs.length)} سابقه</span>
          </h2>
          {txs.length === 0 ? (
            <div className="text-muted flex flex-col items-center gap-2 py-10 text-center text-sm">
              <Gem size={24} className="text-faint" />
              هنوز تغییری ثبت نشده است.
              <span className="text-faint text-xs">هیچ جنمی بدون ثبت سابقه تغییر نمی‌کند.</span>
            </div>
          ) : (
            <ul className="relative space-y-0.5">
              {txs.map((t) => (
                <li key={t.id} className="relative flex items-start gap-3.5 py-3">
                  <span
                    className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                    style={{
                      background:
                        t.amount > 0 ? "rgba(74,222,128,.1)" : t.amount < 0 ? "rgba(255,107,107,.09)" : "var(--panel-2)",
                      color: t.amount > 0 ? "var(--success)" : t.amount < 0 ? "var(--danger)" : "var(--muted)",
                    }}
                  >
                    <Gem size={14} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[0.84rem] font-bold">{t.reason}</span>
                      <span className="badge">{TX_KIND_LABELS[t.kind] ?? t.kind}</span>
                      {t.status === "corrected" && <span className="badge badge-red">ابطال‌شده</span>}
                      {t.kind === "correction" && <span className="badge badge-gold">اصلاحیه</span>}
                    </div>
                    {t.note && <p className="text-muted mt-1 text-[0.72rem] leading-5">یادداشت: {t.note}</p>}
                    <div className="text-faint mt-1 text-[0.66rem] font-semibold">
                      {faDateTime(t.createdAt)} • ثبت توسط {t.actorName}
                    </div>
                  </div>
                  <JanmValue value={t.amount} size="sm" />
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
