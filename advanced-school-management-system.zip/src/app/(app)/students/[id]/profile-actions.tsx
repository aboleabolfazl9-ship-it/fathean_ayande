"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Ban, Clock3, Gem, LoaderCircle, Minus, Pencil, Plus, ShieldCheck, TriangleAlert, Undo2, UserRoundX } from "lucide-react";
import { Modal } from "@/components/modal";
import { JanmAdjustModal } from "@/components/janm-adjust";
import { useToast } from "@/components/providers";
import { faDateTime } from "@/lib/format";
import type { JanmTx, StudentBrief } from "@/lib/types";

const QUICK = [
  { key: "increase" as const, label: "افزایش جنم", icon: Plus, cls: "btn-primary" },
  { key: "decrease" as const, label: "کاهش جنم", icon: Minus, cls: "btn-ghost" },
  { key: "absence" as const, label: "غیبت (۱۰-)", icon: UserRoundX, cls: "btn-ghost" },
  { key: "lateness" as const, label: "تأخیر", icon: Clock3, cls: "btn-ghost" },
  { key: "disorder" as const, label: "بی‌نظمی (۲-)", icon: TriangleAlert, cls: "btn-ghost" },
];

export default function ProfileActions({
  student,
  canJanm,
  canStudents,
}: {
  student: StudentBrief;
  canJanm: boolean;
  canStudents: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [adjustOpen, setAdjustOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  // اصلاح تراکنش‌ها
  const [txList, setTxList] = useState<JanmTx[] | null>(null);
  const [correctionTarget, setCorrectionTarget] = useState<JanmTx | null>(null);
  const [correctionNote, setCorrectionNote] = useState("");

  async function toggleBlock() {
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/students/${student.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isBlocked: !student.isBlocked }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا");
      toast.push("success", student.isBlocked ? "حساب رفع مسدودیت شد." : "حساب مسدود شد.");
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy(false);
    }
  }

  async function loadTxs() {
    try {
      const res = await fetch(`/api/janm?userId=${student.id}&limit=40`);
      const data = await res.json().catch(() => null);
      if (data?.ok) setTxList(data.data);
    } catch {
      toast.push("error", "بارگیری سوابق ممکن نشد.");
    }
  }

  async function correctTx() {
    if (!correctionTarget || busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/janm", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: correctionTarget.id, note: correctionNote }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا");
      toast.push("success", "تراکنش اصلاح شد و سابقه اصلاح ثبت گردید.");
      setCorrectionTarget(null);
      setCorrectionNote("");
      setTxList(null);
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <section className="panel rise rise-1 flex flex-wrap items-center gap-2.5 p-4">
        <span className="ms-1 inline-flex items-center gap-1.5 text-[0.72rem] font-extrabold text-[var(--gold)]">
          <ShieldCheck size={15} />
          اقدام مدیریتی مستقیم:
        </span>
        {canJanm &&
          QUICK.map((q) => (
            <button key={q.key} onClick={() => setAdjustOpen(true)} className={`btn ${q.cls} btn-sm`}>
              <q.icon size={14} />
              {q.label}
            </button>
          ))}
        {canJanm && (
          <button
            className="btn btn-ghost btn-sm"
            onClick={async () => {
              await loadTxs();
            }}
          >
            <Undo2 size={14} />
            اصلاح تراکنش اشتباه
          </button>
        )}
        {canStudents && (
          <button onClick={toggleBlock} disabled={busy} className="btn btn-danger btn-sm ms-auto">
            {busy ? <LoaderCircle size={14} className="animate-spin" /> : <Ban size={14} />}
            {student.isBlocked ? "رفع مسدودیت حساب" : "مسدود کردن حساب"}
          </button>
        )}
      </section>

      <JanmAdjustModal
        open={adjustOpen}
        onClose={() => setAdjustOpen(false)}
        students={[student]}
        initialIds={[student.id]}
        onDone={() => router.refresh()}
      />

      {/* انتخاب تراکنش برای اصلاح */}
      <Modal open={txList !== null && !correctionTarget} onClose={() => setTxList(null)} title="انتخاب تراکنش برای اصلاح" wide>
        <p className="text-muted mb-4 text-[0.76rem] leading-6">
          تراکنش اصلاح‌شده حذف نمی‌شود؛ ابطال می‌گردد و یک سابقه «اصلاحیه» با نام شما ثبت می‌شود.
        </p>
        <div className="max-h-[50dvh] space-y-2 overflow-y-auto">
          {(txList ?? []).filter((t) => t.status === "active").length === 0 && (
            <p className="text-faint py-8 text-center text-sm">تراکنش قابل اصلاحی وجود ندارد.</p>
          )}
          {(txList ?? [])
            .filter((t) => t.status === "active")
            .map((t) => (
              <button
                key={t.id}
                onClick={() => setCorrectionTarget(t)}
                className="panel-inset flex w-full items-center gap-3 px-4 py-3 text-right transition hover:border-[var(--border-strong)]"
              >
                <Pencil size={14} className="text-faint shrink-0" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[0.82rem] font-bold">{t.reason}</span>
                  <span className="text-faint text-[0.66rem]">{faDateTime(t.createdAt)} • {t.actorName}</span>
                </span>
                <span className="text-sm font-black" dir="ltr" style={{ color: t.amount > 0 ? "var(--success)" : t.amount < 0 ? "var(--danger)" : "var(--muted)" }}>
                  {t.amount > 0 ? "+" : ""}
                  {t.amount}
                </span>
              </button>
            ))}
        </div>
      </Modal>

      {/* تأیید اصلاح */}
      <Modal open={correctionTarget !== null} onClose={() => setCorrectionTarget(null)} title="تأیید اصلاح تراکنش">
        {correctionTarget && (
          <div className="space-y-4">
            <div className="panel-inset px-4 py-3 text-sm">
              <div className="font-bold">{correctionTarget.reason}</div>
              <div className="text-faint mt-1 text-[0.7rem]">
                {faDateTime(correctionTarget.createdAt)} • مبلغ: <span dir="ltr">{correctionTarget.amount}</span> جنم
              </div>
            </div>
            <p className="text-muted text-[0.76rem] leading-6">
              با تأیید، اثر این تراکنش خنثی می‌شود و سابقه اصلاح با نام شما در تاریخچه باقی می‌ماند.
            </p>
            <div>
              <label className="label">دلیل اصلاح</label>
              <input className="input" value={correctionNote} onChange={(e) => setCorrectionNote(e.target.value)} placeholder="مثلاً: ثبت اشتباه بود" />
            </div>
            <div className="flex gap-2">
              <button onClick={() => setCorrectionTarget(null)} className="btn btn-ghost flex-1">
                انصراف
              </button>
              <button onClick={correctTx} disabled={busy} className="btn btn-gold flex-1">
                {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Undo2 size={15} />}
                تأیید اصلاح
              </button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}
