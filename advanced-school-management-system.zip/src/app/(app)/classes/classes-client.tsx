"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import { Check, GraduationCap, LoaderCircle, Pencil, Plus, Trash2, Users } from "lucide-react";
import { Avatar, EmptyState, PageHeader, TitleBadge } from "@/components/ui";
import { Modal } from "@/components/modal";
import { useToast } from "@/components/providers";
import { fa, faNum } from "@/lib/format";
import type { ClassItem, StudentBrief } from "@/lib/types";

type ClassWithStudents = ClassItem & { students: StudentBrief[]; avgJanm: number };

export default function ClassesClient({
  classes,
  canManageClasses,
  canManageStudents,
}: {
  classes: ClassWithStudents[];
  canManageClasses: boolean;
  canManageStudents: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [selectedId, setSelectedId] = useState<number | null>(classes[0]?.id ?? null);
  const [busy, setBusy] = useState(false);

  // ویرایش دانش‌آموز
  const [editStudent, setEditStudent] = useState<StudentBrief | null>(null);
  const [editName, setEditName] = useState("");
  const [editClassId, setEditClassId] = useState("");

  // کلاس جدید / ویرایش کلاس
  const [classModal, setClassModal] = useState<"none" | "add" | "edit">("none");
  const [editClass, setEditClass] = useState<ClassWithStudents | null>(null);
  const [className, setClassName] = useState("");
  const [classCode, setClassCode] = useState("");
  const [deleteClass, setDeleteClass] = useState<ClassWithStudents | null>(null);

  const selected = useMemo(() => classes.find((c) => c.id === selectedId) ?? null, [classes, selectedId]);

  const total = classes.reduce((s, c) => s + (c.studentCount ?? 0), 0);

  async function call(path: string, init: RequestInit, okMsg: string): Promise<boolean> {
    if (busy) return false;
    setBusy(true);
    try {
      const res = await fetch(path, { ...init, headers: { "Content-Type": "application/json" } });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا در انجام عملیات");
      toast.push("success", okMsg);
      router.refresh();
      return true;
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function saveStudent() {
    if (!editStudent) return;
    const okRes = await call(
      `/api/students/${editStudent.id}`,
      {
        method: "PATCH",
        body: JSON.stringify({
          fullName: editName,
          classId: editClassId ? Number(editClassId) : undefined,
        }),
      },
      editClassId && Number(editClassId) !== editStudent.classId ? "دانش‌آموز منتقل و ویرایش شد." : "مشخصات ویرایش شد.",
    );
    if (okRes) setEditStudent(null);
  }

  async function saveClass() {
    const isEdit = classModal === "edit" && editClass;
    const okRes = await call(
      isEdit ? `/api/classes/${editClass!.id}` : "/api/classes",
      { method: isEdit ? "PATCH" : "POST", body: JSON.stringify({ name: className, code: classCode }) },
      isEdit ? "کلاس ویرایش شد." : "کلاس جدید ایجاد شد.",
    );
    if (okRes) {
      setClassModal("none");
      setEditClass(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="کلاس‌ها"
        subtitle={`${fa(classes.length)} کلاس • ${fa(total)} دانش‌آموز فعال`}
        icon={<GraduationCap size={22} />}
      >
        {canManageClasses && (
          <button
            onClick={() => {
              setClassName("");
              setClassCode("");
              setClassModal("add");
            }}
            className="btn btn-primary"
          >
            <Plus size={16} />
            افزودن کلاس
          </button>
        )}
      </PageHeader>

      {/* کارت‌های کلاس */}
      <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 lg:grid-cols-5">
        {classes.map((c, i) => {
          const on = c.id === selectedId;
          const best = c.students[0];
          return (
            <motion.button
              key={c.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => setSelectedId(c.id)}
              className="panel relative overflow-hidden p-4 text-right transition"
              style={{
                borderColor: on ? "rgba(231,189,85,.5)" : "var(--border)",
                background: on ? "rgba(231,189,85,.06)" : "var(--panel)",
              }}
            >
              {on && <div className="absolute top-0 right-4 left-4 h-0.5 rounded-full" style={{ background: "linear-gradient(to left,#f0cd74,#a8791b)" }} />}
              <div className="flex items-center justify-between">
                <span className="text-sm font-black sm:text-base">{c.name}</span>
                <span className="badge">{fa(c.studentCount ?? 0)}</span>
              </div>
              <div className="text-faint mt-2 text-[0.66rem] font-bold">
                میانگین جنم: <span dir="ltr">{faNum(c.avgJanm)}</span>
              </div>
              {best && (
                <div className="text-faint mt-1 truncate text-[0.66rem] font-bold">
                  برتر: <span className="text-gold">{best.fullName}</span>
                </div>
              )}
              {canManageClasses && (
                <div className="mt-3 flex gap-1.5">
                  <span
                    role="button"
                    tabIndex={0}
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditClass(c);
                      setClassName(c.name);
                      setClassCode(c.code);
                      setClassModal("edit");
                    }}
                    onKeyDown={(e) => e.key === "Enter" && (e.stopPropagation(), setEditClass(c), setClassName(c.name), setClassCode(c.code), setClassModal("edit"))}
                    className="panel-inset flex h-7 w-7 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--gold)]"
                  >
                    <Pencil size={12} />
                  </span>
                  <span
                    role="button"
                    tabIndex={0}
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteClass(c);
                    }}
                    onKeyDown={(e) => e.key === "Enter" && (e.stopPropagation(), setDeleteClass(c))}
                    className="panel-inset flex h-7 w-7 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--danger)]"
                  >
                    <Trash2 size={12} />
                  </span>
                </div>
              )}
            </motion.button>
          );
        })}
      </div>

      {/* فهرست کلاس انتخاب‌شده */}
      <AnimatePresence mode="wait">
        {selected && (
          <motion.section
            key={selected.id}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25 }}
            className="panel mt-5 overflow-hidden"
          >
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-5 py-4">
              <div className="flex items-center gap-3">
                <span className="panel-inset flex h-10 w-10 items-center justify-center rounded-xl text-[var(--gold)]">
                  <Users size={18} />
                </span>
                <div>
                  <h2 className="text-sm font-extrabold">{selected.name}</h2>
                  <p className="text-faint text-[0.68rem] font-semibold">
                    {fa(selected.studentCount ?? 0)} دانش‌آموز • مرتب‌شده بر اساس جنم
                  </p>
                </div>
              </div>
            </div>
            {selected.students.length === 0 ? (
              <EmptyState title="این کلاس هنوز دانش‌آموزی ندارد" icon={<Users size={26} />} />
            ) : (
              <ul className="divide-y divide-[var(--border)]">
                {selected.students.map((s, i) => (
                  <li key={s.id} className="flex items-center gap-3 px-4 py-3 transition hover:bg-[var(--panel-2)] sm:px-5">
                    <span
                      className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-[0.7rem] font-black"
                      style={
                        i === 0
                          ? { background: "linear-gradient(150deg,#f6dd9a,#caa038)", color: "#241a04" }
                          : { background: "var(--panel-2)", color: "var(--muted)" }
                      }
                    >
                      {fa(i + 1)}
                    </span>
                    <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={36} />
                    <Link href={`/students/${s.id}`} className="group min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-2">
                        <span className="truncate text-[0.85rem] font-bold transition group-hover:text-[var(--gold)]">{s.fullName}</span>
                        {s.title && <TitleBadge title={s.title} />}
                        {s.isBlocked && <span className="badge badge-red">مسدود</span>}
                      </span>
                      <span className="text-faint text-[0.66rem]" dir="ltr">
                        {s.username}
                      </span>
                    </Link>
                    <span
                      className="text-sm font-black"
                      dir="ltr"
                      style={{ color: s.janm > 0 ? "var(--gold)" : s.janm < 0 ? "var(--danger)" : "var(--muted)" }}
                    >
                      {faNum(s.janm)}
                    </span>
                    {canManageStudents && (
                      <button
                        onClick={() => {
                          setEditStudent(s);
                          setEditName(s.fullName);
                          setEditClassId(String(s.classId ?? ""));
                        }}
                        className="panel-inset flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--gold)]"
                        aria-label={`ویرایش ${s.fullName}`}
                      >
                        <Pencil size={14} />
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </motion.section>
        )}
      </AnimatePresence>

      {/* ویرایش دانش‌آموز */}
      <Modal open={editStudent !== null} onClose={() => setEditStudent(null)} title="ویرایش دانش‌آموز">
        {editStudent && (
          <div className="space-y-4">
            <div>
              <label className="label">نام و نام خانوادگی</label>
              <input className="input" value={editName} onChange={(e) => setEditName(e.target.value)} />
            </div>
            <div>
              <label className="label">انتقال به کلاس</label>
              <select className="select" value={editClassId} onChange={(e) => setEditClassId(e.target.value)}>
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <button onClick={saveStudent} disabled={busy} className="btn btn-gold w-full">
              {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
              ذخیره تغییرات
            </button>
          </div>
        )}
      </Modal>

      {/* کلاس جدید / ویرایش */}
      <Modal open={classModal !== "none"} onClose={() => setClassModal("none")} title={classModal === "edit" ? "ویرایش کلاس" : "افزودن کلاس جدید"}>
        <div className="space-y-4">
          <div>
            <label className="label">نام کلاس</label>
            <input className="input" value={className} onChange={(e) => setClassName(e.target.value)} placeholder="مثلاً: کلاس ۱۰/۱" />
          </div>
          <div>
            <label className="label">کد کلاس (انگلیسی)</label>
            <input className="input" dir="ltr" style={{ textAlign: "left" }} value={classCode} onChange={(e) => setClassCode(e.target.value)} placeholder="101" />
          </div>
          <button onClick={saveClass} disabled={busy} className="btn btn-gold w-full">
            {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
            {classModal === "edit" ? "ذخیره تغییرات" : "ایجاد کلاس"}
          </button>
        </div>
      </Modal>

      {/* حذف کلاس */}
      <Modal open={deleteClass !== null} onClose={() => setDeleteClass(null)} title="حذف کلاس">
        <p className="text-muted text-sm leading-7">
          حذف «{deleteClass?.name}» فقط در صورتی ممکن است که دانش‌آموزی نداشته باشد.
        </p>
        <div className="mt-5 flex gap-2">
          <button onClick={() => setDeleteClass(null)} className="btn btn-ghost flex-1">
            انصراف
          </button>
          <button
            onClick={async () => {
              if (!deleteClass) return;
              const okRes = await call(`/api/classes/${deleteClass.id}`, { method: "DELETE", body: "{}" }, "کلاس حذف شد.");
              if (okRes) {
                setDeleteClass(null);
                if (selectedId === deleteClass.id) setSelectedId(classes.find((c) => c.id !== deleteClass.id)?.id ?? null);
              }
            }}
            disabled={busy}
            className="btn btn-danger flex-1"
          >
            {busy ? <LoaderCircle size={15} className="animate-spin" /> : <Trash2 size={15} />}
            حذف قطعی
          </button>
        </div>
      </Modal>
    </div>
  );
}
