import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { asc, desc, eq, ne, and } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import ClassesClient from "./classes-client";
import type { ClassItem, StudentBrief } from "@/lib/types";

export const metadata: Metadata = { title: "کلاس‌ها" };

export default async function ClassesPage() {
  const me = await getSessionUser();
  if (!me) redirect("/login");

  const classRows = await db.select().from(classes).orderBy(asc(classes.code));
  const studentRows = await db
    .select({ u: users, className: classes.name, classCode: classes.code })
    .from(users)
    .leftJoin(classes, eq(classes.id, users.classId))
    .where(and(ne(users.role, "superadmin"), eq(users.isApproved, true)))
    .orderBy(asc(users.fullName));

  const byClass = new Map<number, StudentBrief[]>();
  for (const r of studentRows) {
    if (r.u.classId == null) continue;
    const brief: StudentBrief = {
      id: r.u.id,
      fullName: r.u.fullName,
      username: r.u.username,
      classId: r.u.classId,
      className: r.className,
      classCode: r.classCode,
      role: r.u.role,
      title: r.u.title,
      janm: r.u.janm,
      isApproved: r.u.isApproved,
      isBlocked: r.u.isBlocked,
      avatarColor: r.u.avatarColor,
      avatarUrl: r.u.avatarUrl,
    };
    if (!byClass.has(r.u.classId)) byClass.set(r.u.classId, []);
    byClass.get(r.u.classId)!.push(brief);
  }

  // رتبه هر دانش‌آموز در کلاس خودش (بر اساس جنم)
  const items: (ClassItem & { students: StudentBrief[]; avgJanm: number })[] = classRows.map((c) => {
    const list = (byClass.get(c.id) ?? []).sort((a, b) => b.janm - a.janm);
    return {
      id: c.id,
      name: c.name,
      code: c.code,
      studentCount: list.length,
      students: list,
      avgJanm: list.length ? Math.round(list.reduce((s, x) => s + x.janm, 0) / list.length) : 0,
    };
  });

  return (
    <ClassesClient
      classes={items}
      canManageClasses={hasPerm(me, "classes")}
      canManageStudents={hasPerm(me, "students")}
    />
  );
}
