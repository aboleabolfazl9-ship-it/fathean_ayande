import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { asc, desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { baseMembers, bases, classes, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import BasesClient from "./bases-client";
import type { BaseItem, StudentBrief } from "@/lib/types";

export const metadata: Metadata = { title: "قرارگاه‌ها" };

export default async function BasesPage() {
  const me = await getSessionUser();
  if (!me) redirect("/login");

  const baseRows = await db.select().from(bases).orderBy(asc(bases.id));
  const memberRows = await db
    .select({
      baseId: baseMembers.baseId,
      id: users.id,
      fullName: users.fullName,
      className: classes.name,
      avatarColor: users.avatarColor,
      avatarUrl: users.avatarUrl,
    })
    .from(baseMembers)
    .innerJoin(users, eq(users.id, baseMembers.userId))
    .leftJoin(classes, eq(classes.id, users.classId))
    .orderBy(asc(users.fullName));

  const items: BaseItem[] = baseRows.map((b) => ({
    id: b.id,
    slug: b.slug,
    name: b.name,
    managerName: b.managerName,
    managerUserId: b.managerUserId,
    description: b.description,
    icon: b.icon,
    hue: b.hue,
    members: memberRows
      .filter((m) => m.baseId === b.id)
      .map((m) => ({
        id: m.id,
        fullName: m.fullName,
        className: m.className,
        avatarColor: m.avatarColor,
        avatarUrl: m.avatarUrl,
      })),
  }));

  let students: StudentBrief[] = [];
  const canManage = hasPerm(me, "bases");
  if (canManage) {
    const rows = await db
      .select({ u: users, className: classes.name, classCode: classes.code })
      .from(users)
      .leftJoin(classes, eq(classes.id, users.classId))
      .where(ne(users.role, "superadmin"))
      .orderBy(desc(users.janm));
    students = rows.map((r) => ({
      id: r.u.id,
      fullName: r.u.fullName,
      username: r.u.username,
      classId: r.u.classId,
      className: r.className,
      classCode: r.classCode,
      role: r.u.role,
      title: r.u.title,
      janm: r.u.janm,
      isApproved: r.u.isApproved,
      isBlocked: r.u.isBlocked,
      avatarColor: r.u.avatarColor,
      avatarUrl: r.u.avatarUrl,
    }));
  }

  return <BasesClient bases={items} students={students} canManage={canManage} />;
}
