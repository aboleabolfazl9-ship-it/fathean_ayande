"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "motion/react";
import {
  BookOpenText,
  Check,
  Clapperboard,
  Crown,
  GraduationCap,
  LoaderCircle,
  Search,
  Shield,
  ShieldCheck,
  UserPlus,
  Users,
  X,
  Zap,
} from "lucide-react";
import { Avatar, EmptyState, PageHeader } from "@/components/ui";
import { Modal } from "@/components/modal";
import { useToast } from "@/components/providers";
import { fa, faNum } from "@/lib/format";
import type { BaseItem, StudentBrief } from "@/lib/types";

const ICONS: Record<string, typeof Shield> = {
  book: BookOpenText,
  clapper: Clapperboard,
  shield: ShieldCheck,
  grad: GraduationCap,
  zap: Zap,
};

const HUES: Record<string, { border: string; glow: string; chip: string; bar: string }> = {
  gold: {
    border: "rgba(231,189,85,.35)",
    glow: "radial-gradient(320px 160px at 85% 0%, rgba(231,189,85,.14), transparent 65%)",
    chip: "linear-gradient(150deg,#f0cd74,#a8791b)",
    bar: "linear-gradient(to left,#f0cd74,#a8791b)",
  },
  violet: {
    border: "rgba(192,132,252,.35)",
    glow: "radial-gradient(320px 160px at 85% 0%, rgba(192,132,252,.14), transparent 65%)",
    chip: "linear-gradient(150deg,#c084fc,#6d23b0)",
    bar: "linear-gradient(to left,#c084fc,#6d23b0)",
  },
  sky: {
    border: "rgba(56,189,248,.35)",
    glow: "radial-gradient(320px 160px at 85% 0%, rgba(56,189,248,.13), transparent 65%)",
    chip: "linear-gradient(150deg,#38bdf8,#0c4a6e)",
    bar: "linear-gradient(to left,#38bdf8,#075985)",
  },
  indigo: {
    border: "rgba(129,140,248,.4)",
    glow: "radial-gradient(320px 160px at 85% 0%, rgba(129,140,248,.15), transparent 65%)",
    chip: "linear-gradient(150deg,#818cf8,#3730a3)",
    bar: "linear-gradient(to left,#818cf8,#3730a3)",
  },
  amber: {
    border: "rgba(251,146,60,.35)",
    glow: "radial-gradient(320px 160px at 85% 0%, rgba(251,146,60,.13), transparent 65%)",
    chip: "linear-gradient(150deg,#fbbf24,#b45309)",
    bar: "linear-gradient(to left,#fbbf24,#b45309)",
  },
  blue: {
    border: "rgba(79,124,255,.4)",
    glow: "radial-gradient(320px 160px at 85% 0%, rgba(79,124,255,.16), transparent 65%)",
    chip: "linear-gradient(150deg,#5d88ff,#2742b8)",
    bar: "linear-gradient(to left,#5d88ff,#2742b8)",
  },
};

export default function BasesClient({
  bases,
  students,
  canManage,
}: {
  bases: BaseItem[];
  students: StudentBrief[];
  canManage: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [managing, setManaging] = useState<BaseItem | null>(null);
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState(false);
  const [editName, setEditName] = useState("");
  const [editManager, setEditManager] = useState("");
  const [editDesc, setEditDesc] = useState("");

  const candidates = useMemo(() => {
    if (!managing) return [];
    const memberIds = new Set(managing.members.map((m) => m.id));
    let list = students.filter((s) => !memberIds.has(s.id) && s.isApproved && !s.isBlocked);
    if (search.trim()) list = list.filter((s) => s.fullName.includes(search.trim()));
    return list.slice(0, 30);
  }, [managing, students, search]);

  function openManage(b: BaseItem) {
    setManaging(b);
    setEditName(b.name);
    setEditManager(b.managerName);
    setEditDesc(b.description);
    setSearch("");
  }

  async function api(path: string, init: RequestInit, successMsg: string) {
    setBusy(true);
    try {
      const res = await fetch(path, { ...init, headers: { "Content-Type": "application/json" } });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا در انجام عملیات");
      toast.push("success", successMsg);
      router.refresh();
      return true;
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function saveInfo() {
    if (!managing) return;
    const okRes = await api(
      `/api/bases/${managing.id}`,
      {
        method: "PATCH",
        body: JSON.stringify({ name: editName, managerName: editManager, description: editDesc }),
      },
      "اطلاعات قرارگاه به‌روزرسانی شد.",
    );
    if (okRes) setManaging(null);
  }

  async function addMember(userId: number) {
    if (!managing) return;
    const okRes = await api(`/api/bases/${managing.id}`, { method: "POST", body: JSON.stringify({ userId }) }, "عضو به قرارگاه اضافه شد.");
    if (okRes) setManaging(null);
  }

  async function removeMember(userId: number) {
    if (!managing) return;
    const okRes = await api(`/api/bases/${managing.id}?userId=${userId}`, { method: "DELETE", body: "{}" }, "عضو از قرارگاه حذف شد.");
    if (okRes) setManaging(null);
  }

  return (
    <div>
      <PageHeader
        title="قرارگاه‌ها"
        subtitle="پنج قرارگاه تخصصی مدرسه، هر یک با مأموریت و تیم اختصاصی"
        icon={<Shield size={22} />}
      />

      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {bases.map((b, i) => {
          const Icon = ICONS[b.icon] ?? ShieldCheck;
          const hue = HUES[b.hue] ?? HUES.blue;
          return (
            <motion.section
              key={b.id}
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07, duration: 0.45, ease: [0.22, 0.9, 0.3, 1] }}
              className={`panel group relative flex flex-col overflow-hidden p-6 transition hover:border-[var(--border-strong)] sm:col-span-1 ${
                i === 0 && bases.length % 2 === 1 ? "sm:col-span-2 xl:col-span-1" : ""
              }`}
              style={{ borderColor: "var(--border)" }}
            >
              <div className="pointer-events-none absolute inset-0 opacity-90" style={{ background: hue.glow }} />
              <div className="absolute top-0 right-6 left-6 h-0.5 rounded-full opacity-70" style={{ background: hue.bar }} />

              <div className="relative flex items-start justify-between">
                <span className="flex h-13 w-13 items-center justify-center rounded-2xl text-white shadow-soft" style={{ background: hue.chip, height: 52, width: 52 }}>
                  <Icon size={24} strokeWidth={1.8} />
                </span>
                <span className="badge">{fa(b.members.length)} عضو</span>
              </div>

              <h2 className="relative mt-4 text-lg font-black tracking-tight">{b.name}</h2>
              <p className="text-muted relative mt-2 flex-1 text-[0.8rem] leading-7">{b.description}</p>

              <div className="relative mt-4 flex items-center gap-2.5 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] px-3 py-2.5">
                <Crown size={15} className="shrink-0 text-[var(--gold)]" />
                <span className="text-faint text-[0.68rem] font-bold">مدیر قرارگاه:</span>
                <span className="truncate text-[0.8rem] font-extrabold">{b.managerName}</span>
              </div>

              {b.members.length > 0 && (
                <div className="relative mt-4 flex items-center justify-between">
                  <div className="flex -space-x-2.5" dir="ltr">
                    {b.members.slice(0, 5).map((m) => (
                      <Avatar key={m.id} name={m.fullName} color={m.avatarColor} url={m.avatarUrl} size={30} className="ring-2 ring-[var(--bg)]" />
                    ))}
                  </div>
                  <span className="text-faint text-[0.66rem] font-bold">
                    {b.members.length > 5 ? `+${faNum(b.members.length - 5)} عضو دیگر` : `${fa(b.members.length)} عضو فعال`}
                  </span>
                </div>
              )}

              {canManage && (
                <button onClick={() => openManage(b)} className="btn btn-ghost btn-sm relative mt-4 w-full">
                  <Users size={14} />
                  مدیریت قرارگاه و اعضا
                </button>
              )}
            </motion.section>
          );
        })}
      </div>

      {bases.length === 0 && <EmptyState title="قرارگاهی ثبت نشده است" icon={<Shield size={26} />} />}

      {/* پنجره مدیریت */}
      <Modal open={managing !== null} onClose={() => setManaging(null)} title={managing ? `مدیریت ${managing.name}` : ""} wide>
        {managing && (
          <div className="space-y-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label">نام قرارگاه</label>
                <input className="input" value={editName} onChange={(e) => setEditName(e.target.value)} />
              </div>
              <div>
                <label className="label">نام مدیر قرارگاه</label>
                <input className="input" value={editManager} onChange={(e) => setEditManager(e.target.value)} />
              </div>
              <div className="sm:col-span-2">
                <label className="label">توضیحات</label>
                <textarea className="textarea" value={editDesc} onChange={(e) => setEditDesc(e.target.value)} />
              </div>
              <button onClick={saveInfo} disabled={busy} className="btn btn-primary sm:col-span-2">
                {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
                ذخیره اطلاعات
              </button>
            </div>

            <hr className="hr-gold" />

            {/* اعضا */}
            <div>
              <h4 className="mb-2 flex items-center gap-2 text-[0.8rem] font-extrabold">
                <Users size={15} className="text-[var(--gold)]" />
                اعضای فعلی ({fa(managing.members.length)})
              </h4>
              {managing.members.length === 0 ? (
                <p className="text-faint py-2 text-xs">عضوی ثبت نشده است.</p>
              ) : (
                <div className="mb-4 flex flex-wrap gap-2">
                  {managing.members.map((m) => (
                    <span key={m.id} className="panel-inset flex items-center gap-2 rounded-xl px-2.5 py-1.5">
                      <Avatar name={m.fullName} color={m.avatarColor} url={m.avatarUrl} size={24} />
                      <span className="text-[0.74rem] font-bold">{m.fullName}</span>
                      <button
                        onClick={() => removeMember(m.id)}
                        disabled={busy}
                        className="text-faint transition hover:text-[var(--danger)]"
                        aria-label={`حذف ${m.fullName}`}
                      >
                        <X size={13} />
                      </button>
                    </span>
                  ))}
                </div>
              )}

              <h4 className="mb-2 flex items-center gap-2 text-[0.8rem] font-extrabold">
                <UserPlus size={15} className="text-[var(--success)]" />
                افزودن عضو جدید
              </h4>
              <div className="panel-inset overflow-hidden">
                <div className="relative border-b border-[var(--border)]">
                  <Search size={15} className="text-faint absolute top-1/2 right-3 -translate-y-1/2" />
                  <input
                    className="w-full bg-transparent py-2.5 ps-4 pe-9 text-[0.82rem] outline-none"
                    placeholder="جست‌وجوی دانش‌آموز…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <div className="max-h-48 overflow-y-auto">
                  {candidates.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => addMember(s.id)}
                      disabled={busy}
                      className="flex w-full items-center gap-3 px-3 py-2 text-right transition hover:bg-[var(--panel-2)]"
                    >
                      <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={30} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[0.8rem] font-bold">{s.fullName}</span>
                        <span className="text-faint text-[0.66rem]">{s.className}</span>
                      </span>
                      <UserPlus size={15} className="text-faint shrink-0" />
                    </button>
                  ))}
                  {candidates.length === 0 && <div className="text-faint py-5 text-center text-xs">دانش‌آموز دیگری باقی نمانده است.</div>}
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
