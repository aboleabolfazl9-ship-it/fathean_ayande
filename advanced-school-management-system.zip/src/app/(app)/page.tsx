import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { and, asc, desc, eq, ne, sql } from "drizzle-orm";
import {
  ArrowLeft,
  CalendarClock,
  Gem,
  ListOrdered,
  Megaphone,
  Medal,
  Shield,
  Trophy,
  History,
  GraduationCap,
} from "lucide-react";
import { db } from "@/db";
import { announcements, classes, exams, honors, janmTransactions, users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { fa, faDate, faDateTime, faNum } from "@/lib/format";
import { Avatar, JanmValue, TitleBadge } from "@/components/ui";
import { CountUp, JanmSpark } from "./dashboard-widgets";

export const metadata: Metadata = { title: "داشبورد" };

function greeting() {
  const h = new Date().getHours();
  if (h < 6) return "شب بخیر";
  if (h < 12) return "صبح بخیر";
  if (h < 15) return "ظهر بخیر";
  if (h < 18) return "عصر بخیر";
  return "شب بخیر";
}

export default async function DashboardPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const isStudent = user.role !== "superadmin";

  const [cls] = user.classId
    ? await db.select().from(classes).where(eq(classes.id, user.classId)).limit(1)
    : [null];

  const [rankRow] = isStudent
    ? await db
        .select({ rank: sql<number>`(select count(*)::int + 1 from ${users} u2 where u2.role != 'superadmin' and u2.is_approved and u2.janm > ${user.janm})` })
        .from(users)
        .where(eq(users.id, user.id))
        .limit(1)
    : [{ rank: 0 }];

  const [studentCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users)
    .where(and(ne(users.role, "superadmin"), eq(users.isApproved, true)));

  const [honorCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(honors)
    .where(eq(honors.userId, user.id));

  const lastTx = await db
    .select()
    .from(janmTransactions)
    .where(eq(janmTransactions.userId, user.id))
    .orderBy(desc(janmTransactions.createdAt), desc(janmTransactions.id))
    .limit(6);

  const latestNews = user.notifyPrefs?.announcements === false
    ? []
    : await db.select().from(announcements).orderBy(desc(announcements.createdAt)).limit(3);

  const upcomingExams =
    user.notifyPrefs?.exams === false
      ? []
      : await db.select().from(exams).orderBy(asc(exams.examDate)).limit(2);

  // نقاط نمودار: تجمعی از قدیم به جدید
  const sparkBase = [...lastTx.filter((t) => t.status !== "corrected")].reverse();
  let acc = user.janm - sparkBase.filter((t) => t.status === "active").reduce((s, t) => s + t.amount, 0);
  const sparkPoints = [acc, ...sparkBase.filter((t) => t.status === "active").map((t) => (acc += t.amount))];

  const quickLinks = [
    { href: "/list", label: "لیست مدرسه", desc: "رتبه‌بندی جنم همه دانش‌آموزان", icon: ListOrdered, hue: "#4f7cff" },
    { href: "/bases", label: "قرارگاه‌ها", desc: "پنج قرارگاه تخصصی مدرسه", icon: Shield, hue: "#c084fc" },
    { href: "/exams", label: "برنامه امتحانات", desc: "تاریخ‌های مهم ارزشیابی", icon: CalendarClock, hue: "#38bdf8" },
    { href: "/honors", label: "افتخارات", desc: "دستاوردهای دانش‌آموزان", icon: Trophy, hue: "#e7bd55" },
  ];

  return (
    <div>
      {/* سربرگ خوش‌آمد */}
      <section className="panel shadow-soft rise relative overflow-hidden p-6 sm:p-8">
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(600px 240px at 90% 0%, rgba(79,124,255,.14), transparent 60%), radial-gradient(400px 200px at 0% 100%, rgba(231,189,85,.09), transparent 60%)",
          }}
        />
        <div className="relative flex flex-wrap items-center gap-5">
          <Avatar name={user.fullName} color={user.avatarColor} url={user.avatarUrl} size={76} ring={user.role !== "student"} className="shadow-soft" />
          <div className="min-w-0 flex-1">
            <div className="text-muted text-sm font-semibold">
              {greeting()}،
            </div>
            <h1 className="mt-0.5 flex flex-wrap items-center gap-2 text-xl font-black tracking-tight sm:text-2xl">
              {user.fullName}
              {user.title && <TitleBadge title={user.title} />}
            </h1>
            <div className="text-muted mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-semibold">
              <span className="badge badge-blue">
                <GraduationCap size={12} />
                {cls?.name ?? "مدیریت سامانه"}
              </span>
              <span>نام کاربری: <span dir="ltr" className="font-bold">{fa(user.username)}</span></span>
              <span>{faDate(new Date())}</span>
            </div>
          </div>
          {isStudent && (
            <Link
              href="/settings"
              className="btn btn-ghost btn-sm"
            >
              ویرایش پروفایل
              <ArrowLeft size={14} />
            </Link>
          )}
        </div>
      </section>

      {/* کارت‌های آماری */}
      <section className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="panel rise rise-1 relative overflow-hidden p-5">
          <div className="flex items-center justify-between">
            <span className="text-muted text-xs font-bold">میزان جنم فعلی</span>
            <span className="panel-inset flex h-9 w-9 items-center justify-center rounded-xl text-[var(--gold)]">
              <Gem size={17} />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            {isStudent ? (
              <CountUp value={user.janm} className="gold-text text-4xl font-black tracking-tight" />
            ) : (
              <span className="text-faint text-sm font-bold">—</span>
            )}
            {isStudent && <span className="text-faint text-xs font-bold">جنم</span>}
          </div>
          <div className="mt-3">
            <JanmSpark points={sparkPoints} positive={user.janm >= 0} />
          </div>
        </div>

        <div className="panel rise rise-2 p-5">
          <div className="flex items-center justify-between">
            <span className="text-muted text-xs font-bold">رتبه در مدرسه</span>
            <span className="panel-inset flex h-9 w-9 items-center justify-center rounded-xl" style={{ color: "#8facff" }}>
              <Medal size={17} />
            </span>
          </div>
          <div className="mt-3 text-3xl font-black">
            {isStudent ? (
              <>
                <span className="gold-text">{fa(rankRow?.rank ?? 0)}</span>
                <span className="text-faint text-sm font-bold"> از {fa(studentCount.count)}</span>
              </>
            ) : (
              <span className="text-faint text-sm font-bold">—</span>
            )}
          </div>
          <p className="text-faint mt-2 text-[0.72rem] font-semibold">بر اساس میزان جنم — به‌روزرسانی زنده</p>
        </div>

        <div className="panel rise rise-3 p-5">
          <div className="flex items-center justify-between">
            <span className="text-muted text-xs font-bold">کلاس</span>
            <span className="panel-inset flex h-9 w-9 items-center justify-center rounded-xl" style={{ color: "#38bdf8" }}>
              <GraduationCap size={17} />
            </span>
          </div>
          <div className="mt-3 text-2xl font-black">{cls?.name ?? "—"}</div>
          <Link href="/classes" className="text-faint mt-2 inline-flex items-center gap-1 text-[0.72rem] font-bold hover:text-[var(--text)]">
            مشاهده کلاس‌ها <ArrowLeft size={12} />
          </Link>
        </div>

        <div className="panel rise rise-4 p-5">
          <div className="flex items-center justify-between">
            <span className="text-muted text-xs font-bold">افتخارات</span>
            <span className="panel-inset flex h-9 w-9 items-center justify-center rounded-xl text-[var(--gold)]">
              <Trophy size={17} />
            </span>
          </div>
          <div className="mt-3 text-3xl font-black">
            <span className="gold-text">{fa(honorCount.count)}</span>
          </div>
          <Link href="/honors" className="text-faint mt-2 inline-flex items-center gap-1 text-[0.72rem] font-bold hover:text-[var(--text)]">
            دیواره افتخار <ArrowLeft size={12} />
          </Link>
        </div>
      </section>

      <div className="mt-5 grid gap-5 lg:grid-cols-5">
        {/* آخرین تغییرات جنم */}
        <section className="panel rise rise-2 p-5 lg:col-span-3">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-sm font-extrabold">
              <History size={16} className="text-[var(--gold)]" />
              آخرین تغییرات جنم
            </h2>
            {isStudent && (
              <Link href={`/students/${user.id}`} className="text-faint inline-flex items-center gap-1 text-[0.72rem] font-bold hover:text-[var(--text)]">
                تاریخچه کامل <ArrowLeft size={12} />
              </Link>
            )}
          </div>
          {lastTx.length === 0 ? (
            <div className="text-muted flex flex-col items-center gap-2 py-10 text-center text-sm">
              <Gem size={26} className="text-faint" />
              هنوز تغییری در جنم شما ثبت نشده است.
              <span className="text-faint text-xs">جنم اولیه همه دانش‌آموزان صفر است.</span>
            </div>
          ) : (
            <ul className="divide-y divide-[var(--border)]">
              {lastTx.map((t) => (
                <li key={t.id} className="flex items-center gap-3 py-3">
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                    style={{
                      background: t.amount > 0 ? "rgba(74,222,128,.12)" : t.amount < 0 ? "rgba(255,107,107,.1)" : "var(--panel-2)",
                      color: t.amount > 0 ? "var(--success)" : t.amount < 0 ? "var(--danger)" : "var(--muted)",
                    }}
                  >
                    <Gem size={15} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[0.84rem] font-bold">
                      {t.reason}
                      {t.status === "corrected" && <span className="badge badge-red ms-2">ابطال‌شده</span>}
                    </div>
                    <div className="text-faint mt-0.5 text-[0.68rem]">
                      {faDateTime(t.createdAt)} • ثبت توسط {t.actorName}
                    </div>
                  </div>
                  <JanmValue value={t.amount} size="sm" />
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* اعلان‌ها و امتحان نزدیک */}
        <div className="space-y-5 lg:col-span-2">
          {upcomingExams.length > 0 && (
            <section className="panel rise rise-3 p-5">
              <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold">
                <CalendarClock size={16} style={{ color: "#38bdf8" }} />
                امتحانات پیش‌رو
              </h2>
              <ul className="space-y-2.5">
                {upcomingExams.map((e) => (
                  <li key={e.id} className="panel-inset flex items-center justify-between px-3.5 py-3">
                    <span className="text-[0.84rem] font-bold">{e.title}</span>
                    <span className="badge badge-blue">{faDate(e.examDate)}</span>
                  </li>
                ))}
              </ul>
              <Link href="/exams" className="text-faint mt-3 inline-flex items-center gap-1 text-[0.72rem] font-bold hover:text-[var(--text)]">
                برنامه کامل <ArrowLeft size={12} />
              </Link>
            </section>
          )}

          <section className="panel rise rise-4 p-5">
            <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold">
              <Megaphone size={16} className="text-[var(--gold)]" />
              اعلان‌های مدرسه
            </h2>
            {latestNews.length === 0 ? (
              <p className="text-muted py-6 text-center text-sm">اعلانی وجود ندارد.</p>
            ) : (
              <ul className="space-y-2.5">
                {latestNews.map((n) => (
                  <li key={n.id}>
                    <Link href="/announcements" className="panel-inset block px-3.5 py-3 transition hover:border-[var(--border-strong)]">
                      <div className="text-[0.84rem] font-bold">{n.title}</div>
                      <div className="text-faint mt-1 text-[0.68rem]">{faDate(n.createdAt)} • {n.createdByName}</div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>

      {/* میانبرها */}
      <section className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {quickLinks.map((q, i) => (
          <Link
            key={q.href}
            href={q.href}
            className={`panel rise rise-${(i % 4) + 1} group p-5 transition hover:border-[var(--border-strong)] hover:bg-[var(--panel-2)]`}
          >
            <span className="panel-inset flex h-10 w-10 items-center justify-center rounded-xl transition group-hover:scale-105" style={{ color: q.hue }}>
              <q.icon size={19} />
            </span>
            <div className="mt-3 text-sm font-extrabold">{q.label}</div>
            <div className="text-faint mt-1 text-[0.7rem] font-semibold">{q.desc}</div>
          </Link>
        ))}
      </section>
    </div>
  );
}
