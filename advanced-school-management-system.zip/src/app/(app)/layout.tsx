import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { classes } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { AppShell } from "@/components/app-shell";
import { ToastProvider } from "@/components/providers";
import type { SessionUser } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function ProtectedLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  let className: string | null = null;
  if (user.classId) {
    const [cls] = await db.select().from(classes).where(eq(classes.id, user.classId)).limit(1);
    className = cls?.name ?? null;
  }

  const sessionUser: SessionUser = {
    id: user.id,
    fullName: user.fullName,
    username: user.username,
    role: user.role,
    title: user.title,
    className,
    avatarColor: user.avatarColor,
    avatarUrl: user.avatarUrl,
    permissions: (user.permissions as string[] | null) ?? null,
  };

  return (
    <ToastProvider>
      <AppShell user={sessionUser}>{children}</AppShell>
    </ToastProvider>
  );
}
