import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { classes, honors, users } from "@/db/schema";
import { getSessionUser, hasPerm } from "@/lib/auth";
import HonorsClient from "./honors-client";
import type { HonorItem, StudentBrief } from "@/lib/types";

export const metadata: Metadata = { title: "افتخارات" };

export default async function HonorsPage() {
  const me = await getSessionUser();
  if (!me) redirect("/login");

  const rows = await db
    .select({ h: honors, userName: users.fullName, className: classes.name })
    .from(honors)
    .innerJoin(users, eq(users.id, honors.userId))
    .leftJoin(classes, eq(classes.id, users.classId))
    .orderBy(desc(honors.awardDate), desc(honors.id))
    .limit(100);

  const items: HonorItem[] = rows.map(({ h, userName, className }) => ({
    id: h.id,
    userId: h.userId,
    userName,
    className,
    title: h.title,
    description: h.description,
    awardDate: h.awardDate.toISOString(),
    createdByName: h.createdByName,
    createdAt: h.createdAt.toISOString(),
  }));

  let students: StudentBrief[] = [];
  const canManage = hasPerm(me, "content");
  if (canManage) {
    const srows = await db
      .select({ u: users, className: classes.name })
      .from(users)
      .leftJoin(classes, eq(classes.id, users.classId))
      .where(ne(users.role, "superadmin"))
      .orderBy(users.fullName);
    students = srows.map((r) => ({
      id: r.u.id,
      fullName: r.u.fullName,
      username: r.u.username,
      classId: r.u.classId,
      className: r.className,
      classCode: null,
      role: r.u.role,
      title: r.u.title,
      janm: r.u.janm,
      isApproved: r.u.isApproved,
      isBlocked: r.u.isBlocked,
      avatarColor: r.u.avatarColor,
      avatarUrl: r.u.avatarUrl,
    }));
  }

  return <HonorsClient honors={items} students={students} canManage={canManage} />;
}
