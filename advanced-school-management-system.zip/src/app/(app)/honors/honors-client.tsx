"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "motion/react";
import { Check, LoaderCircle, Medal, Pencil, Plus, Search, Trash2, Trophy } from "lucide-react";
import { Avatar, EmptyState, PageHeader } from "@/components/ui";
import { Modal } from "@/components/modal";
import { useToast } from "@/components/providers";
import { fa, faDate, faDateInputValue } from "@/lib/format";
import type { HonorItem, StudentBrief } from "@/lib/types";

export default function HonorsClient({
  honors,
  students,
  canManage,
}: {
  honors: HonorItem[];
  students: StudentBrief[];
  canManage: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [modal, setModal] = useState<"none" | "add" | "edit">("none");
  const [target, setTarget] = useState<HonorItem | null>(null);
  const [deleting, setDeleting] = useState<HonorItem | null>(null);

  const [search, setSearch] = useState("");
  const [userId, setUserId] = useState<number | null>(null);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [date, setDate] = useState("");

  const candidates = useMemo(() => {
    let list = students.filter((s) => s.isApproved && !s.isBlocked);
    if (search.trim()) list = list.filter((s) => s.fullName.includes(search.trim()));
    return list.slice(0, 8);
  }, [students, search]);

  function openEdit(h: HonorItem) {
    setTarget(h);
    setUserId(h.userId);
    setTitle(h.title);
    setDesc(h.description);
    setDate(faDateInputValue(h.awardDate));
    setModal("edit");
  }

  function openAdd() {
    setTarget(null);
    setUserId(null);
    setTitle("");
    setDesc("");
    setDate("");
    setSearch("");
    setModal("add");
  }

  async function save() {
    if (busy) return;
    if (modal === "add" && !userId) {
      toast.push("error", "دانش‌آموز را انتخاب کنید.");
      return;
    }
    setBusy(true);
    try {
      const isEdit = modal === "edit" && target;
      const res = await fetch(isEdit ? `/api/honors/${target!.id}` : "/api/honors", {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: userId ?? undefined,
          title,
          description: desc,
          date: date || undefined,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا در ذخیره");
      toast.push("success", isEdit ? "افتخار ویرایش شد." : "افتخار جدید ثبت شد.");
      setModal("none");
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!deleting || busy) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/honors/${deleting.id}`, { method: "DELETE", headers: { "Content-Type": "application/json" } });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "خطا در حذف");
      toast.push("success", "افتخار حذف شد.");
      setDeleting(null);
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="افتخارات"
        subtitle={`دیواره افتخار مدرسه • ${fa(honors.length)} افتخار ثبت‌شده`}
        icon={<Trophy size={22} />}
      >
        {canManage && (
          <button onClick={openAdd} className="btn btn-primary">
            <Plus size={16} />
            ثبت افتخار
          </button>
        )}
      </PageHeader>

      {honors.length === 0 ? (
        <div className="panel rise">
          <EmptyState
            icon={<Trophy size={26} />}
            title="هنوز افتخاری ثبت نشده است"
            hint="اولین افتخار مدرسه، اینجا به نمایش در می‌آید."
          />
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {honors.map((h, i) => (
            <motion.article
              key={h.id}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.05, 0.4) }}
              className="panel group relative flex flex-col overflow-hidden p-5 transition hover:border-[rgba(231,189,85,.45)]"
            >
              <div
                className="pointer-events-none absolute inset-0 opacity-0 transition group-hover:opacity-100"
                style={{ background: "radial-gradient(280px 140px at 80% 0%, rgba(231,189,85,.12), transparent 65%)" }}
              />
              <div className="relative flex items-start gap-3.5">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl shadow-soft" style={{ background: "linear-gradient(150deg,#f0cd74,#a8791b)" }}>
                  <Medal size={22} className="text-[#241a04]" />
                </span>
                <div className="min-w-0 flex-1">
                  <h3 className="text-[0.92rem] leading-6 font-extrabold">{h.title}</h3>
                  <div className="text-faint mt-1 text-[0.68rem] font-semibold">{faDate(h.awardDate)}</div>
                </div>
                {canManage && (
                  <div className="flex gap-1.5">
                    <button onClick={() => openEdit(h)} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--gold)]" aria-label="ویرایش">
                      <Pencil size={13} />
                    </button>
                    <button onClick={() => setDeleting(h)} className="panel-inset flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] transition hover:text-[var(--danger)]" aria-label="حذف">
                      <Trash2 size={13} />
                    </button>
                  </div>
                )}
              </div>
              {h.description && <p className="text-muted relative mt-3 flex-1 text-[0.78rem] leading-7">{h.description}</p>}
              <div className="relative mt-4 flex items-center gap-2.5 border-t border-[var(--border)] pt-3">
                <Avatar name={h.userName} color="blue" size={30} />
                <Link href={`/students/${h.userId}`} className="truncate text-[0.8rem] font-bold hover:text-[var(--gold)]">
                  {h.userName}
                </Link>
                {h.className && <span className="badge ms-auto">{h.className}</span>}
              </div>
            </motion.article>
          ))}
        </div>
      )}

      {/* افزودن/ویرایش */}
      <Modal open={modal !== "none"} onClose={() => setModal("none")} title={modal === "edit" ? "ویرایش افتخار" : "ثبت افتخار جدید"}>
        <div className="space-y-4">
          {modal === "add" && (
            <div>
              <label className="label">دانش‌آموز</label>
              {userId ? (
                <div className="panel-inset flex items-center justify-between px-3 py-2.5">
                  <span className="text-sm font-bold">{students.find((s) => s.id === userId)?.fullName}</span>
                  <button onClick={() => setUserId(null)} className="text-faint text-xs font-bold hover:text-[var(--danger)]">
                    تغییر
                  </button>
                </div>
              ) : (
                <div className="panel-inset overflow-hidden">
                  <div className="relative border-b border-[var(--border)]">
                    <Search size={15} className="text-faint absolute top-1/2 right-3 -translate-y-1/2" />
                    <input className="w-full bg-transparent py-2.5 ps-4 pe-9 text-[0.82rem] outline-none" placeholder="جست‌وجوی دانش‌آموز…" value={search} onChange={(e) => setSearch(e.target.value)} />
                  </div>
                  <div className="max-h-44 overflow-y-auto">
                    {candidates.map((s) => (
                      <button key={s.id} onClick={() => setUserId(s.id)} className="flex w-full items-center gap-3 px-3 py-2 text-right transition hover:bg-[var(--panel-2)]">
                        <Avatar name={s.fullName} color={s.avatarColor} url={s.avatarUrl} size={28} />
                        <span className="min-w-0 flex-1 truncate text-[0.8rem] font-bold">{s.fullName}</span>
                        <span className="text-faint text-[0.66rem]">{s.className}</span>
                      </button>
                    ))}
                    {candidates.length === 0 && <div className="text-faint py-4 text-center text-xs">یافت نشد.</div>}
                  </div>
                </div>
              )}
            </div>
          )}
          <div>
            <label className="label">عنوان افتخار</label>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: رتبه اول المپیاد علمی" />
          </div>
          <div>
            <label className="label">تاریخ (شمسی — اختیاری)</label>
            <input className="input" dir="ltr" style={{ textAlign: "left" }} value={date} onChange={(e) => setDate(e.target.value)} placeholder="1404/08/20" />
          </div>
          <div>
            <label className="label">توضیحات</label>
            <textarea className="textarea" value={desc} onChange={(e) => setDesc(e.target.value)} />
          </div>
          <button onClick={save} disabled={busy} className="btn btn-gold w-full">
            {busy ? <LoaderCircle size={16} className="animate-spin" /> : <Check size={15} />}
            {modal === "edit" ? "ذخیره تغییرات" : "ثبت افتخار"}
          </button>
        </div>
      </Modal>

      <Modal open={deleting !== null} onClose={() => setDeleting(null)} title="حذف افتخار">
        <p className="text-muted text-sm leading-7">افتخار «{deleting?.title}» برای همیشه حذف شود؟</p>
        <div className="mt-5 flex gap-2">
          <button onClick={() => setDeleting(null)} className="btn btn-ghost flex-1">
            انصراف
          </button>
          <button onClick={remove} disabled={busy} className="btn btn-danger flex-1">
            {busy ? <LoaderCircle size={15} className="animate-spin" /> : <Trash2 size={15} />}
            حذف قطعی
          </button>
        </div>
      </Modal>
    </div>
  );
}
