"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Bell,
  BellOff,
  Check,
  ImagePlus,
  KeyRound,
  LoaderCircle,
  LogOut,
  Moon,
  Settings as SettingsIcon,
  Sun,
  Trash2,
  UserRound,
  ShieldCheck,
} from "lucide-react";
import { Avatar, PageHeader } from "@/components/ui";
import { getTheme, toggleTheme, useToast, type Theme } from "@/components/providers";
import { faDate } from "@/lib/format";

const COLORS = ["blue", "indigo", "teal", "sky", "violet", "slate", "gold"] as const;
const COLOR_LABEL: Record<string, string> = {
  blue: "آبی",
  indigo: "نیلی",
  teal: "فیروزه‌ای",
  sky: "آسمانی",
  violet: "بنفش",
  slate: "خاکستری",
  gold: "طلایی",
};
const COLOR_STYLE: Record<string, string> = {
  blue: "linear-gradient(150deg,#5d88ff,#2742b8)",
  indigo: "linear-gradient(150deg,#8b7bff,#4534b8)",
  teal: "linear-gradient(150deg,#2dd4bf,#0f766e)",
  sky: "linear-gradient(150deg,#38bdf8,#0369a1)",
  violet: "linear-gradient(150deg,#c084fc,#7e22ce)",
  slate: "linear-gradient(150deg,#94a3b8,#475569)",
  gold: "linear-gradient(150deg,#f0cd74,#a8791b)",
};

type UserInfo = {
  id: number;
  fullName: string;
  username: string;
  role: string;
  title: string | null;
  className: string | null;
  avatarColor: string;
  avatarUrl: string | null;
  createdAt: string;
  notifyPrefs: { announcements?: boolean; janm?: boolean; exams?: boolean } | null;
};

export default function SettingsClient({ user }: { user: UserInfo }) {
  const router = useRouter();
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
  const [color, setColor] = useState(user.avatarColor);
  const [theme, setTheme] = useState<Theme>("dark");

  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");

  const [prefs, setPrefs] = useState({
    announcements: user.notifyPrefs?.announcements !== false,
    janm: user.notifyPrefs?.janm !== false,
    exams: user.notifyPrefs?.exams !== false,
  });

  const [busy, setBusy] = useState<string>("");

  // تم فعلی پس از اتصال به DOM خوانده می‌شود
  useEffect(() => {
    setTheme(getTheme());
  }, []);

  async function uploadAvatar(file: File) {
    setBusy("avatar");
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/me/avatar", { method: "POST", body: fd });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "آپلود ناموفق بود");
      setAvatarUrl(data.data.url);
      toast.push("success", "تصویر پروفایل به‌روزرسانی شد.");
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy("");
    }
  }

  async function removeAvatar() {
    setBusy("avatar");
    try {
      const res = await fetch("/api/me/avatar", { method: "DELETE", headers: { "Content-Type": "application/json" } });
      if (!res.ok) throw new Error("حذف ناموفق بود");
      setAvatarUrl(null);
      toast.push("success", "تصویر پروفایل حذف شد.");
      router.refresh();
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy("");
    }
  }

  async function saveColor(c: string) {
    setColor(c);
    try {
      const res = await fetch("/api/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatarColor: c }),
      });
      if (!res.ok) throw new Error();
      router.refresh();
    } catch {
      toast.push("error", "ذخیره رنگ ممکن نشد.");
    }
  }

  async function changePassword() {
    if (next !== confirm) {
      toast.push("error", "تکرار رمز جدید با رمز مطابقت ندارد.");
      return;
    }
    setBusy("password");
    try {
      const res = await fetch("/api/me/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ current, next }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) throw new Error(data?.error ?? "تغییر رمز ناموفق بود");
      toast.push("success", "رمز عبور با موفقیت تغییر کرد.");
      setCurrent("");
      setNext("");
      setConfirm("");
    } catch (e) {
      toast.push("error", e instanceof Error ? e.message : "خطایی رخ داد.");
    } finally {
      setBusy("");
    }
  }

  async function savePrefs(nextPrefs: typeof prefs) {
    setPrefs(nextPrefs);
    try {
      const res = await fetch("/api/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notifyPrefs: nextPrefs }),
      });
      if (!res.ok) throw new Error();
      toast.push("success", "تنظیمات اعلان ذخیره شد.");
    } catch {
      toast.push("error", "ذخیره تنظیمات ممکن نشد.");
    }
  }

  async function logout() {
    setBusy("logout");
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      window.location.href = "/login";
    } catch {
      toast.push("error", "خروج انجام نشد.");
      setBusy("");
    }
  }

  const roleLabel = user.role === "superadmin" ? "مدیر اصلی" : user.role === "admin" ? "مدیر" : "دانش‌آموز";

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <PageHeader title="تنظیمات" subtitle="مدیریت حساب، امنیت و شخصی‌سازی" icon={<SettingsIcon size={22} />} />

      {/* اطلاعات حساب */}
      <section className="panel rise p-6">
        <h2 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
          <UserRound size={16} className="text-[var(--gold)]" />
          اطلاعات حساب
        </h2>
        <div className="flex flex-wrap items-center gap-4">
          <Avatar name={user.fullName} color={color} url={avatarUrl} size={72} className="shadow-soft" />
          <div className="min-w-0 flex-1">
            <div className="text-base font-black">{user.fullName}</div>
            <div className="text-muted mt-1 flex flex-wrap items-center gap-2 text-[0.72rem] font-semibold">
              <span className="badge badge-blue">{roleLabel}</span>
              {user.title && <span className="badge badge-gold">{user.title}</span>}
              {user.className && <span className="badge">{user.className}</span>}
            </div>
            <div className="text-faint mt-2 text-[0.68rem]">
              نام کاربری: <span dir="ltr" className="font-bold">{user.username}</span> • عضویت: {faDate(user.createdAt)}
            </div>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <button onClick={() => fileRef.current?.click()} disabled={busy === "avatar"} className="btn btn-primary btn-sm">
            {busy === "avatar" ? <LoaderCircle size={14} className="animate-spin" /> : <ImagePlus size={14} />}
            تغییر تصویر پروفایل
          </button>
          {avatarUrl && (
            <button onClick={removeAvatar} disabled={busy === "avatar"} className="btn btn-ghost btn-sm">
              <Trash2 size={14} />
              حذف تصویر
            </button>
          )}
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) uploadAvatar(f);
              e.target.value = "";
            }}
          />
        </div>

        <div className="mt-5">
          <span className="label">رنگ آواتار (وقتی تصویر ندارید)</span>
          <div className="flex flex-wrap gap-2">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => saveColor(c)}
                className="flex h-9 w-9 items-center justify-center rounded-xl transition"
                style={{
                  background: COLOR_STYLE[c],
                  boxShadow: color === c ? "0 0 0 2px var(--bg), 0 0 0 4px rgba(231,189,85,.6)" : undefined,
                }}
                title={COLOR_LABEL[c]}
                aria-label={`رنگ ${COLOR_LABEL[c]}`}
              >
                {color === c && <Check size={14} className="text-white" />}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* امنیت */}
      <section className="panel rise rise-1 p-6">
        <h2 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
          <KeyRound size={16} className="text-[var(--gold)]" />
          تغییر رمز عبور
        </h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <label className="label">رمز فعلی</label>
            <input type="password" className="input" dir="ltr" style={{ textAlign: "left" }} value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" />
          </div>
          <div>
            <label className="label">رمز جدید</label>
            <input type="password" className="input" dir="ltr" style={{ textAlign: "left" }} value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" />
          </div>
          <div>
            <label className="label">تکرار رمز جدید</label>
            <input type="password" className="input" dir="ltr" style={{ textAlign: "left" }} value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
          </div>
        </div>
        <button onClick={changePassword} disabled={busy === "password" || !current || !next || !confirm} className="btn btn-gold btn-sm mt-4">
          {busy === "password" ? <LoaderCircle size={14} className="animate-spin" /> : <ShieldCheck size={14} />}
          ذخیره رمز جدید
        </button>
        <p className="text-faint mt-3 text-[0.66rem] font-semibold">
          رمز عبور با الگوریتم امن هش می‌شود؛ رمز فعلی شما هرگز ذخیره یا نمایش داده نمی‌شود.
        </p>
      </section>

      {/* اعلان‌ها و تم */}
      <section className="panel rise rise-2 p-6">
        <h2 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
          <Bell size={16} className="text-[var(--gold)]" />
          اعلان‌ها و ظاهر
        </h2>
        <div className="space-y-3">
          {(
            [
              { key: "announcements", label: "نمایش اطلاعیه‌ها در داشبورد", desc: "آخرین اعلان‌های مدرسه در صفحه اصلی شما" },
              { key: "janm", label: "نمایش تغییرات جنم در داشبورد", desc: "آخرین سوابق امتیاز شما" },
              { key: "exams", label: "نمایش امتحانات پیش‌رو", desc: "یادآوری امتحانات نزدیک در داشبورد" },
            ] as const
          ).map((p) => (
            <button
              key={p.key}
              onClick={() => savePrefs({ ...prefs, [p.key]: !prefs[p.key] })}
              className="flex w-full items-center gap-3 rounded-xl border border-[var(--border)] px-4 py-3 text-right transition hover:border-[var(--border-strong)]"
            >
              <span
                className="flex h-6 w-11 shrink-0 items-center rounded-full p-0.5 transition"
                style={{ background: prefs[p.key] ? "linear-gradient(150deg,#5d88ff,#2742b8)" : "var(--panel-2)" }}
              >
                <span
                  className="h-5 w-5 rounded-full bg-white shadow transition-transform"
                  style={{ transform: prefs[p.key] ? "translateX(-20px)" : "translateX(0)" }}
                />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[0.82rem] font-bold">{p.label}</span>
                <span className="text-faint text-[0.66rem]">{p.desc}</span>
              </span>
              {prefs[p.key] ? <Bell size={15} className="text-[var(--blue)]" /> : <BellOff size={15} className="text-faint" />}
            </button>
          ))}

          <button
            onClick={() => setTheme(toggleTheme())}
            className="flex w-full items-center gap-3 rounded-xl border border-[var(--border)] px-4 py-3 text-right transition hover:border-[var(--border-strong)]"
          >
            <span className="panel-inset flex h-9 w-9 items-center justify-center rounded-xl">
              {theme === "dark" ? <Moon size={16} /> : <Sun size={16} />}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[0.82rem] font-bold">تم {theme === "dark" ? "تاریک" : "روشن"}</span>
              <span className="text-faint text-[0.66rem]">برای تغییر حالت {theme === "dark" ? "روشن" : "تاریک"} کلیک کنید</span>
            </span>
            {theme === "dark" ? <Sun size={15} className="text-faint" /> : <Moon size={15} className="text-faint" />}
          </button>
        </div>
      </section>

      {/* خروج */}
      <section className="panel rise rise-3 p-6">
        <h2 className="mb-2 flex items-center gap-2 text-sm font-extrabold text-[var(--danger)]">
          <LogOut size={16} />
          خروج از حساب
        </h2>
        <p className="text-muted text-[0.78rem] leading-6">نشست شما به‌صورت امن از سرور ابطال می‌شود.</p>
        <button onClick={logout} disabled={busy === "logout"} className="btn btn-danger btn-sm mt-4">
          {busy === "logout" ? <LoaderCircle size={14} className="animate-spin" /> : <LogOut size={14} />}
          خروج امن از حساب
        </button>
      </section>
    </div>
  );
}
