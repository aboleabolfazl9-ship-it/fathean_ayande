import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { classes } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import SettingsClient from "./settings-client";

export const metadata: Metadata = { title: "تنظیمات" };

export default async function SettingsPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  let className: string | null = null;
  if (user.classId) {
    const [cls] = await db.select().from(classes).where(eq(classes.id, user.classId)).limit(1);
    className = cls?.name ?? null;
  }

  return (
    <SettingsClient
      user={{
        id: user.id,
        fullName: user.fullName,
        username: user.username,
        role: user.role,
        title: user.title,
        className,
        avatarColor: user.avatarColor,
        avatarUrl: user.avatarUrl,
        createdAt: user.createdAt.toISOString(),
        notifyPrefs: (user.notifyPrefs as { announcements?: boolean; janm?: boolean; exams?: boolean } | null) ?? null,
      }}
    />
  );
}
