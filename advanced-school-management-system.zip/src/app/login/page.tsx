import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { classes } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import LoginClient from "./login-client";

export const metadata: Metadata = { title: "ورود به سامانه" };

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect("/");

  const classRows = await db.select().from(classes).orderBy(asc(classes.code));

  return <LoginClient classes={classRows.map((c) => ({ id: c.id, name: c.name, code: c.code }))} />;
}
