"use client";

import { useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  LogIn,
  UserPlus,
  KeyRound,
  Eye,
  EyeOff,
  LoaderCircle,
  ShieldCheck,
  Sparkles,
  Medal,
} from "lucide-react";
import { Logo } from "@/components/ui";
import type { ClassItem } from "@/lib/types";

type Tab = "login" | "register" | "forgot";

const TABS: { key: Tab; label: string; icon: typeof LogIn }[] = [
  { key: "login", label: "ورود", icon: LogIn },
  { key: "register", label: "ثبت‌نام", icon: UserPlus },
  { key: "forgot", label: "بازیابی رمز", icon: KeyRound },
];

export default function LoginClient({ classes }: { classes: ClassItem[] }) {
  const [tab, setTab] = useState<Tab>("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showPass, setShowPass] = useState(false);

  // ورود
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  // ثبت‌نام
  const [fullName, setFullName] = useState("");
  const [regUsername, setRegUsername] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [classId, setClassId] = useState("");
  // بازیابی
  const [forgotUsername, setForgotUsername] = useState("");
  const [forgotNote, setForgotNote] = useState("");

  function resetMessages() {
    setError("");
    setSuccess("");
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    resetMessages();
    setLoading(true);
    try {
      let res: Response;
      if (tab === "login") {
        res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password }),
        });
      } else if (tab === "register") {
        res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ fullName, username: regUsername, password: regPassword, classId: Number(classId) }),
        });
      } else {
        res = await fetch("/api/auth/forgot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username: forgotUsername, note: forgotNote }),
        });
      }
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) {
        setError(data?.error ?? "خطایی رخ داد؛ دوباره تلاش کنید.");
        return;
      }
      if (tab === "login") {
        setSuccess("ورود موفق — در حال انتقال به داشبورد...");
        // ابتدا مطمئن شویم کوکی نشست واقعاً در مرورگر ذخیره شده است
        const check = await fetch("/api/me", { cache: "no-store" });
        if (check.ok) {
          // ناوبری کامل (نه SPA) تا کوکی نشست تازه بلافاصله به سرور برسد
          window.location.assign("/");
        } else {
          setError(
            "مرورگر شما کوکی نشست را ذخیره نکرد (کوکی‌های شخص ثالث مسدود است). لطفاً آدرس سایت را مستقیماً در تب جدید مرورگر باز کنید یا مسدودسازی کوکی‌ها را غیرفعال کنید.",
          );
          setSuccess("");
        }
      } else {
        setSuccess(data.data?.message ?? "انجام شد.");
      }
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-dvh">
      {/* ستون تصویر — دسکتاپ */}
      <div className="relative hidden w-[46%] overflow-hidden lg:block">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/login-art.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(to left, rgba(5,8,15,.94) 0%, rgba(5,8,15,.55) 55%, rgba(5,8,15,.35) 100%)" }}
        />
        <div className="relative z-10 flex h-full flex-col justify-between p-10">
          <div className="flex items-center gap-3">
            <Logo size={44} />
            <div>
              <div className="text-lg font-black text-white">فاتحان آینده</div>
              <div className="text-[0.7rem] font-semibold text-white/60">سامانه اختصاصی مدرسه</div>
            </div>
          </div>
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
            >
              <h2 className="max-w-md text-3xl leading-[1.5] font-black text-white">
                یک سامانه واحد برای کل مدرسه؛
                <span className="gold-text"> دقیق، امن و همیشه به‌روز</span>
              </h2>
              <p className="mt-3 max-w-md text-sm leading-7 text-white/65">
                رتبه‌بندی جنم، قرارگاه‌ها، برنامه امتحانات، افتخارات و اطلاعیه‌ها — همه در یک پنجره، با حساب اختصاصی برای
                هر دانش‌آموز.
              </p>
            </motion.div>
            <div className="flex flex-wrap gap-3">
              {[
                { icon: Medal, t: "سیستم امتیاز جنم" },
                { icon: ShieldCheck, t: "حساب‌های امن و مستقل" },
                { icon: Sparkles, t: "مدیریت زنده و مستقیم" },
              ].map((f, i) => (
                <motion.div
                  key={f.t}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.35 + i * 0.1 }}
                  className="flex items-center gap-2 rounded-full border border-white/15 bg-white/8 px-4 py-2 text-[0.72rem] font-bold text-white/85 backdrop-blur-md"
                >
                  <f.icon size={14} className="text-[#e7bd55]" />
                  {f.t}
                </motion.div>
              ))}
            </div>
          </div>
          <div className="text-[0.68rem] font-semibold text-white/40">نسخه ۱٫۰ — طراحی و توسعه اختصاصی</div>
        </div>
      </div>

      {/* ستون فرم */}
      <div className="relative flex flex-1 items-center justify-center px-4 py-10">
        {/* درخشش موبایل */}
        <div
          className="pointer-events-none absolute inset-0 lg:hidden"
          style={{
            background:
              "radial-gradient(500px 300px at 50% 0%, rgba(79,124,255,.16), transparent 70%), radial-gradient(400px 260px at 50% 100%, rgba(231,189,85,.1), transparent 70%)",
          }}
        />
        <div className="relative w-full max-w-md">
          <div className="glass-strong overflow-hidden">
            <div className="px-7 pt-8 pb-6 text-center lg:hidden">
              <Logo size={52} className="float-y mx-auto" />
              <h1 className="mt-4 text-xl font-black">فاتحان آینده</h1>
              <p className="text-muted mt-1 text-xs">سامانه اختصاصی و یکپارچه مدرسه</p>
            </div>
            <div className="hidden px-8 pt-8 lg:block">
              <h1 className="text-xl font-black">به سامانه خوش آمدید</h1>
              <p className="text-muted mt-1.5 text-xs leading-6">برای ادامه، وارد حساب خود شوید یا ثبت‌نام کنید.</p>
            </div>

            {/* زبانه‌ها */}
            <div className="mx-7 mt-6 grid grid-cols-3 gap-1 rounded-2xl border border-[var(--border)] bg-[var(--panel-2)] p-1">
              {TABS.map((t) => (
                <button
                  key={t.key}
                  onClick={() => {
                    setTab(t.key);
                    resetMessages();
                  }}
                  className={`relative flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[0.72rem] font-bold transition ${
                    tab === t.key ? "text-white" : "text-[var(--muted)] hover:text-[var(--text)]"
                  }`}
                >
                  {tab === t.key && (
                    <motion.span
                      layoutId="tab-pill"
                      className="absolute inset-0 rounded-xl"
                      style={{ background: "linear-gradient(160deg,#5d88ff,#2742b8)", boxShadow: "0 6px 18px -6px rgba(58,96,232,.7)" }}
                      transition={{ type: "spring", damping: 28, stiffness: 380 }}
                    />
                  )}
                  <t.icon size={14} className="relative z-10" />
                  <span className="relative z-10">{t.label}</span>
                </button>
              ))}
            </div>

            <form onSubmit={submit} className="space-y-4 px-7 py-6 sm:px-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={tab}
                  initial={{ opacity: 0, x: 14 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -14 }}
                  transition={{ duration: 0.22 }}
                  className="space-y-4"
                >
                  {tab === "register" && (
                    <>
                      <div>
                        <label className="label" htmlFor="fullName">نام و نام خانوادگی</label>
                        <input
                          id="fullName"
                          className="input"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="مثلاً محمد اکرمی ابرقوئی"
                          required
                        />
                      </div>
                      <div>
                        <label className="label" htmlFor="class">کلاس</label>
                        <select
                          id="class"
                          className="select"
                          value={classId}
                          onChange={(e) => setClassId(e.target.value)}
                          required
                        >
                          <option value="">انتخاب کلاس…</option>
                          {classes.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </>
                  )}

                  {tab !== "register" && (
                    <div>
                      <label className="label" htmlFor="username">نام کاربری</label>
                      <input
                        id="username"
                        className="input"
                        dir="ltr"
                        style={{ textAlign: "left" }}
                        value={tab === "forgot" ? forgotUsername : username}
                        onChange={(e) => (tab === "forgot" ? setForgotUsername(e.target.value) : setUsername(e.target.value))}
                        placeholder="username"
                        autoComplete="username"
                        required
                      />
                    </div>
                  )}

                  {tab === "register" && (
                    <div>
                      <label className="label" htmlFor="regUsername">نام کاربری (انگلیسی)</label>
                      <input
                        id="regUsername"
                        className="input"
                        dir="ltr"
                        style={{ textAlign: "left" }}
                        value={regUsername}
                        onChange={(e) => setRegUsername(e.target.value)}
                        placeholder="username"
                        autoComplete="username"
                        required
                      />
                    </div>
                  )}

                  {tab !== "forgot" && (
                    <div>
                      <label className="label" htmlFor="password">رمز عبور</label>
                      <div className="relative">
                        <input
                          id="password"
                          type={showPass ? "text" : "password"}
                          className="input"
                          dir="ltr"
                          style={{ textAlign: "left", paddingLeft: "2.6rem" }}
                          value={tab === "register" ? regPassword : password}
                          onChange={(e) => (tab === "register" ? setRegPassword(e.target.value) : setPassword(e.target.value))}
                          placeholder="••••••••"
                          autoComplete={tab === "register" ? "new-password" : "current-password"}
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPass((s) => !s)}
                          className="absolute top-1/2 left-2.5 -translate-y-1/2 text-[var(--faint)] transition hover:text-[var(--text)]"
                          aria-label="نمایش رمز"
                        >
                          {showPass ? <EyeOff size={17} /> : <Eye size={17} />}
                        </button>
                      </div>
                    </div>
                  )}

                  {tab === "forgot" && (
                    <>
                      <p className="text-muted rounded-xl border border-[var(--border)] bg-[var(--panel-2)] px-3 py-2.5 text-[0.72rem] leading-6">
                        درخواست بازیابی شما برای مدیر ارسال می‌شود. پس از بررسی، رمز موقت جدید از مسیر امن به شما اعلام
                        خواهد شد.
                      </p>
                      <div>
                        <label className="label" htmlFor="fnote">توضیح (اختیاری)</label>
                        <input
                          id="fnote"
                          className="input"
                          value={forgotNote}
                          onChange={(e) => setForgotNote(e.target.value)}
                          placeholder="مثلاً: رمزم را فراموش کرده‌ام"
                        />
                      </div>
                    </>
                  )}
                </motion.div>
              </AnimatePresence>

              {error && (
                <motion.p
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl border border-[rgba(255,107,107,.35)] bg-[rgba(255,107,107,.1)] px-3 py-2.5 text-[0.76rem] font-bold text-[var(--danger)]"
                >
                  {error}
                </motion.p>
              )}
              {success && (
                <motion.p
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl border border-[rgba(74,222,128,.35)] bg-[rgba(74,222,128,.1)] px-3 py-2.5 text-[0.76rem] font-bold text-[var(--success)]"
                >
                  {success}
                </motion.p>
              )}

              <button type="submit" disabled={loading} className="btn btn-gold w-full py-3 text-[0.92rem]">
                {loading ? (
                  <LoaderCircle size={18} className="animate-spin" />
                ) : tab === "login" ? (
                  <LogIn size={17} />
                ) : tab === "register" ? (
                  <UserPlus size={17} />
                ) : (
                  <KeyRound size={17} />
                )}
                {loading
                  ? "در حال پردازش..."
                  : tab === "login"
                    ? "ورود به حساب"
                    : tab === "register"
                      ? "ثبت درخواست حساب"
                      : "ارسال درخواست بازیابی"}
              </button>

              {tab === "login" && (
                <p className="text-faint text-center text-[0.7rem] leading-6">
                  دانش‌آموزان با نام کاربری اختصاصی خود وارد می‌شوند.
                  <br />
                  ثبت‌نام‌های جدید پس از تأیید مدیر فعال می‌شوند.
                </p>
              )}
            </form>
          </div>

          <p className="text-faint mt-5 text-center text-[0.66rem] font-semibold">
            سامانه اختصاصی مدرسه فاتحان آینده — تمام فعالیت‌ها ثبت و پایش می‌شوند
          </p>
        </div>
      </div>
    </div>
  );
}
