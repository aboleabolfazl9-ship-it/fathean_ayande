import { cache } from "react";
import { cookies } from "next/headers";
import { eq, and, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, type UserRow } from "@/db/schema";
import { newSessionToken, sha256 } from "@/lib/crypto";

import type { PermKey } from "@/lib/permissions";

export const SESSION_COOKIE = "fatehan_session";
const SESSION_DAYS = 7;

export type { PermKey };

const cookieBase = {
  httpOnly: true,
  // SameSite=None + Secure تا در پیش‌نمایش‌های iframe (cross-site) هم کوکی ذخیره شود.
  // امنیت CSRF همچنان با بررسی Origin در csrfGuard تضمین می‌شود.
  sameSite: "none" as const,
  secure: true,
  path: "/",
};

export async function createSession(userId: number): Promise<string> {
  const token = newSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ id: sha256(token), userId, expiresAt });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, { ...cookieBase, expires: expiresAt });
  return token;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.id, sha256(token)));
  }
  // حذف کوکی با همان مشخصاتی که ساخته شده تا مرورگر آن را همان کوکی بداند
  store.set(SESSION_COOKIE, "", { ...cookieBase, expires: new Date(0), maxAge: 0 });
}

/** کاربر فعلی بر اساس کوکی نشست — با cache در هر درخواست */
export const getSessionUser = cache(async (): Promise<UserRow | null> => {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users, session: sessions })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.id, sha256(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  if (!rows.length) return null;
  return rows[0].user;
});

export function isAdmin(user: UserRow | null): boolean {
  if (!user) return false;
  if (!user.isApproved || user.isBlocked) return false;
  return user.role === "admin" || user.role === "superadmin";
}

export function isSuperAdmin(user: UserRow | null): boolean {
  if (!user) return false;
  if (!user.isApproved || user.isBlocked) return false;
  return user.role === "superadmin";
}

/** بررسی سطح دسترسی یک مجوز خاص */
export function hasPerm(user: UserRow | null, perm: PermKey): boolean {
  if (!isAdmin(user)) return false;
  if (user!.role === "superadmin") return true;
  const perms = (user!.permissions as string[] | null) ?? [];
  return perms.includes(perm);
}

/** آیا کاربر دانش‌آموز است (برای لیست‌ها و رتبه‌بندی) */
export function isStudentLike(user: UserRow): boolean {
  return user.role !== "superadmin";
}
