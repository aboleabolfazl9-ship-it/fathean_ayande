import { randomBytes, scryptSync, timingSafeEqual, createHash } from "node:crypto";

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const original = Buffer.from(hash, "hex");
  return candidate.length === original.length && timingSafeEqual(candidate, original);
}

export function sha256(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

export function newSessionToken(): string {
  return randomBytes(32).toString("base64url");
}

export function randomTempPassword(): string {
  // رمز موقت امن ۱۰ کاراکتری
  return randomBytes(7).toString("base64url").replace(/[-_]/g, "x").slice(0, 10) + randomBytes(1).toString("hex").slice(0, 2);
}
