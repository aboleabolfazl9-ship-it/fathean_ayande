/* انواع داده مشترک بین سرور و کلاینت */

export type StudentBrief = {
  id: number;
  fullName: string;
  username: string;
  classId: number | null;
  className: string | null;
  classCode: string | null;
  role: string;
  title: string | null;
  janm: number;
  isApproved: boolean;
  isBlocked: boolean;
  avatarColor: string;
  avatarUrl: string | null;
  rank?: number;
};

export type MeInfo = StudentBrief & {
  permissions: string[] | null;
  notifyPrefs: { announcements?: boolean; janm?: boolean; exams?: boolean } | null;
};

export type SessionUser = {
  id: number;
  fullName: string;
  username: string;
  role: string;
  title: string | null;
  className: string | null;
  avatarColor: string;
  avatarUrl: string | null;
  permissions: string[] | null;
};

export type JanmTx = {
  id: number;
  userId: number;
  userName?: string;
  amount: number;
  kind: string;
  reason: string;
  note: string;
  actorName: string;
  status: string;
  correctsId: number | null;
  createdAt: string;
};

export type AnnouncementItem = {
  id: number;
  title: string;
  body: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string | null;
};

export type HonorItem = {
  id: number;
  userId: number;
  userName: string;
  className?: string | null;
  title: string;
  description: string;
  awardDate: string;
  createdByName: string | null;
  createdAt: string;
};

export type ExamItem = {
  id: number;
  title: string;
  description: string;
  examDate: string;
};

export type BaseItem = {
  id: number;
  slug: string;
  name: string;
  managerName: string;
  managerUserId: number | null;
  description: string;
  icon: string;
  hue: string;
  members: { id: number; fullName: string; className: string | null; avatarColor: string; avatarUrl: string | null }[];
};

export type ClassItem = {
  id: number;
  name: string;
  code: string;
  studentCount?: number;
};

export const TX_KIND_LABELS: Record<string, string> = {
  manual: "دستی",
  absence: "غیبت غیرموجه",
  lateness: "تأخیر در ورود",
  lateness_penalty: "جریمه سه تأخیر",
  disorder: "بی‌نظمی",
  correction: "اصلاحیه",
  honor: "افتخار",
};
