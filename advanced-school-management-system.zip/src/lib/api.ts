import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { db } from "@/db";
import { activityLogs } from "@/db/schema";

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ ok: true, data }, init);
}

export function fail(message: string, status = 400) {
  return NextResponse.json({ ok: false, error: message }, { status });
}

export function handleError(e: unknown) {
  if (e instanceof ZodError) {
    const first = e.issues[0];
    return fail(first ? first.message : "اطلاعات وارد‌شده معتبر نیست.", 422);
  }
  console.error(e);
  return fail("خطای داخلی سرور رخ داد. دوباره تلاش کنید.", 500);
}

/** محافظت CSRF: درخواست‌های تغییردهنده باید same-origin باشند */
export function csrfGuard(req: Request): NextResponse | null {
  const origin = req.headers.get("origin");
  if (!origin) return null; // ابزارهای سروری
  try {
    const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
    if (new URL(origin).host !== host) return fail("درخواست نامعتبر است.", 403);
  } catch {
    return fail("درخواست نامعتبر است.", 403);
  }
  return null;
}

/** ثبت گزارش فعالیت مدیران */
export async function logActivity(actorId: number | null, actorName: string, action: string, detail = "") {
  try {
    await db.insert(activityLogs).values({ actorId, actorName, action, detail });
  } catch (e) {
    console.error("logActivity failed", e);
  }
}
