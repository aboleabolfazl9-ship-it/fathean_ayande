import * as jalaali from "jalaali-js";

const FA = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function fa(input: number | string | null | undefined): string {
  if (input === null || input === undefined) return "";
  return String(input).replace(/\d/g, (d) => FA[Number(d)]);
}

/** عدد با جداکننده هزارگان و ارقام فارسی */
export function faNum(n: number): string {
  const sign = n < 0 ? "−" : "";
  const abs = Math.abs(n);
  return sign + fa(abs.toLocaleString("en-US").replace(/,/g, "٬"));
}

/** نمایش مقدار جنم با علامت */
export function faSigned(n: number): string {
  if (n > 0) return "+" + faNum(n);
  return faNum(n);
}

export const FA_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

function toJ(date: Date) {
  return jalaali.toJalaali(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

function isValid(d: Date) {
  return d instanceof Date && !isNaN(d.getTime());
}

/** مثل: ۲۰ آبان ۱۴۰۴ */
export function faDate(input: Date | string | null | undefined): string {
  if (!input) return "—";
  const d = typeof input === "string" ? new Date(input) : input;
  if (!isValid(d)) return "—";
  const j = toJ(d);
  return `${fa(j.jd)} ${FA_MONTHS[j.jm - 1]} ${fa(j.jy)}`;
}

/** مثل: ۲۰ آبان ۱۴۰۴ • ۱۴:۳۰ */
export function faDateTime(input: Date | string | null | undefined): string {
  if (!input) return "—";
  const d = typeof input === "string" ? new Date(input) : input;
  if (!isValid(d)) return "—";
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${faDate(d)} • ${fa(`${hh}:${mm}`)}`;
}

/** تاریخ جلالی کوتاه: ۱۴۰۴/۰۸/۲۰ — برای اینپوت‌های تاریخ */
export function faDateInputValue(input: Date | string): string {
  const d = typeof input === "string" ? new Date(input) : input;
  if (!isValid(d)) return "";
  const j = toJ(d);
  return `${j.jy}/${String(j.jm).padStart(2, "0")}/${String(j.jd).padStart(2, "0")}`;
}

/** تبدیل تاریخ شمسی (jy/jm/jd) به Date میلادی (ظهر به‌وقت محلی تا از خطای منطقه زمانی جلوگیری شود) */
export function jalaliToDate(jy: number, jm: number, jd: number): Date {
  const g = jalaali.toGregorian(jy, jm, jd);
  return new Date(g.gy, g.gm - 1, g.gd, 12, 0, 0);
}

export function parseJalaliString(s: string): Date | null {
  const m = s.trim().match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/);
  if (!m) return null;
  const jy = Number(m[1]);
  const jm = Number(m[2]);
  const jd = Number(m[3]);
  if (jm < 1 || jm > 12 || jd < 1 || jd > 31) return null;
  if (!jalaali.isValidJalaaliDate(jy, jm, jd)) return null;
  return jalaliToDate(jy, jm, jd);
}

const WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
export function faWeekday(input: Date | string): string {
  const d = typeof input === "string" ? new Date(input) : input;
  if (!isValid(d)) return "";
  // getDay: 0=Sunday ... 6=Saturday — تقویم ایران از شنبه شروع می‌شود
  const map = [1, 2, 3, 4, 5, 6, 0]; // Sunday→یکشنبه ...
  return WEEKDAYS[map[d.getDay()]];
}

/** زمان نسبی فارسی */
export function faRelative(input: Date | string): string {
  const d = typeof input === "string" ? new Date(input) : input;
  if (!isValid(d)) return "";
  const diff = Date.now() - d.getTime();
  const abs = Math.abs(diff);
  const mins = Math.floor(abs / 60000);
  const suffix = diff >= 0 ? "پیش" : "بعد";
  if (mins < 1) return "هم‌اکنون";
  if (mins < 60) return `${fa(mins)} دقیقه ${suffix}`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${fa(hours)} ساعت ${suffix}`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${fa(days)} روز ${suffix}`;
  return faDate(d);
}

export function todayJalali(): { jy: number; jm: number; jd: number } {
  return toJ(new Date());
}
