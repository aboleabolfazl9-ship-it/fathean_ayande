/* تعریف سطوح دسترسی — بدون وابستگی به سرور؛ قابل استفاده در کلاینت و سرور */

export const PERMS = [
  { key: "students", label: "مدیریت دانش‌آموزان" },
  { key: "janm", label: "مدیریت جنم" },
  { key: "classes", label: "مدیریت کلاس‌ها" },
  { key: "bases", label: "مدیریت قرارگاه‌ها" },
  { key: "exams", label: "مدیریت امتحانات" },
  { key: "content", label: "اطلاعیه‌ها و افتخارات" },
] as const;

export type PermKey = (typeof PERMS)[number]["key"];
