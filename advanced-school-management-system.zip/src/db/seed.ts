import { db } from "@/db";
import {
  announcements,
  baseMembers,
  bases,
  classes,
  exams,
  users,
} from "@/db/schema";
import { hashPassword } from "@/lib/crypto";
import { jalaliToDate } from "@/lib/format";
import { sql } from "drizzle-orm";

/* ------------------------------------------------------------------ */
/*  داده‌های واقعی مدرسه فاتحان آینده                                    */
/* ------------------------------------------------------------------ */

export const CLASS_DATA: { name: string; code: string; students: string[] }[] = [
  {
    name: "کلاس ۷/۱",
    code: "71",
    students: [
      "محمد اکرمی ابرقوئی",
      "محمدکیان برائی",
      "محمدطه تکتاز",
      "محمدرحیم تهمتن",
      "امیرعباس جوکار",
      "محمدطاها خانی دهنوی",
      "محمدمهدی خزائی",
      "علی داریوش نیا",
      "حسین دلیاسری",
      "محمدماهان دهقانی سعدی",
      "محمدطاها رحمانی",
      "علیرضا رزمخواه",
      "محمدحسن زارع",
      "میعاد شریف پور",
      "مهیار شریف پور",
      "علی شهبازی",
      "اباالفضل عباسی",
      "محمد فتحی",
      "حسین فریدونی خانیمنی",
      "کیان گورکانی",
    ],
  },
  {
    name: "کلاس ۸/۱",
    code: "81",
    students: [
      "محمدسبحان اوحدی",
      "علی بانشی",
      "امیرعلی برومند",
      "ابوالفضل بهمنی",
      "علی جابری اربابی",
      "امیرحسین جهانخواه",
      "محمدرضا دشتکی پور",
      "امیرعلی ربانی",
      "محمدطاها رحیم زادگان",
      "رضا زارعی",
      "امیرمهدی زراوشان",
      "محمدطاها سلطانی",
      "محمدصالح شهریاری",
      "محمدحسن صمیمی",
      "احمدعلی طالع زاده",
      "محمدرضا قربانی باوریانی",
      "ایلیا کاظمی احمدآبادی",
      "علی کشاورز",
      "حسین محمدی",
      "محمدحسین مشکین فام فرد",
      "سیدمحمدباقر نبوی زاده",
    ],
  },
  {
    name: "کلاس ۸/۲",
    code: "82",
    students: [
      "متین احمدی چنارفاریابی",
      "محمدطاها اهرمی",
      "امیرمحمد جعفری",
      "محمدطاها جمالی آزاد",
      "امیررضا جوکارکمال آبادی",
      "محمدسبحان حاصلی",
      "علی حسین پور",
      "محمد حمزه نژاد",
      "حسین دادگر",
      "متین ریحانی",
      "امیرعلی زارع",
      "احمدرضا زارع کدنجی",
      "محمدطاها شکاری",
      "محمدمهدی شهبازی",
      "محمدسپهر شیردل",
      "امیرمحمد فردفتح آبادی",
      "محمدپارسا مروت",
      "محمدامین مصلی نژاد",
    ],
  },
  {
    name: "کلاس ۹/۱",
    code: "91",
    students: [
      "محمدجواد اشراق پور",
      "محمدپارسا جعفری",
      "طاها حسینقلی",
      "محمدمهدی دادگر",
      "ایلیا ذوالعدل",
      "عرشیا ذوالعدل",
      "شایان سیمکانی",
      "عرفان محسنی حقیقی",
      "علی نام آور",
      "محمدعلی هادی زاده",
      "محمدسبحان یعقوب زاده",
    ],
  },
  {
    name: "کلاس ۹/۲",
    code: "92",
    students: [
      "محمدمهدی اکبری باصری",
      "محمدطاها امیری",
      "امیرمحمد پوربشیری",
      "بنیامین ترابی",
      "پرهام توفیقی",
      "محمدعرفان ثابت",
      "سیدمهدی حسینی",
      "امیرمهدی زارعی",
      "مجتبی شکیبا",
      "رضا کاوسی",
      "حمیدرضا لامع",
      "محمدحسین محبی",
      "سیدامیرعلی نبوی زاده",
      "مهیار نیکونام نظامی",
      "امیرحسین واقعی",
      "محمدطه هلالی",
    ],
  },
];

const BASES = [
  {
    slug: "farhangi",
    name: "قرارگاه فرهنگی",
    manager: "بنیامین ترابی",
    icon: "book",
    hue: "gold",
    description:
      "قرارگاه فرهنگی مسئول برنامه‌ریزی و اجرای فعالیت‌های فرهنگی، هنری و معنوی مدرسه است؛ از مراسم و مناسبت‌ها تا نشریه و رویدادهای فرهنگی.",
  },
  {
    slug: "media",
    name: "قرارگاه مدیا",
    manager: "محمدسبحان اوحدی",
    icon: "clapper",
    hue: "violet",
    description:
      "قرارگاه مدیا پوشش رسانه‌ای رویدادهای مدرسه، تولید محتوای تصویری، عکاسی، طراحی و مدیریت رسانه‌های رسمی فاتحان آینده را بر عهده دارد.",
  },
  {
    slug: "nezam",
    name: "قرارگاه نظم",
    manager: "مجتبی شکیبا",
    icon: "shield",
    hue: "sky",
    description:
      "قرارگاه نظم بر انضباط، حضور و غیاب، نظافت و اجرای قوانین مدرسه نظارت می‌کند و هماهنگ‌کننده امور اجرایی روزانه است.",
  },
  {
    slug: "danayi",
    name: "قرارگاه دانایی",
    manager: "عرشیا ذوالعدل",
    icon: "grad",
    hue: "indigo",
    description:
      "قرارگاه دانایی بر کیفیت آموزش، کلاس‌های تقویتی، پژوهش، مسابقات علمی و برنامه‌ریزی درسی دانش‌آموزان متمرکز است.",
  },
  {
    slug: "energy",
    name: "قرارگاه انرژی",
    manager: "طاها حسینقلی",
    icon: "zap",
    hue: "amber",
    description:
      "قرارگاه انرژی مسئول فعالیت‌های ورزشی، رقابت‌های داخل مدرسه، سرزندگی و نشاط دانش‌آموزان و مدیریت رویدادهای بدنی است.",
  },
];

/** نام کاربری دانش‌آموز: کد کلاس + شماره دو رقمی در فهرست کلاس */
export function studentUsername(code: string, index: number): string {
  return `${code}${String(index + 1).padStart(2, "0")}`;
}

export const DEFAULT_STUDENT_PASSWORD = "123456";
export const ADMIN_USERNAME = "admin";
export const ADMIN_PASSWORD = "admin12345";

const AVATAR_COLORS = ["blue", "indigo", "teal", "sky", "violet", "slate"];

let seeded = false;

export async function runSeed() {
  if (seeded) return;
  seeded = true;
  try {
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
    if (count > 0) return; // قبلاً راه‌اندازی شده

    console.log("[seed] راه‌اندازی اولیه پایگاه‌داده آغاز شد...");

    const allPerms = ["students", "janm", "classes", "bases", "exams", "content"];

    // مدیر اصلی سامانه
    const [superAdmin] = await db
      .insert(users)
      .values({
        username: ADMIN_USERNAME,
        passwordHash: hashPassword(ADMIN_PASSWORD),
        fullName: "مدیریت سامانه",
        role: "superadmin",
        permissions: allPerms,
        avatarColor: "gold",
        isApproved: true,
      })
      .returning();

    const studentHash = hashPassword(DEFAULT_STUDENT_PASSWORD);
    const nameToUserId = new Map<string, number>();
    let globalIndex = 0;
    const orderedUsernames = new Set<string>();

    for (const cls of CLASS_DATA) {
      const [classRow] = await db.insert(classes).values({ name: cls.name, code: cls.code }).returning();

      for (let i = 0; i < cls.students.length; i++) {
        const fullName = cls.students[i];
        let username = studentUsername(cls.code, i);
        while (orderedUsernames.has(username)) username = username + "x";
        orderedUsernames.add(username);

        let role = "student";
        let title: string | null = null;
        let permissions: string[] | null = null;
        if (fullName === "علی جابری اربابی") {
          title = "مدیر ارشد";
          role = "admin";
          permissions = allPerms;
        } else if (fullName === "ایلیا کاظمی احمدآبادی") {
          title = "مسئول آمار";
        }

        const [u] = await db
          .insert(users)
          .values({
            username,
            passwordHash: studentHash,
            fullName,
            classId: classRow.id,
            role,
            title,
            permissions,
            janm: 0,
            isApproved: true,
            avatarColor: AVATAR_COLORS[globalIndex % AVATAR_COLORS.length],
          })
          .returning({ id: users.id });
        nameToUserId.set(fullName, u.id);
        globalIndex++;
      }
    }

    // قرارگاه‌ها + عضویت مدیر هر قرارگاه
    for (const b of BASES) {
      const managerId = nameToUserId.get(b.manager) ?? null;
      const [base] = await db
        .insert(bases)
        .values({
          slug: b.slug,
          name: b.name,
          managerName: b.manager,
          managerUserId: managerId,
          description: b.description,
          icon: b.icon,
          hue: b.hue,
        })
        .returning();
      if (managerId) {
        await db.insert(baseMembers).values({ baseId: base.id, userId: managerId }).onConflictDoNothing();
      }
    }

    // مسئولیت‌های رسمی: عنوانی مدیران قرارگاه در پروفایل کاربری
    for (const b of BASES) {
      const id = nameToUserId.get(b.manager);
      if (id) {
        await db
          .update(users)
          .set({ title: `مدیر ${b.name}` })
          .where(sql`${users.id} = ${id}`);
      }
    }
    // بازگردانی مسئولیت‌های رسمی مدرسه (بر اساس مصوبه)
    const ali = nameToUserId.get("علی جابری اربابی");
    if (ali) await db.update(users).set({ title: "مدیر ارشد" }).where(sql`${users.id} = ${ali}`);
    const elia = nameToUserId.get("ایلیا کاظمی احمدآبادی");
    if (elia) await db.update(users).set({ title: "مسئول آمار" }).where(sql`${users.id} = ${elia}`);

    // تنها امتحان ثبت‌شده فعلی: امتحان مبتکران — ۲۰ آبان
    await db.insert(exams).values({
      title: "امتحان مبتکران",
      description: "امتحان رسمی مبتکران؛ جزئیات جلسه و حیطه از طریق اطلاعیه‌ها اعلام می‌شود.",
      examDate: jalaliToDate(1404, 8, 20),
    });

    // اطلاعیه خوش‌آمد رسمی
    await db.insert(announcements).values({
      title: "راه‌اندازی سامانه فاتحان آینده",
      body: "سامانه اختصاصی مدرسه فاتحان آینده رسماً راه‌اندازی شد. تمام دانش‌آموزان با حساب کاربری خود وارد شوند و در نخستین ورود، رمز عبور خود را از بخش تنظیمات تغییر دهند. واحد امتیاز سامانه «جنم» است و تمام تغییرات آن با ذکر دلیل و نام مدیر ثبت می‌شود.",
      createdById: superAdmin.id,
      createdByName: "مدیریت سامانه",
    });

    console.log("[seed] راه‌اندازی کامل شد؛ کلاس‌ها: ۵، دانش‌آموزان: ۸۶");
  } catch (e) {
    console.error("[seed] خطا در راه‌اندازی اولیه:", e);
  }
}
