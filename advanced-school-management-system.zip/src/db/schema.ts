import {
  pgTable,
  serial,
  varchar,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/*  کلاس‌ها                                                            */
/* ------------------------------------------------------------------ */
export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 40 }).notNull().unique(),
  code: varchar("code", { length: 8 }).notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/* ------------------------------------------------------------------ */
/*  کاربران (مدیران و دانش‌آموزان)                                      */
/* ------------------------------------------------------------------ */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    username: varchar("username", { length: 60 }).notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    fullName: varchar("full_name", { length: 140 }).notNull(),
    classId: integer("class_id").references(() => classes.id, { onDelete: "set null" }),
    role: varchar("role", { length: 20 }).notNull().default("student"), // superadmin | admin | student
    title: varchar("title", { length: 80 }), // مدیر ارشد / مسئول آمار / مدیر قرارگاه ...
    permissions: jsonb("permissions").$type<string[]>(), // برای مدیران فرعی
    janm: integer("janm").notNull().default(0),
    isApproved: boolean("is_approved").notNull().default(true),
    isBlocked: boolean("is_blocked").notNull().default(false),
    avatarColor: varchar("avatar_color", { length: 20 }).notNull().default("blue"),
    avatarUrl: text("avatar_url"),
    notifyPrefs: jsonb("notify_prefs").$type<{
      announcements?: boolean;
      janm?: boolean;
      exams?: boolean;
    }>(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("users_class_idx").on(t.classId), index("users_janm_idx").on(t.janm)],
);

/* ------------------------------------------------------------------ */
/*  نشست‌ها (Session امن)                                               */
/* ------------------------------------------------------------------ */
export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(), // sha256(token)
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

/* ------------------------------------------------------------------ */
/*  قرارگاه‌ها                                                          */
/* ------------------------------------------------------------------ */
export const bases = pgTable("bases", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 40 }).notNull().unique(),
  name: varchar("name", { length: 80 }).notNull(),
  managerName: varchar("manager_name", { length: 140 }).notNull(),
  managerUserId: integer("manager_user_id").references(() => users.id, { onDelete: "set null" }),
  description: text("description").notNull().default(""),
  icon: varchar("icon", { length: 40 }).notNull().default("shield"),
  hue: varchar("hue", { length: 40 }).notNull().default("blue"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const baseMembers = pgTable(
  "base_members",
  {
    id: serial("id").primaryKey(),
    baseId: integer("base_id")
      .notNull()
      .references(() => bases.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("base_members_unique").on(t.baseId, t.userId)],
);

/* ------------------------------------------------------------------ */
/*  امتحانات                                                           */
/* ------------------------------------------------------------------ */
export const exams = pgTable("exams", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 160 }).notNull(),
  description: text("description").notNull().default(""),
  examDate: timestamp("exam_date", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/* ------------------------------------------------------------------ */
/*  افتخارات                                                           */
/* ------------------------------------------------------------------ */
export const honors = pgTable(
  "honors",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 180 }).notNull(),
    description: text("description").notNull().default(""),
    awardDate: timestamp("award_date", { withTimezone: true }).notNull(),
    createdById: integer("created_by_id"),
    createdByName: varchar("created_by_name", { length: 140 }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("honors_user_idx").on(t.userId)],
);

/* ------------------------------------------------------------------ */
/*  اطلاعیه‌ها                                                          */
/* ------------------------------------------------------------------ */
export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  createdById: integer("created_by_id"),
  createdByName: varchar("created_by_name", { length: 140 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }),
});

/* ------------------------------------------------------------------ */
/*  تراکنش‌های جنم (هر تغییر جنم = یک سابقه)                            */
/* ------------------------------------------------------------------ */
export const janmTransactions = pgTable(
  "janm_transactions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    amount: integer("amount").notNull(),
    kind: varchar("kind", { length: 24 }).notNull().default("manual"),
    // manual | absence | lateness | lateness_penalty | disorder | correction
    reason: varchar("reason", { length: 220 }).notNull(),
    note: text("note").notNull().default(""),
    actorId: integer("actor_id"),
    actorName: varchar("actor_name", { length: 140 }).notNull().default(""),
    status: varchar("status", { length: 16 }).notNull().default("active"), // active | corrected | void
    correctsId: integer("corrects_id"), // در صورت اصلاح، آی‌دی تراکنش اصلی
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("janm_user_idx").on(t.userId), index("janm_created_idx").on(t.createdAt)],
);

/* ------------------------------------------------------------------ */
/*  درخواست‌های بازیابی رمز عبور                                        */
/* ------------------------------------------------------------------ */
export const passwordResets = pgTable("password_resets", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 60 }).notNull(),
  fullName: varchar("full_name", { length: 140 }).notNull().default(""),
  note: text("note").notNull().default(""),
  status: varchar("status", { length: 16 }).notNull().default("pending"), // pending | done | rejected
  handledByName: varchar("handled_by_name", { length: 140 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  handledAt: timestamp("handled_at", { withTimezone: true }),
});

/* ------------------------------------------------------------------ */
/*  گزارش فعالیت مدیران                                                 */
/* ------------------------------------------------------------------ */
export const activityLogs = pgTable(
  "activity_logs",
  {
    id: serial("id").primaryKey(),
    actorId: integer("actor_id"),
    actorName: varchar("actor_name", { length: 140 }).notNull().default(""),
    action: varchar("action", { length: 100 }).notNull(),
    detail: text("detail").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("logs_created_idx").on(t.createdAt)],
);

export type UserRow = typeof users.$inferSelect;
export type ClassRow = typeof classes.$inferSelect;
export type BaseRow = typeof bases.$inferSelect;
export type ExamRow = typeof exams.$inferSelect;
export type HonorRow = typeof honors.$inferSelect;
export type AnnouncementRow = typeof announcements.$inferSelect;
export type JanmTransactionRow = typeof janmTransactions.$inferSelect;
