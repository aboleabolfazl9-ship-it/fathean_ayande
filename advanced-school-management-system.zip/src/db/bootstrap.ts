import { sql } from "drizzle-orm";
import { db } from "@/db";

/* ------------------------------------------------------------------ */
/*  ساخت خودکار جداول در اولین اجرا — برای استقرار بدون دستور دستی      */
/*  همه دستورها idempotent هستند (IF NOT EXISTS)                        */
/* ------------------------------------------------------------------ */

const DDL = `
CREATE TABLE IF NOT EXISTS classes (
  id serial PRIMARY KEY,
  name varchar(40) NOT NULL UNIQUE,
  code varchar(8) NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id serial PRIMARY KEY,
  username varchar(60) NOT NULL UNIQUE,
  password_hash text NOT NULL,
  full_name varchar(140) NOT NULL,
  class_id integer REFERENCES classes(id) ON DELETE SET NULL,
  role varchar(20) NOT NULL DEFAULT 'student',
  title varchar(80),
  permissions jsonb,
  janm integer NOT NULL DEFAULT 0,
  is_approved boolean NOT NULL DEFAULT true,
  is_blocked boolean NOT NULL DEFAULT false,
  avatar_color varchar(20) NOT NULL DEFAULT 'blue',
  avatar_url text,
  notify_prefs jsonb,
  created_at timestamptz DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS users_class_idx ON users(class_id);
CREATE INDEX IF NOT EXISTS users_janm_idx ON users(janm);

CREATE TABLE IF NOT EXISTS sessions (
  id text PRIMARY KEY,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now() NOT NULL,
  expires_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions(user_id);

CREATE TABLE IF NOT EXISTS bases (
  id serial PRIMARY KEY,
  slug varchar(40) NOT NULL UNIQUE,
  name varchar(80) NOT NULL,
  manager_name varchar(140) NOT NULL,
  manager_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  description text NOT NULL DEFAULT '',
  icon varchar(40) NOT NULL DEFAULT 'shield',
  hue varchar(40) NOT NULL DEFAULT 'blue',
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS base_members (
  id serial PRIMARY KEY,
  base_id integer NOT NULL REFERENCES bases(id) ON DELETE CASCADE,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now() NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS base_members_unique ON base_members(base_id, user_id);

CREATE TABLE IF NOT EXISTS exams (
  id serial PRIMARY KEY,
  title varchar(160) NOT NULL,
  description text NOT NULL DEFAULT '',
  exam_date timestamptz NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS honors (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title varchar(180) NOT NULL,
  description text NOT NULL DEFAULT '',
  award_date timestamptz NOT NULL,
  created_by_id integer,
  created_by_name varchar(140),
  created_at timestamptz DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS honors_user_idx ON honors(user_id);

CREATE TABLE IF NOT EXISTS announcements (
  id serial PRIMARY KEY,
  title varchar(180) NOT NULL,
  body text NOT NULL,
  created_by_id integer,
  created_by_name varchar(140),
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz
);

CREATE TABLE IF NOT EXISTS janm_transactions (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  kind varchar(24) NOT NULL DEFAULT 'manual',
  reason varchar(220) NOT NULL,
  note text NOT NULL DEFAULT '',
  actor_id integer,
  actor_name varchar(140) NOT NULL DEFAULT '',
  status varchar(16) NOT NULL DEFAULT 'active',
  corrects_id integer,
  created_at timestamptz DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS janm_user_idx ON janm_transactions(user_id);
CREATE INDEX IF NOT EXISTS janm_created_idx ON janm_transactions(created_at);

CREATE TABLE IF NOT EXISTS password_resets (
  id serial PRIMARY KEY,
  username varchar(60) NOT NULL,
  full_name varchar(140) NOT NULL DEFAULT '',
  note text NOT NULL DEFAULT '',
  status varchar(16) NOT NULL DEFAULT 'pending',
  handled_by_name varchar(140),
  created_at timestamptz DEFAULT now() NOT NULL,
  handled_at timestamptz
);

CREATE TABLE IF NOT EXISTS activity_logs (
  id serial PRIMARY KEY,
  actor_id integer,
  actor_name varchar(140) NOT NULL DEFAULT '',
  action varchar(100) NOT NULL,
  detail text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS logs_created_idx ON activity_logs(created_at);
`;

let ensured = false;

/** اگر جداول وجود نداشتند می‌سازد؛ در غیر این صورت بدون تغییر عبور می‌کند */
export async function ensureSchema() {
  if (ensured) return;
  ensured = true;
  try {
    const [{ exists }] = await db.execute<{ exists: boolean }>(
      sql`select exists (select 1 from information_schema.tables where table_schema = 'public' and table_name = 'users') as exists`,
    ).then((r) => r.rows);
    if (exists) return;
    console.log("[bootstrap] ساخت جداول پایگاه‌داده...");
    for (const statement of DDL.split(";").map((s) => s.trim()).filter(Boolean)) {
      await db.execute(sql.raw(statement));
    }
    console.log("[bootstrap] جداول با موفقیت ساخته شدند.");
  } catch (e) {
    ensured = false;
    console.error("[bootstrap] خطا در آماده‌سازی جداول:", e);
  }
}
