import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { createInitialState, type DemoState, type StudentRecord, type TransactionRecord, type TransactionKind } from "./data/seed";
import { demoAccounts, staffProfiles } from "./data/content";

const STORAGE_KEY = "fatehan-future-static-demo-v1";

type Session = {
  profileId: string;
  username: string;
};

type AuthProfile = {
  id: string;
  fullName: string;
  role: "admin" | "staff" | "student";
  title?: string;
  classCode?: string;
  studentNumber?: string;
  janam?: number;
  avatarTone?: string;
};

type AppStateValue = {
  state: DemoState;
  session: Session | null;
  profile: AuthProfile | null;
  signIn: (username: string, demoCode: string) => { ok: boolean; message: string };
  signOut: () => void;
  submitRegistration: (payload: { fullName: string; classCode: string; username: string }) => { ok: boolean; message: string };
  approveRegistration: (registrationId: string) => void;
  rejectRegistration: (registrationId: string) => void;
  addTransaction: (payload: {
    studentIds: string[];
    kind: TransactionKind | "manualPlus" | "manualMinus";
    amount?: number;
    reason: string;
    actor: string;
  }) => void;
  addAnnouncement: (payload: { title: string; body: string; category: string }) => void;
  addHonor: (payload: { studentId: string; title: string; description: string; date: string; type: string }) => void;
  addExam: (payload: { title: string; subject: string; classCode: string; jalaliDate: string; fullDate: string; status: string; note: string }) => void;
  toggleTheme: () => void;
  theme: "dark" | "light";
  updateProfileDemo: (payload: { avatarTone?: string; blocked?: boolean }) => void;
};

const AppStateContext = createContext<AppStateValue | null>(null);

function hydrate(): DemoState {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (!saved) return createInitialState();
  try {
    return JSON.parse(saved) as DemoState;
  } catch {
    return createInitialState();
  }
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<DemoState>(() => createInitialState());
  const [session, setSession] = useState<Session | null>(null);
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    setState(hydrate());
    const savedSession = localStorage.getItem(`${STORAGE_KEY}:session`);
    const savedTheme = localStorage.getItem(`${STORAGE_KEY}:theme`) as "dark" | "light" | null;
    if (savedSession) {
      try {
        setSession(JSON.parse(savedSession));
      } catch {}
    }
    if (savedTheme === "dark" || savedTheme === "light") {
      setTheme(savedTheme);
      document.documentElement.dataset.theme = savedTheme;
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  useEffect(() => {
    if (session) localStorage.setItem(`${STORAGE_KEY}:session`, JSON.stringify(session));
    else localStorage.removeItem(`${STORAGE_KEY}:session`);
  }, [session]);

  const profile = useMemo<AuthProfile | null>(() => {
    if (!session) return null;
    const staff = staffProfiles.find((item) => item.id === session.profileId);
    if (staff) return staff;
    const student = state.students.find((item) => item.id === session.profileId);
    if (!student) return null;
    return {
      id: student.id,
      fullName: student.fullName,
      role: student.role,
      title: student.title,
      classCode: student.classCode,
      studentNumber: student.studentNumber,
      janam: student.janam,
      avatarTone: student.avatarTone,
    };
  }, [session, state.students]);

  const signIn = (username: string, demoCode: string) => {
    const account = demoAccounts.find((item) => item.username === username.trim());
    if (!account) return { ok: false, message: "حساب نمایشی یافت نشد." };
    if (!demoCode.trim()) return { ok: false, message: "کد نمایشی را وارد کنید." };
    setSession({ profileId: account.profileId, username: account.username });
    return { ok: true, message: `ورود نمایشی ${account.role} انجام شد.` };
  };

  const submitRegistration = (payload: { fullName: string; classCode: string; username: string }) => {
    if (state.students.some((item) => item.username === payload.username) || state.pendingRegistrations.some((item) => item.username === payload.username)) {
      return { ok: false, message: "این نام کاربری قبلاً ثبت شده است." };
    }
    setState((current) => ({
      ...current,
      pendingRegistrations: [
        ...current.pendingRegistrations,
        {
          id: `pending-${Date.now()}`,
          fullName: payload.fullName,
          classCode: payload.classCode,
          username: payload.username,
          submittedAt: new Date().toISOString(),
        },
      ],
    }));
    return { ok: true, message: "درخواست ثبت‌نام در نسخه نمایشی ثبت شد و باید توسط مدیر تأیید شود." };
  };

  const approveRegistration = (registrationId: string) => {
    setState((current) => {
      const target = current.pendingRegistrations.find((item) => item.id === registrationId);
      if (!target) return current;
      const nextId = `stu-${current.students.length + 1}`;
      const newStudent: StudentRecord = {
        id: nextId,
        studentNumber: `فا/جدید/${String(current.students.length + 1).padStart(2, "0")}`,
        username: target.username,
        fullName: target.fullName,
        classCode: target.classCode,
        role: "student",
        avatarTone: "blue",
        janam: 0,
        approved: true,
        blocked: false,
        absences: 0,
        latenessCount: 0,
        disorderCount: 0,
        achievements: [],
      };
      return {
        ...current,
        students: [...current.students, newStudent],
        pendingRegistrations: current.pendingRegistrations.filter((item) => item.id !== registrationId),
      };
    });
  };

  const rejectRegistration = (registrationId: string) => {
    setState((current) => ({
      ...current,
      pendingRegistrations: current.pendingRegistrations.filter((item) => item.id !== registrationId),
    }));
  };

  const addTransaction = (payload: {
    studentIds: string[];
    kind: TransactionKind | "manualPlus" | "manualMinus";
    amount?: number;
    reason: string;
    actor: string;
  }) => {
    setState((current) => {
      const transactions: TransactionRecord[] = [...current.transactions];
      const students = current.students.map((student) => ({ ...student }));
      payload.studentIds.forEach((studentId) => {
        const student = students.find((item) => item.id === studentId);
        if (!student) return;
        let amount = 0;
        let kind: TransactionKind = "positive";
        let reason = payload.reason;
        if (payload.kind === "manualPlus") {
          amount = Math.abs(payload.amount ?? 0);
          kind = "positive";
        } else if (payload.kind === "manualMinus") {
          amount = -Math.abs(payload.amount ?? 0);
          kind = "negative";
        } else if (payload.kind === "absence") {
          amount = -10;
          kind = "absence";
          reason = "غیبت غیرموجه";
          student.absences += 1;
        } else if (payload.kind === "disorder") {
          amount = -2;
          kind = "disorder";
          reason = "بی‌نظمی";
          student.disorderCount += 1;
        } else if (payload.kind === "lateness") {
          student.latenessCount += 1;
          transactions.push({
            id: `tx-${Date.now()}-${studentId}-l`,
            studentId,
            amount: 0,
            kind: "lateness",
            reason: "ثبت تأخیر در ورود",
            actor: payload.actor,
            date: new Date().toLocaleDateString("fa-IR"),
            time: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" }),
          });
          if (student.latenessCount % 3 === 0) {
            amount = -5;
            kind = "lateness-penalty";
            reason = "کسر جنم پس از سه بار تأخیر";
          } else {
            amount = 0;
            kind = "lateness";
            reason = "تأخیر ثبت شد؛ هنوز به سه مورد نرسیده است.";
          }
        }
        student.janam += amount;
        transactions.push({
          id: `tx-${Date.now()}-${studentId}-${kind}`,
          studentId,
          amount,
          kind,
          reason,
          actor: payload.actor,
          date: new Date().toLocaleDateString("fa-IR"),
          time: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" }),
        });
      });
      return { ...current, students, transactions };
    });
  };

  const addAnnouncement = (payload: { title: string; body: string; category: string }) => {
    setState((current) => ({
      ...current,
      announcements: [
        {
          id: `ann-${Date.now()}`,
          title: payload.title,
          body: payload.body,
          category: payload.category,
          author: "دفتر مدیریت",
          date: new Date().toLocaleDateString("fa-IR"),
        },
        ...current.announcements,
      ],
    }));
  };

  const addHonor = (payload: { studentId: string; title: string; description: string; date: string; type: string }) => {
    setState((current) => ({
      ...current,
      honors: [{ id: `honor-${Date.now()}`, ...payload }, ...current.honors],
    }));
  };

  const addExam = (payload: { title: string; subject: string; classCode: string; jalaliDate: string; fullDate: string; status: string; note: string }) => {
    setState((current) => ({
      ...current,
      exams: [...current.exams, { id: `exam-${Date.now()}`, ...payload }],
    }));
  };

  const toggleTheme = () => {
    setTheme((current) => {
      const next = current === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = next;
      localStorage.setItem(`${STORAGE_KEY}:theme`, next);
      return next;
    });
  };

  const updateProfileDemo = (payload: { avatarTone?: string; blocked?: boolean }) => {
    if (!profile || profile.role !== "student") return;
    setState((current) => ({
      ...current,
      students: current.students.map((student) =>
        student.id === profile.id
          ? {
              ...student,
              avatarTone: payload.avatarTone ?? student.avatarTone,
              blocked: payload.blocked ?? student.blocked,
            }
          : student,
      ),
    }));
  };

  const value: AppStateValue = {
    state,
    session,
    profile,
    signIn,
    signOut: () => setSession(null),
    submitRegistration,
    approveRegistration,
    rejectRegistration,
    addTransaction,
    addAnnouncement,
    addHonor,
    addExam,
    toggleTheme,
    theme,
    updateProfileDemo,
  };

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const context = useContext(AppStateContext);
  if (!context) throw new Error("useAppState must be used inside AppStateProvider");
  return context;
}
