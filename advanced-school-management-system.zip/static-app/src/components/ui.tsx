import { Link, NavLink } from "react-router-dom";
import { clsx } from "clsx";
import { fa, faNumber, avatarGradient } from "../lib/format";
import type { ReactNode } from "react";

export function LogoMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={clsx("logo-mark", compact && "compact")}>ف</div>
  );
}

export function BrandBlock() {
  return (
    <Link to="/" className="brand-block">
      <LogoMark />
      <div>
        <strong>مدرسه فاتحان آینده</strong>
        <span>سامانه هوشمند مدیریت مدرسه</span>
      </div>
    </Link>
  );
}

export function PageIntro({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <header className="page-intro">
      <div>
        <h1>{title}</h1>
        {subtitle ? <p>{subtitle}</p> : null}
      </div>
      {action ? <div className="page-intro-action">{action}</div> : null}
    </header>
  );
}

export function Surface({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={clsx("surface-card", className)}>{children}</section>;
}

export function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "blue" | "orange" | "gold" | "green" | "danger" }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

export function AvatarChip({ name, tone = "blue", size = 44 }: { name: string; tone?: string; size?: number }) {
  return (
    <span
      className="avatar-chip"
      style={{ width: size, height: size, background: avatarGradient(tone), fontSize: size * 0.42 }}
      aria-hidden
    >
      {name.trim().charAt(0)}
    </span>
  );
}

export function StudentInline({ name, tone, subtitle }: { name: string; tone?: string; subtitle?: string }) {
  return (
    <div className="student-inline">
      <AvatarChip name={name} tone={tone} size={38} />
      <div>
        <strong>{name}</strong>
        {subtitle ? <span>{subtitle}</span> : null}
      </div>
    </div>
  );
}

export function MetricCard({ label, value, helper, accent = "blue" }: { label: string; value: string | number; helper?: string; accent?: "blue" | "orange" | "gold" | "green" }) {
  return (
    <div className={`metric-card metric-${accent}`}>
      <span>{label}</span>
      <strong>{typeof value === "number" ? faNumber(value) : value}</strong>
      {helper ? <small>{helper}</small> : null}
    </div>
  );
}

export function NavItem({ to, icon, label }: { to: string; icon: ReactNode; label: string }) {
  return (
    <NavLink to={to} className={({ isActive }) => clsx("nav-item", isActive && "active")}>
      <span className="nav-icon-wrap">{icon}</span>
      <span>{label}</span>
    </NavLink>
  );
}

export function EmptyBlock({ title, description }: { title: string; description: string }) {
  return (
    <div className="empty-block">
      <strong>{title}</strong>
      <p>{description}</p>
    </div>
  );
}

export function NumberCell({ value, positiveAsGold = false }: { value: number; positiveAsGold?: boolean }) {
  const className = value > 0 ? (positiveAsGold ? "text-gold" : "text-green") : value < 0 ? "text-danger" : "text-muted";
  return (
    <strong className={className} dir="ltr">
      {value > 0 ? `+${fa(value)}` : fa(value)}
    </strong>
  );
}

export function RankPill({ rank }: { rank: number }) {
  return <span className={clsx("rank-pill", rank === 1 && "first", rank === 2 && "second", rank === 3 && "third")}>{fa(rank)}</span>;
}
