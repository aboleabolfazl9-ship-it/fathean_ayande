import {
  BellRing,
  BookOpenText,
  CalendarClock,
  Crown,
  Gauge,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Medal,
  Megaphone,
  MoonStar,
  ShieldCheck,
  SunMedium,
  Trophy,
  Users,
} from "lucide-react";
import { Outlet } from "react-router-dom";
import { BrandBlock, NavItem, StudentInline } from "./ui";
import { useAppState } from "../app-state";

export function ShellLayout() {
  const { profile, signOut, toggleTheme, theme } = useAppState();
  if (!profile) return null;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <BrandBlock />

        <div className="nav-list">
          <NavItem to="/" icon={<LayoutDashboard size={18} />} label="صفحه اصلی" />
          <NavItem to="/classes" icon={<GraduationCap size={18} />} label="کلاس‌ها" />
          <NavItem to="/students" icon={<Users size={18} />} label="پرونده دانش‌آموزان" />
          <NavItem to="/bases" icon={<ShieldCheck size={18} />} label="قرارگاه‌ها" />
          <NavItem to="/exams" icon={<CalendarClock size={18} />} label="امتحانات" />
          <NavItem to="/announcements" icon={<Megaphone size={18} />} label="اطلاعیه‌ها" />
          <NavItem to="/honors" icon={<Trophy size={18} />} label="افتخارات" />
          <NavItem to="/settings" icon={<BellRing size={18} />} label="تنظیمات و حساب" />
          {(profile.role === "admin" || profile.role === "staff") && (
            <NavItem to="/admin" icon={<Crown size={18} />} label="پنل مدیریت مدرسه" />
          )}
        </div>

        <div className="sidebar-footer">
          <StudentInline
            name={profile.fullName}
            tone={profile.avatarTone ?? "blue"}
            subtitle={profile.title ?? (profile.classCode ? `کلاس ${profile.classCode}` : "سامانه مرکزی")}
          />
          <div className="actions-row" style={{ marginTop: 14 }}>
            <button className="ghost-btn" onClick={toggleTheme}>
              {theme === "dark" ? <SunMedium size={16} /> : <MoonStar size={16} />}
              {theme === "dark" ? "حالت روشن" : "حالت تاریک"}
            </button>
            <button className="danger-btn" onClick={signOut}>
              <LogOut size={16} />
              خروج
            </button>
          </div>
        </div>
      </aside>

      <main className="main-area">
        <div className="top-strip">
          <span className="role-strip">
            {profile.role === "admin" ? <Crown size={16} /> : profile.role === "staff" ? <BookOpenText size={16} /> : <Medal size={16} />}
            {profile.role === "admin" ? "دسترسی مدیر اصلی" : profile.role === "staff" ? "دسترسی کادر مدرسه" : "حساب دانش‌آموزی نمایشی"}
          </span>
          <button className="theme-toggle" onClick={toggleTheme}>
            {theme === "dark" ? <SunMedium size={16} /> : <MoonStar size={16} />}
            تغییر پوسته
          </button>
        </div>
        <Outlet />
      </main>
    </div>
  );
}
