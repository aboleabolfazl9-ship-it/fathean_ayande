import React from "react";
import ReactDOM from "react-dom/client";
import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import { AppStateProvider, useAppState } from "./app-state";
import { ShellLayout } from "./components/layout";
import {
  AdminPage,
  AnnouncementsPage,
  AuthPage,
  BasesPage,
  ClassesPage,
  DashboardPage,
  ExamsPage,
  HonorsPage,
  SettingsPage,
  StudentProfilePage,
  StudentsIndexPage,
} from "./pages";
import "./styles.css";

function Protected() {
  const { session } = useAppState();
  if (!session) return <Navigate to="/login" replace />;
  return <ShellLayout />;
}

function AppRouter() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/login" element={<AuthPage />} />
        <Route element={<Protected />}>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/classes" element={<ClassesPage />} />
          <Route path="/students" element={<StudentsIndexPage />} />
          <Route path="/students/:studentId" element={<StudentProfilePage />} />
          <Route path="/bases" element={<BasesPage />} />
          <Route path="/exams" element={<ExamsPage />} />
          <Route path="/announcements" element={<AnnouncementsPage />} />
          <Route path="/honors" element={<HonorsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/admin" element={<AdminPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AppStateProvider>
      <AppRouter />
    </AppStateProvider>
  </React.StrictMode>,
);
