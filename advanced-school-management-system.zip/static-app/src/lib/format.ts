import * as jalaali from "jalaali-js";

const faDigits = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
const months = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];
const weekdays = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];

export const fa = (value: number | string) => String(value).replace(/\d/g, (d) => faDigits[Number(d)]);
export const faNumber = (value: number) => `${value < 0 ? "−" : ""}${fa(Math.abs(value).toLocaleString("en-US").replace(/,/g, "٬"))}`;

export const classLabel = (code: string) => `کلاس ${fa(code)}`;

export function toJalaliParts(date = new Date()) {
  return jalaali.toJalaali(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

export function currentJalaliDate(date = new Date()) {
  const j = toJalaliParts(date);
  return `${fa(j.jd)} ${months[j.jm - 1]} ${fa(j.jy)}`;
}

export function currentWeekday(date = new Date()) {
  return weekdays[date.getDay()];
}

export function currentTime(date = new Date()) {
  const hh = String(date.getHours()).padStart(2, "0");
  const mm = String(date.getMinutes()).padStart(2, "0");
  return fa(`${hh}:${mm}`);
}

export function avatarGradient(tone: string) {
  const tones: Record<string, string> = {
    blue: "linear-gradient(135deg, #1A3F87 0%, #2457B4 100%)",
    indigo: "linear-gradient(135deg, #4234B8 0%, #7065FF 100%)",
    teal: "linear-gradient(135deg, #0F766E 0%, #14B8A6 100%)",
    sky: "linear-gradient(135deg, #0C4A6E 0%, #38BDF8 100%)",
    violet: "linear-gradient(135deg, #5B21B6 0%, #C084FC 100%)",
    slate: "linear-gradient(135deg, #334155 0%, #94A3B8 100%)",
    amber: "linear-gradient(135deg, #B45309 0%, #F59E0B 100%)",
  };
  return tones[tone] ?? tones.blue;
}

export function signedJanam(value: number) {
  if (value > 0) return `+${faNumber(value)}`;
  return faNumber(value);
}

export function rankMedal(rank: number) {
  if (rank === 1) return "طلایی";
  if (rank === 2) return "نقره‌ای";
  if (rank === 3) return "برنزی";
  return "رتبه";
}
