import { useMemo, useState } from "react";
import {
  Award,
  BookOpenText,
  CalendarClock,
  CheckCircle2,
  Crown,
  Flame,
  GraduationCap,
  Megaphone,
  Medal,
  NotebookTabs,
  ShieldCheck,
  Sparkles,
  Trophy,
  UserPlus,
  Users,
} from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAppState } from "./app-state";
import { currentJalaliDate, currentTime, currentWeekday, fa, faNumber, signedJanam, classLabel, rankMedal } from "./lib/format";
import { schoolMeta } from "./data/content";
import { Badge, EmptyBlock, MetricCard, NumberCell, PageIntro, RankPill, StudentInline, Surface } from "./components/ui";
import type { StudentRecord } from "./data/seed";

function useComputed() {
  const { state } = useAppState();
  return useMemo(() => {
    const approvedStudents = state.students.filter((item) => item.approved);
    const schoolSorted = [...approvedStudents].sort((a, b) => b.janam - a.janam || a.fullName.localeCompare(b.fullName, "fa"));
    const schoolRanks = new Map<string, number>();
    schoolSorted.forEach((student, index) => schoolRanks.set(student.id, index + 1));

    const classRanks = new Map<string, number>();
    state.classes.forEach((schoolClass) => {
      const items = approvedStudents
        .filter((student) => student.classCode === schoolClass.code)
        .sort((a, b) => b.janam - a.janam || a.fullName.localeCompare(b.fullName, "fa"));
      items.forEach((student, index) => classRanks.set(student.id, index + 1));
    });

    const byClass = state.classes.map((schoolClass) => {
      const students = approvedStudents.filter((student) => student.classCode === schoolClass.code);
      const totalJanam = students.reduce((sum, student) => sum + student.janam, 0);
      return {
        ...schoolClass,
        students,
        count: students.length,
        avgJanam: students.length ? Math.round(totalJanam / students.length) : 0,
        topStudent: [...students].sort((a, b) => b.janam - a.janam)[0] ?? null,
      };
    });

    return { approvedStudents, schoolSorted, schoolRanks, classRanks, byClass };
  }, [state]);
}

export function AuthPage() {
  const navigate = useNavigate();
  const { signIn, submitRegistration } = useAppState();
  const [tab, setTab] = useState<"login" | "register">("login");
  const [loginForm, setLoginForm] = useState({ username: "admin-demo", code: "demo" });
  const [registerForm, setRegisterForm] = useState({ fullName: "", classCode: "7/1", username: "" });
  const [feedback, setFeedback] = useState<string | null>(null);
  const [feedbackTone, setFeedbackTone] = useState<"ok" | "error">("ok");

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <div className="auth-showcase" style={{ backgroundImage: `url(${schoolMeta.heroImage})` }}>
          <div className="auth-overlay">
            <div>
              <Badge tone="gold">نسخه نمایشی قابل انتشار روی GitHub Pages</Badge>
              <h2>
                سامانه هوشمند <span className="text-gold">مدرسه فاتحان آینده</span>
              </h2>
              <p>
                همه‌چیز فارسی، راست‌چین، مدرسه‌محور و مبتنی بر تقویم شمسی طراحی شده است؛ از جنم و پرونده دانش‌آموز تا قرارگاه‌ها، امتحانات و پنل مدیریت.
              </p>
            </div>
            <div className="three-col-grid">
              <Surface>
                <strong>۸۶ دانش‌آموز واقعی</strong>
                <p className="footer-note">فهرست کامل کلاس‌های ۷/۱، ۸/۱، ۸/۲، ۹/۱ و ۹/۲</p>
              </Surface>
              <Surface>
                <strong>سیستم جنم</strong>
                <p className="footer-note">ثبت امتیاز مثبت و منفی با تاریخچه کامل و رتبه‌بندی خودکار</p>
              </Surface>
              <Surface>
                <strong>پنل مدیریت</strong>
                <p className="footer-note">مدیریت اطلاعیه‌ها، افتخارات، امتحانات، دانش‌آموزان و قرارگاه‌ها</p>
              </Surface>
            </div>
          </div>
        </div>

        <div className="auth-panel">
          <Badge tone="blue">{currentWeekday()} • {currentJalaliDate()} • ساعت {currentTime()}</Badge>
          <h1>ورود نمایشی به سامانه</h1>
          <p>
            این نسخه برای نمایش رابط کاربری و فرایندهای اصلی مدرسه ساخته شده است. هیچ رمز واقعی ذخیره یا بررسی نمی‌شود و همه داده‌ها در مرورگر شما نگه‌داری می‌شود.
          </p>

          <div className="auth-tabs">
            <button className={tab === "login" ? "active" : ""} onClick={() => setTab("login")}>ورود نمایشی</button>
            <button className={tab === "register" ? "active" : ""} onClick={() => setTab("register")}>ثبت‌نام آزمایشی</button>
          </div>

          {tab === "login" ? (
            <div className="form-grid">
              <label className="form-field">
                <span>نام کاربری نمایشی</span>
                <input className="text-field" value={loginForm.username} onChange={(event) => setLoginForm((current) => ({ ...current, username: event.target.value }))} dir="ltr" />
              </label>
              <label className="form-field">
                <span>کد نمایشی</span>
                <input className="text-field" value={loginForm.code} onChange={(event) => setLoginForm((current) => ({ ...current, code: event.target.value }))} dir="ltr" />
              </label>
              <div className="info-box">
                حساب‌های آماده: <b dir="ltr">admin-demo</b> برای مدیر اصلی، <b dir="ltr">staff-demo</b> برای کادر مدرسه و <b dir="ltr">7101</b> برای نمونه دانش‌آموز.
              </div>
              <div className="actions-row">
                <button
                  className="primary-btn"
                  onClick={() => {
                    const result = signIn(loginForm.username, loginForm.code);
                    setFeedback(result.message);
                    setFeedbackTone(result.ok ? "ok" : "error");
                    if (result.ok) navigate("/");
                  }}
                >
                  ورود به سامانه
                </button>
              </div>
            </div>
          ) : (
            <div className="form-grid">
              <label className="form-field">
                <span>نام و نام خانوادگی</span>
                <input className="text-field" value={registerForm.fullName} onChange={(event) => setRegisterForm((current) => ({ ...current, fullName: event.target.value }))} />
              </label>
              <label className="form-field">
                <span>پایه و کلاس</span>
                <select className="text-field" value={registerForm.classCode} onChange={(event) => setRegisterForm((current) => ({ ...current, classCode: event.target.value }))}>
                  <option value="7/1">۷/۱</option>
                  <option value="8/1">۸/۱</option>
                  <option value="8/2">۸/۲</option>
                  <option value="9/1">۹/۱</option>
                  <option value="9/2">۹/۲</option>
                </select>
              </label>
              <label className="form-field">
                <span>نام کاربری پیشنهادی</span>
                <input className="text-field" value={registerForm.username} onChange={(event) => setRegisterForm((current) => ({ ...current, username: event.target.value }))} dir="ltr" />
              </label>
              <button
                className="secondary-btn"
                onClick={() => {
                  const result = submitRegistration(registerForm);
                  setFeedback(result.message);
                  setFeedbackTone(result.ok ? "ok" : "error");
                  if (result.ok) setRegisterForm({ fullName: "", classCode: "7/1", username: "" });
                }}
              >
                ثبت درخواست نمایشی
              </button>
            </div>
          )}

          {feedback ? <div className={feedbackTone === "ok" ? "info-box" : "empty-block"} style={{ marginTop: 16 }}>{feedback}</div> : null}
        </div>
      </div>
    </div>
  );
}

export function DashboardPage() {
  const { state, profile } = useAppState();
  const { approvedStudents, schoolSorted, schoolRanks, byClass } = useComputed();
  const profileStudent = profile?.role === "student" ? state.students.find((item) => item.id === profile.id) : null;
  const upcomingExams = state.exams.slice(0, 3);
  const highlights = state.honors.slice(0, 4).map((honor) => ({
    ...honor,
    student: state.students.find((item) => item.id === honor.studentId),
  }));

  return (
    <div className="form-grid">
      <PageIntro
        title="صفحه اصلی سامانه"
        subtitle="نمای یکپارچه‌ی آموزشی، انضباطی، فرهنگی و دانش‌آموزی مدرسه فاتحان آینده"
        action={<Badge tone="blue">{currentWeekday()} • {currentJalaliDate()} • ساعت {currentTime()}</Badge>}
      />

      <Surface className="hero">
        <div className="hero-content">
          <Badge tone="gold">هویت رسمی مدرسه ایرانی • نسخه استاتیک نمایشی</Badge>
          <h2>
            {profileStudent ? `خوش آمدی ${profileStudent.fullName}` : `خوش آمدی ${profile?.fullName ?? "کاربر مدرسه"}`}
          </h2>
          <p>
            این داشبورد نمایی زنده از تعداد دانش‌آموزان، وضعیت جنم، امتحانات پیش‌رو، اطلاعیه‌های مهم و فعالیت‌های اخیر مدرسه را نمایش می‌دهد.
          </p>
          <div className="meta-row">
            <Badge tone="blue">{fa(approvedStudents.length)} دانش‌آموز</Badge>
            <Badge tone="green">{fa(byClass.length)} کلاس فعال</Badge>
            <Badge tone="orange">{fa(state.bases.length)} قرارگاه اختصاصی</Badge>
            {profileStudent ? <Badge tone="gold">رتبه شما در مدرسه: {fa(schoolRanks.get(profileStudent.id) ?? 0)}</Badge> : null}
          </div>
        </div>
        <div className="hero-media" style={{ backgroundImage: `url(${schoolMeta.heroImage})` }} />
      </Surface>

      <div className="metrics-grid">
        <MetricCard label="تعداد دانش‌آموزان" value={approvedStudents.length} helper="بر اساس داده‌های نمایشی ذخیره‌شده" />
        <MetricCard label="تعداد کلاس‌ها" value={byClass.length} accent="blue" helper="متوسطه اول مدرسه" />
        <MetricCard label="اطلاعیه‌های مهم" value={state.announcements.length} accent="orange" helper="قابل مدیریت از پنل مدرسه" />
        <MetricCard label="امتحانات ثبت‌شده" value={state.exams.length} accent="gold" helper="تقویم آموزشی شمسی" />
      </div>

      <div className="two-col-grid">
        <Surface>
          <div className="section-title">
            <h2>اطلاعیه‌های مهم مدرسه</h2>
            <Badge tone="blue">{fa(state.announcements.length)} مورد</Badge>
          </div>
          <div className="content-list">
            {state.announcements.slice(0, 4).map((item) => (
              <div className="content-row" key={item.id}>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.body}</p>
                </div>
                <Badge tone="neutral">{item.date}</Badge>
              </div>
            ))}
          </div>
        </Surface>

        <Surface>
          <div className="section-title">
            <h2>امتحانات پیش‌رو</h2>
            <Badge tone="orange">تقویم شمسی</Badge>
          </div>
          <div className="content-list">
            {upcomingExams.map((exam) => (
              <div className="content-row" key={exam.id}>
                <div>
                  <h3>{exam.title}</h3>
                  <p>{exam.subject} • {exam.classCode} • {exam.note}</p>
                </div>
                <div style={{ textAlign: "left" }}>
                  <Badge tone="gold">{exam.jalaliDate}</Badge>
                  <p className="footer-note">{exam.status}</p>
                </div>
              </div>
            ))}
          </div>
        </Surface>
      </div>

      <div className="three-col-grid">
        <Surface>
          <div className="section-title">
            <h2>رتبه‌بندی برتر مدرسه</h2>
            <Badge tone="gold">اول تا سوم</Badge>
          </div>
          <div className="content-list">
            {schoolSorted.slice(0, 3).map((student, index) => (
              <div className="content-row" key={student.id}>
                <StudentInline name={student.fullName} tone={student.avatarTone} subtitle={`${classLabel(student.classCode)} • ${rankMedal(index + 1)}`} />
                <div style={{ textAlign: "left" }}>
                  <RankPill rank={index + 1} />
                  <div className="footer-note">{signedJanam(student.janam)} جنم</div>
                </div>
              </div>
            ))}
          </div>
        </Surface>

        <Surface>
          <div className="section-title">
            <h2>وضعیت جنم</h2>
            <Badge tone="green">واحد امتیاز مدرسه</Badge>
          </div>
          {profileStudent ? (
            <div className="content-list">
              <MetricCard label="موجودی فعلی" value={profileStudent.janam} accent="green" helper="قابل ویرایش در پنل مدیریت" />
              <p className="footer-note">
                رتبه در مدرسه: {fa(schoolRanks.get(profileStudent.id) ?? 0)} • رتبه در کلاس: {fa(
                  (((byClass.find((item) => item.code === profileStudent.classCode)?.students ?? [])
                    .sort((a, b) => b.janam - a.janam || a.fullName.localeCompare(b.fullName, "fa"))
                    .findIndex((item) => item.id === profileStudent.id)) + 1) || 0,
                )}
              </p>
            </div>
          ) : (
            <EmptyBlock title="نمایش گروهی" description="برای مدیر و کادر مدرسه، وضعیت کلی جنم و رتبه‌بندی مدرسه از این بخش قابل مشاهده است." />
          )}
        </Surface>

        <Surface>
          <div className="section-title">
            <h2>فعالیت‌های اخیر مدرسه</h2>
            <Badge tone="blue">به‌روزرسانی‌ها</Badge>
          </div>
          <div className="content-list">
            {state.recentActivities.map((activity) => (
              <div className="content-row" key={activity.id}>
                <div>
                  <h3>{activity.title}</h3>
                  <p>{activity.detail}</p>
                </div>
                <Badge>{activity.date}</Badge>
              </div>
            ))}
          </div>
        </Surface>
      </div>

      <div className="two-col-grid">
        <Surface>
          <div className="section-title">
            <h2>افتخارات دانش‌آموزان</h2>
            <Badge tone="gold">نمایش سریع</Badge>
          </div>
          <div className="content-list">
            {highlights.map((item) => (
              <div className="content-row" key={item.id}>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
                <div style={{ textAlign: "left" }}>
                  <Badge tone="green">{item.type}</Badge>
                  <p className="footer-note">{item.student?.fullName ?? "—"}</p>
                </div>
              </div>
            ))}
          </div>
        </Surface>

        <Surface>
          <div className="section-title">
            <h2>نمای کلی کلاس‌ها</h2>
            <Badge tone="blue">میانگین جنم</Badge>
          </div>
          <div className="content-list">
            {byClass.map((schoolClass) => (
              <div className="content-row" key={schoolClass.id}>
                <div>
                  <h3>{schoolClass.title}</h3>
                  <p>{schoolClass.description}</p>
                </div>
                <div style={{ textAlign: "left" }}>
                  <Badge tone="blue">{fa(schoolClass.count)} نفر</Badge>
                  <p className="footer-note">میانگین جنم: {faNumber(schoolClass.avgJanam)}</p>
                </div>
              </div>
            ))}
          </div>
        </Surface>
      </div>
    </div>
  );
}

export function ClassesPage() {
  const { state } = useAppState();
  const { byClass, classRanks } = useComputed();

  return (
    <div className="form-grid">
      <PageIntro title="کلاس‌های مدرسه" subtitle="پنج کلاس فعال متوسطه اول همراه با فهرست دانش‌آموزان، رتبه‌بندی داخلی و میانگین جنم" />
      <div className="five-col-grid">
        {byClass.map((schoolClass) => (
          <Surface key={schoolClass.id}>
            <div className="section-title">
              <h2>{schoolClass.code}</h2>
              <Badge tone="blue">{fa(schoolClass.count)} نفر</Badge>
            </div>
            <p className="footer-note">{schoolClass.title}</p>
            <div className="meta-row" style={{ marginTop: 10 }}>
              <Badge tone="gold">میانگین جنم: {faNumber(schoolClass.avgJanam)}</Badge>
              <Badge tone="green">مشاور: {schoolClass.advisor}</Badge>
            </div>
            {schoolClass.topStudent ? <p className="footer-note">دانش‌آموز برتر: {schoolClass.topStudent.fullName}</p> : null}
          </Surface>
        ))}
      </div>

      {byClass.map((schoolClass) => (
        <Surface key={`${schoolClass.id}-table`}>
          <div className="section-title">
            <h2>{schoolClass.title}</h2>
            <Badge tone="orange">{schoolClass.room}</Badge>
          </div>
          <table className="rich-table">
            <thead>
              <tr>
                <th>رتبه داخلی</th>
                <th>دانش‌آموز</th>
                <th>شماره دانش‌آموزی</th>
                <th>جنم</th>
                <th>پرونده</th>
              </tr>
            </thead>
            <tbody>
              {schoolClass.students
                .slice()
                .sort((a, b) => (classRanks.get(a.id) ?? 99) - (classRanks.get(b.id) ?? 99))
                .map((student) => (
                  <tr key={student.id}>
                    <td><RankPill rank={classRanks.get(student.id) ?? 0} /></td>
                    <td>
                      <StudentInline
                        name={student.fullName}
                        tone={student.avatarTone}
                        subtitle={student.title ?? `شماره: ${student.username}`}
                      />
                    </td>
                    <td>{student.studentNumber}</td>
                    <td><NumberCell value={student.janam} positiveAsGold /></td>
                    <td><Link className="ghost-btn" to={`/students/${student.id}`}>مشاهده پرونده</Link></td>
                  </tr>
                ))}
            </tbody>
          </table>
        </Surface>
      ))}
    </div>
  );
}

export function StudentsIndexPage() {
  const { approvedStudents, schoolRanks, classRanks } = useComputed();
  const [query, setQuery] = useState("");
  const filtered = approvedStudents.filter((student) => student.fullName.includes(query) || student.username.includes(query));

  return (
    <div className="form-grid">
      <PageIntro title="پرونده دانش‌آموزان" subtitle="جست‌وجو در پرونده‌ها، رتبه‌ها، سوابق و اطلاعات کلاس هر دانش‌آموز" />
      <Surface>
        <label className="form-field">
          <span>جست‌وجوی دانش‌آموز</span>
          <input className="text-field" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="نام، نام خانوادگی یا نام کاربری" />
        </label>
      </Surface>
      <Surface>
        <table className="rich-table">
          <thead>
            <tr>
              <th>رتبه مدرسه</th>
              <th>دانش‌آموز</th>
              <th>کلاس</th>
              <th>رتبه کلاس</th>
              <th>جنم</th>
              <th>پرونده</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((student) => (
              <tr key={student.id}>
                <td><RankPill rank={schoolRanks.get(student.id) ?? 0} /></td>
                <td><StudentInline name={student.fullName} tone={student.avatarTone} subtitle={student.studentNumber} /></td>
                <td>{classLabel(student.classCode)}</td>
                <td>{fa(classRanks.get(student.id) ?? 0)}</td>
                <td><NumberCell value={student.janam} positiveAsGold /></td>
                <td><Link className="primary-btn" to={`/students/${student.id}`}>مشاهده پرونده</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Surface>
    </div>
  );
}

function StudentProfileBlocks({ student }: { student: StudentRecord }) {
  const { state } = useAppState();
  const { schoolRanks, classRanks } = useComputed();
  const honors = state.honors.filter((item) => item.studentId === student.id);
  const transactions = state.transactions.filter((item) => item.studentId === student.id).slice().reverse();
  const base = state.bases.find((item) => item.memberIds.includes(student.id));

  return (
    <div className="form-grid">
      <PageIntro
        title={`پرونده ${student.fullName}`}
        subtitle="نمای کامل اطلاعات هویتی، آموزشی، انضباطی و افتخارات دانش‌آموز"
        action={<Badge tone="gold">{student.title ?? "دانش‌آموز"}</Badge>}
      />

      <Surface>
        <div className="two-col-grid">
          <div className="content-list">
            <StudentInline name={student.fullName} tone={student.avatarTone} subtitle={`${student.studentNumber} • ${classLabel(student.classCode)}`} />
            <div className="meta-row">
              <Badge tone="blue">نام کاربری: {student.username}</Badge>
              <Badge tone="green">رتبه مدرسه: {fa(schoolRanks.get(student.id) ?? 0)}</Badge>
              <Badge tone="orange">رتبه کلاس: {fa(classRanks.get(student.id) ?? 0)}</Badge>
            </div>
            {base ? <p className="footer-note">عضو {base.title} • مسئول: {base.head}</p> : null}
          </div>
          <div className="metrics-grid" style={{ gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>
            <MetricCard label="جنم" value={student.janam} accent="gold" helper="واحد امتیاز مدرسه" />
            <MetricCard label="غیبت غیرموجه" value={student.absences} accent="orange" helper="مورد ثبت‌شده" />
            <MetricCard label="تأخیرها" value={student.latenessCount} accent="blue" helper="سه تأخیر = ۵- جنم" />
            <MetricCard label="بی‌نظمی‌ها" value={student.disorderCount} accent="green" helper="گزارش‌های ثبت‌شده" />
          </div>
        </div>
      </Surface>

      <div className="two-col-grid">
        <Surface>
          <div className="section-title">
            <h2>افتخارات ثبت‌شده</h2>
            <Badge tone="gold">{fa(honors.length)} مورد</Badge>
          </div>
          {honors.length ? (
            <div className="content-list">
              {honors.map((honor) => (
                <div className="content-row" key={honor.id}>
                  <div>
                    <h3>{honor.title}</h3>
                    <p>{honor.description}</p>
                  </div>
                  <div style={{ textAlign: "left" }}>
                    <Badge tone="green">{honor.type}</Badge>
                    <p className="footer-note">{honor.date}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <EmptyBlock title="افتخار ثبت نشده" description="فعلاً موردی برای این دانش‌آموز در نسخه نمایشی ثبت نشده است." />
          )}
        </Surface>

        <Surface>
          <div className="section-title">
            <h2>سوابق انضباطی و حضور</h2>
            <Badge tone="orange">به‌روزشونده بر اساس تراکنش‌ها</Badge>
          </div>
          <div className="content-list">
            <div className="content-row"><div><h3>حضور و غیاب</h3><p>غیبت‌های غیرموجه: {fa(student.absences)} مورد</p></div><Badge tone="danger">{fa(student.absences)}</Badge></div>
            <div className="content-row"><div><h3>تأخیر در ورود</h3><p>تعداد ثبت‌شده: {fa(student.latenessCount)} مورد</p></div><Badge tone="blue">{fa(student.latenessCount)}</Badge></div>
            <div className="content-row"><div><h3>بی‌نظمی</h3><p>گزارش‌های رفتاری ثبت‌شده: {fa(student.disorderCount)} مورد</p></div><Badge tone="orange">{fa(student.disorderCount)}</Badge></div>
          </div>
        </Surface>
      </div>

      <Surface>
        <div className="section-title">
          <h2>تاریخچه تغییرات جنم</h2>
          <Badge tone="blue">{fa(transactions.length)} رکورد</Badge>
        </div>
        {transactions.length ? (
          <table className="rich-table">
            <thead>
              <tr>
                <th>نوع</th>
                <th>دلیل</th>
                <th>مسئول ثبت</th>
                <th>تاریخ و ساعت</th>
                <th>مقدار</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx) => (
                <tr key={tx.id}>
                  <td><Badge tone={tx.amount < 0 ? "danger" : tx.amount > 0 ? "green" : "blue"}>{tx.kind}</Badge></td>
                  <td>{tx.reason}</td>
                  <td>{tx.actor}</td>
                  <td>{tx.date} • {tx.time}</td>
                  <td><NumberCell value={tx.amount} positiveAsGold /></td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <EmptyBlock title="تغییری ثبت نشده است" description="از آن‌جا که هر دانش‌آموز با صفر جنم شروع می‌کند، تاریخچه پس از اولین ثبت انضباطی یا تشویقی ساخته می‌شود." />
        )}
      </Surface>
    </div>
  );
}

export function StudentProfilePage() {
  const { studentId } = useParams();
  const { state } = useAppState();
  const student = state.students.find((item) => item.id === studentId);
  if (!student) return <EmptyBlock title="پرونده پیدا نشد" description="شناسه‌ی دانش‌آموز معتبر نیست یا هنوز در نسخه نمایشی ثبت نشده است." />;
  return <StudentProfileBlocks student={student} />;
}

export function BasesPage() {
  const { state } = useAppState();
  return (
    <div className="form-grid">
      <PageIntro title="قرارگاه‌های مدرسه" subtitle="پنج قرارگاه اختصاصی برای حوزه‌های فرهنگی، رسانه‌ای، انضباطی، دانشی و انرژی دانش‌آموزی" />
      <div className="three-col-grid">
        {state.bases.map((base) => (
          <Surface key={base.id}>
            <div className="section-title">
              <h2>{base.title}</h2>
              <Badge tone={base.color === "gold" ? "gold" : base.color === "orange" ? "orange" : base.color === "green" ? "green" : "blue"}>{base.head}</Badge>
            </div>
            <p className="footer-note">{base.summary}</p>
            <div className="content-list" style={{ marginTop: 14 }}>
              <div>
                <strong>اعضا</strong>
                <p className="footer-note">{base.memberIds.map((id) => state.students.find((student) => student.id === id)?.fullName).filter(Boolean).join("، ")}</p>
              </div>
              <div>
                <strong>فعالیت‌ها</strong>
                <p className="footer-note">{base.activities.join(" • ")}</p>
              </div>
              <div>
                <strong>گزارش عملکرد</strong>
                <p className="footer-note">{base.report}</p>
              </div>
              <div>
                <strong>افتخارات</strong>
                <p className="footer-note">{base.honors.join(" • ")}</p>
              </div>
            </div>
          </Surface>
        ))}
      </div>
    </div>
  );
}

export function ExamsPage() {
  const { state } = useAppState();
  return (
    <div className="form-grid">
      <PageIntro title="امتحانات و برنامه آموزشی" subtitle="تقویم شمسی برگزاری آزمون‌ها، وضعیت اجرایی و یادداشت‌های آموزشی" />
      <Surface>
        <table className="rich-table">
          <thead>
            <tr>
              <th>عنوان</th>
              <th>درس / نوع</th>
              <th>پایه و کلاس</th>
              <th>تاریخ</th>
              <th>وضعیت</th>
              <th>یادداشت</th>
            </tr>
          </thead>
          <tbody>
            {state.exams.map((exam) => (
              <tr key={exam.id}>
                <td>{exam.title}</td>
                <td>{exam.subject}</td>
                <td>{exam.classCode}</td>
                <td>{exam.jalaliDate} • {exam.fullDate}</td>
                <td><Badge tone="orange">{exam.status}</Badge></td>
                <td>{exam.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Surface>
    </div>
  );
}

export function AnnouncementsPage() {
  const { state } = useAppState();
  return (
    <div className="form-grid">
      <PageIntro title="اطلاعیه‌های مدرسه" subtitle="اطلاعیه‌های مدیر، معاونت، برنامه‌های فرهنگی و اخبار اجرایی بدون بخش نظرات عمومی" />
      <div className="two-col-grid">
        {state.announcements.map((announcement) => (
          <Surface key={announcement.id}>
            <div className="section-title">
              <h2>{announcement.title}</h2>
              <Badge tone="blue">{announcement.category}</Badge>
            </div>
            <p style={{ lineHeight: 2 }}>{announcement.body}</p>
            <p className="footer-note">{announcement.author} • {announcement.date}</p>
          </Surface>
        ))}
      </div>
    </div>
  );
}

export function HonorsPage() {
  const { state } = useAppState();
  const { schoolRanks } = useComputed();
  const topSchool = state.students.slice().sort((a, b) => b.janam - a.janam).slice(0, 3);

  return (
    <div className="form-grid">
      <PageIntro title="افتخارات و رتبه‌بندی" subtitle="نمایش دانش‌آموزان برتر، مدال‌ها، افتخارات علمی، فرهنگی و قرارگاهی" />
      <div className="three-col-grid">
        {topSchool.map((student, index) => (
          <Surface key={student.id}>
            <div className="section-title">
              <h2>{student.fullName}</h2>
              <RankPill rank={index + 1} />
            </div>
            <p className="footer-note">{classLabel(student.classCode)} • رتبه مدرسه {fa(schoolRanks.get(student.id) ?? 0)}</p>
            <MetricCard label="میزان جنم" value={student.janam} accent={index === 0 ? "gold" : index === 1 ? "blue" : "orange"} helper={rankMedal(index + 1)} />
          </Surface>
        ))}
      </div>
      <Surface>
        <table className="rich-table">
          <thead>
            <tr>
              <th>دانش‌آموز</th>
              <th>عنوان افتخار</th>
              <th>توضیحات</th>
              <th>نوع</th>
              <th>تاریخ</th>
            </tr>
          </thead>
          <tbody>
            {state.honors.map((honor) => {
              const student = state.students.find((item) => item.id === honor.studentId);
              return (
                <tr key={honor.id}>
                  <td>{student?.fullName ?? "—"}</td>
                  <td>{honor.title}</td>
                  <td>{honor.description}</td>
                  <td><Badge tone="gold">{honor.type}</Badge></td>
                  <td>{honor.date}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Surface>
    </div>
  );
}

export function SettingsPage() {
  const { profile, toggleTheme, theme, updateProfileDemo } = useAppState();
  const studentProfile = profile?.role === "student" ? profile : null;
  const tones = ["blue", "indigo", "teal", "sky", "violet", "slate", "amber"];

  return (
    <div className="form-grid">
      <PageIntro title="تنظیمات سامانه" subtitle="شخصی‌سازی پوسته، اطلاعات نمایشی حساب و کنترل تجربه‌ی کاربری نسخه استاتیک" />
      <div className="two-col-grid">
        <Surface>
          <div className="section-title"><h2>پوسته و نمایش</h2></div>
          <p className="footer-note">رنگ‌های اصلی سامانه: پس‌زمینه #050A14، کارت‌ها #0F1A30، آبی #1A3F87، نارنجی #F08A5D و طلایی #F5B400</p>
          <div className="actions-row" style={{ marginTop: 16 }}>
            <button className="primary-btn" onClick={toggleTheme}>{theme === "dark" ? "تغییر به حالت روشن" : "تغییر به حالت تاریک"}</button>
          </div>
        </Surface>
        <Surface>
          <div className="section-title"><h2>حساب نمایشی</h2></div>
          <p className="footer-note">این نسخه برای GitHub Pages ساخته شده و داده‌ها فقط در مرورگر شما ذخیره می‌شوند.</p>
          {studentProfile ? (
            <div className="form-grid" style={{ marginTop: 14 }}>
              <label className="form-field">
                <span>رنگ آواتار نمایشی</span>
                <select className="text-field" value={studentProfile.avatarTone} onChange={(event) => updateProfileDemo({ avatarTone: event.target.value })}>
                  {tones.map((tone) => (
                    <option key={tone} value={tone}>{tone}</option>
                  ))}
                </select>
              </label>
            </div>
          ) : (
            <EmptyBlock title="تنظیمات ویژه دانش‌آموز" description="برخی گزینه‌های نمایشی فقط در حساب دانش‌آموزی فعال می‌شوند." />
          )}
        </Surface>
      </div>
    </div>
  );
}

export function AdminPage() {
  const { state, profile, approveRegistration, rejectRegistration, addTransaction, addAnnouncement, addHonor, addExam } = useAppState();
  const { approvedStudents, byClass } = useComputed();
  const [tab, setTab] = useState<"students" | "janam" | "content" | "reports">("students");
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [janamForm, setJanamForm] = useState({ kind: "manualPlus", amount: 1, reason: "تشویق آموزشی" });
  const [announcementForm, setAnnouncementForm] = useState({ title: "", body: "", category: "مدیریت" });
  const [honorForm, setHonorForm] = useState({ studentId: approvedStudents[0]?.id ?? "", title: "", description: "", date: new Date().toLocaleDateString("fa-IR"), type: "علمی" });
  const [examForm, setExamForm] = useState({ title: "", subject: "", classCode: "همه پایه‌ها", jalaliDate: "", fullDate: "", status: "برنامه‌ریزی شده", note: "" });

  if (!profile || (profile.role !== "admin" && profile.role !== "staff")) {
    return <EmptyBlock title="دسترسی محدود" description="پنل مدیریت فقط برای مدیر اصلی و کادر مدرسه در نسخه نمایشی فعال است." />;
  }

  return (
    <div className="form-grid">
      <PageIntro title="پنل مدیریت مدرسه" subtitle="مدیریت دانش‌آموزان، جنم، اطلاعیه‌ها، افتخارات، امتحانات و گزارش عملکرد سامانه" />

      <div className="tab-group">
        <button className={tab === "students" ? "active" : ""} onClick={() => setTab("students")}>دانش‌آموزان و ثبت‌نام</button>
        <button className={tab === "janam" ? "active" : ""} onClick={() => setTab("janam")}>مدیریت جنم</button>
        <button className={tab === "content" ? "active" : ""} onClick={() => setTab("content")}>اطلاعیه‌ها، افتخارات و امتحانات</button>
        <button className={tab === "reports" ? "active" : ""} onClick={() => setTab("reports")}>گزارش‌ها</button>
      </div>

      {tab === "students" ? (
        <div className="form-grid">
          <Surface>
            <div className="section-title">
              <h2>درخواست‌های ثبت‌نام در انتظار تأیید</h2>
              <Badge tone="orange">{fa(state.pendingRegistrations.length)} درخواست</Badge>
            </div>
            {state.pendingRegistrations.length ? (
              <table className="rich-table">
                <thead>
                  <tr>
                    <th>نام</th>
                    <th>کلاس</th>
                    <th>نام کاربری</th>
                    <th>زمان ثبت</th>
                    <th>اقدام</th>
                  </tr>
                </thead>
                <tbody>
                  {state.pendingRegistrations.map((registration) => (
                    <tr key={registration.id}>
                      <td>{registration.fullName}</td>
                      <td>{registration.classCode}</td>
                      <td dir="ltr">{registration.username}</td>
                      <td>{registration.submittedAt}</td>
                      <td>
                        <div className="actions-row">
                          <button className="primary-btn" onClick={() => approveRegistration(registration.id)}>تأیید</button>
                          <button className="danger-btn" onClick={() => rejectRegistration(registration.id)}>رد</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <EmptyBlock title="درخواستی ثبت نشده" description="وقتی دانش‌آموزی از صفحه ورود ثبت‌نام نمایشی انجام دهد، در این بخش نمایش داده می‌شود." />
            )}
          </Surface>

          <Surface>
            <div className="section-title">
              <h2>فهرست دانش‌آموزان فعال</h2>
              <Badge tone="blue">{fa(approvedStudents.length)} نفر</Badge>
            </div>
            <table className="rich-table">
              <thead>
                <tr>
                  <th>دانش‌آموز</th>
                  <th>کلاس</th>
                  <th>شماره دانش‌آموزی</th>
                  <th>جنم</th>
                  <th>سوابق انضباطی</th>
                </tr>
              </thead>
              <tbody>
                {approvedStudents.map((student) => (
                  <tr key={student.id}>
                    <td>{student.fullName}</td>
                    <td>{student.classCode}</td>
                    <td>{student.studentNumber}</td>
                    <td><NumberCell value={student.janam} positiveAsGold /></td>
                    <td>{`غیبت: ${fa(student.absences)} • تأخیر: ${fa(student.latenessCount)} • بی‌نظمی: ${fa(student.disorderCount)}`}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Surface>
        </div>
      ) : null}

      {tab === "janam" ? (
        <div className="form-grid">
          <Surface>
            <div className="section-title">
              <h2>ثبت جنم مثبت و منفی</h2>
              <Badge tone="gold">واحد امتیاز: جنم</Badge>
            </div>
            <div className="form-grid two">
              <label className="form-field">
                <span>دانش‌آموزان هدف</span>
                <select
                  className="text-field"
                  multiple
                  value={selectedStudentIds}
                  onChange={(event) => setSelectedStudentIds(Array.from(event.target.selectedOptions).map((item) => item.value))}
                  style={{ minHeight: 180 }}
                >
                  {approvedStudents.map((student) => (
                    <option key={student.id} value={student.id}>{student.fullName} — {student.classCode}</option>
                  ))}
                </select>
              </label>
              <div className="form-grid">
                <label className="form-field">
                  <span>نوع ثبت</span>
                  <select className="text-field" value={janamForm.kind} onChange={(event) => setJanamForm((current) => ({ ...current, kind: event.target.value, reason: event.target.value === "absence" ? "غیبت غیرموجه" : event.target.value === "disorder" ? "بی‌نظمی" : event.target.value === "lateness" ? "ثبت تأخیر" : current.reason }))}>
                    <option value="manualPlus">جنم مثبت</option>
                    <option value="manualMinus">جنم منفی</option>
                    <option value="absence">غیبت غیرموجه (۱۰-)</option>
                    <option value="lateness">ثبت تأخیر (هر سه مورد، ۵-)</option>
                    <option value="disorder">بی‌نظمی (۲-)</option>
                  </select>
                </label>
                <label className="form-field">
                  <span>مقدار (برای ثبت دستی)</span>
                  <input className="text-field" type="number" value={janamForm.amount} onChange={(event) => setJanamForm((current) => ({ ...current, amount: Number(event.target.value) }))} />
                </label>
                <label className="form-field">
                  <span>دلیل ثبت</span>
                  <input className="text-field" value={janamForm.reason} onChange={(event) => setJanamForm((current) => ({ ...current, reason: event.target.value }))} />
                </label>
                <button
                  className="primary-btn"
                  onClick={() =>
                    addTransaction({
                      studentIds: selectedStudentIds,
                      kind: janamForm.kind as never,
                      amount: janamForm.amount,
                      reason: janamForm.reason,
                      actor: profile.fullName,
                    })
                  }
                >
                  ثبت در تاریخچه جنم
                </button>
              </div>
            </div>
          </Surface>
        </div>
      ) : null}

      {tab === "content" ? (
        <div className="form-grid three-col-grid">
          <Surface>
            <div className="section-title"><h2>اطلاعیه جدید</h2></div>
            <div className="form-grid">
              <label className="form-field"><span>عنوان</span><input className="text-field" value={announcementForm.title} onChange={(event) => setAnnouncementForm((current) => ({ ...current, title: event.target.value }))} /></label>
              <label className="form-field"><span>دسته</span><select className="text-field" value={announcementForm.category} onChange={(event) => setAnnouncementForm((current) => ({ ...current, category: event.target.value }))}><option>مدیریت</option><option>آموزشی</option><option>فرهنگی</option><option>امتحانات</option></select></label>
              <label className="form-field"><span>متن</span><textarea className="text-field" value={announcementForm.body} onChange={(event) => setAnnouncementForm((current) => ({ ...current, body: event.target.value }))} /></label>
              <button className="secondary-btn" onClick={() => addAnnouncement(announcementForm)}>انتشار اطلاعیه</button>
            </div>
          </Surface>

          <Surface>
            <div className="section-title"><h2>ثبت افتخار</h2></div>
            <div className="form-grid">
              <label className="form-field"><span>دانش‌آموز</span><select className="text-field" value={honorForm.studentId} onChange={(event) => setHonorForm((current) => ({ ...current, studentId: event.target.value }))}>{approvedStudents.map((student) => <option key={student.id} value={student.id}>{student.fullName}</option>)}</select></label>
              <label className="form-field"><span>عنوان افتخار</span><input className="text-field" value={honorForm.title} onChange={(event) => setHonorForm((current) => ({ ...current, title: event.target.value }))} /></label>
              <label className="form-field"><span>نوع</span><select className="text-field" value={honorForm.type} onChange={(event) => setHonorForm((current) => ({ ...current, type: event.target.value }))}><option>علمی</option><option>فرهنگی</option><option>قرارگاهی</option></select></label>
              <label className="form-field"><span>تاریخ</span><input className="text-field" value={honorForm.date} onChange={(event) => setHonorForm((current) => ({ ...current, date: event.target.value }))} /></label>
              <label className="form-field"><span>توضیحات</span><textarea className="text-field" value={honorForm.description} onChange={(event) => setHonorForm((current) => ({ ...current, description: event.target.value }))} /></label>
              <button className="secondary-btn" onClick={() => addHonor(honorForm)}>ثبت افتخار</button>
            </div>
          </Surface>

          <Surface>
            <div className="section-title"><h2>افزودن امتحان</h2></div>
            <div className="form-grid">
              <label className="form-field"><span>عنوان</span><input className="text-field" value={examForm.title} onChange={(event) => setExamForm((current) => ({ ...current, title: event.target.value }))} /></label>
              <label className="form-field"><span>موضوع / درس</span><input className="text-field" value={examForm.subject} onChange={(event) => setExamForm((current) => ({ ...current, subject: event.target.value }))} /></label>
              <label className="form-field"><span>پایه و کلاس</span><input className="text-field" value={examForm.classCode} onChange={(event) => setExamForm((current) => ({ ...current, classCode: event.target.value }))} /></label>
              <label className="form-field"><span>تاریخ کوتاه</span><input className="text-field" value={examForm.jalaliDate} onChange={(event) => setExamForm((current) => ({ ...current, jalaliDate: event.target.value }))} placeholder="مثلاً ۲۰ آبان" /></label>
              <label className="form-field"><span>تاریخ کامل</span><input className="text-field" value={examForm.fullDate} onChange={(event) => setExamForm((current) => ({ ...current, fullDate: event.target.value }))} placeholder="۱۴۰۵/۰۸/۲۰" /></label>
              <label className="form-field"><span>یادداشت</span><textarea className="text-field" value={examForm.note} onChange={(event) => setExamForm((current) => ({ ...current, note: event.target.value }))} /></label>
              <button className="secondary-btn" onClick={() => addExam(examForm)}>افزودن امتحان</button>
            </div>
          </Surface>
        </div>
      ) : null}

      {tab === "reports" ? (
        <div className="form-grid">
          <div className="metrics-grid">
            <MetricCard label="دانش‌آموزان فعال" value={approvedStudents.length} accent="blue" helper="پس از تأیید مدیر" />
            <MetricCard label="کلاس‌ها" value={byClass.length} accent="green" helper="متوسطه اول" />
            <MetricCard label="تراکنش‌های جنم" value={state.transactions.length} accent="orange" helper="ثبت‌های انضباطی و تشویقی" />
            <MetricCard label="اطلاعیه‌ها" value={state.announcements.length} accent="gold" helper="اخبار مدرسه و برنامه‌ها" />
          </div>
          <Surface>
            <div className="section-title"><h2>گزارش کلاس‌ها</h2></div>
            <table className="rich-table">
              <thead>
                <tr>
                  <th>کلاس</th>
                  <th>تعداد دانش‌آموز</th>
                  <th>میانگین جنم</th>
                  <th>دانش‌آموز برتر</th>
                </tr>
              </thead>
              <tbody>
                {byClass.map((schoolClass) => (
                  <tr key={schoolClass.id}>
                    <td>{schoolClass.title}</td>
                    <td>{fa(schoolClass.count)}</td>
                    <td>{faNumber(schoolClass.avgJanam)}</td>
                    <td>{schoolClass.topStudent?.fullName ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Surface>
        </div>
      ) : null}
    </div>
  );
}
