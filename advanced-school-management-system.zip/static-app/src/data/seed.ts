import { baseSeeds, demoAccounts, seedAnnouncements, seedExams, seedHonors } from "./content";
import { schoolClasses } from "./classes";
import { studentSeeds } from "./students";

export type TransactionKind = "positive" | "negative" | "absence" | "lateness" | "lateness-penalty" | "disorder";

export type StudentRecord = {
  id: string;
  studentNumber: string;
  username: string;
  fullName: string;
  classCode: string;
  title?: string;
  role: "admin" | "staff" | "student";
  avatarTone: string;
  janam: number;
  approved: boolean;
  blocked: boolean;
  absences: number;
  latenessCount: number;
  disorderCount: number;
  baseId?: string;
  achievements: string[];
};

export type TransactionRecord = {
  id: string;
  studentId: string;
  amount: number;
  kind: TransactionKind;
  reason: string;
  actor: string;
  date: string;
  time: string;
};

export type DemoState = {
  students: StudentRecord[];
  classes: typeof schoolClasses;
  bases: ((typeof baseSeeds)[number] & { memberIds: string[] })[];
  announcements: typeof seedAnnouncements;
  exams: typeof seedExams;
  honors: typeof seedHonors;
  transactions: TransactionRecord[];
  recentActivities: { id: string; title: string; detail: string; date: string }[];
  pendingRegistrations: {
    id: string;
    fullName: string;
    classCode: string;
    username: string;
    submittedAt: string;
  }[];
  demoAccounts: typeof demoAccounts;
};

export const createInitialState = (): DemoState => {
  const students: StudentRecord[] = studentSeeds.map((student) => ({
    ...student,
    role: student.role ?? "student",
    avatarTone: student.avatarTone ?? "blue",
    janam: 0,
    approved: true,
    blocked: false,
    absences: 0,
    latenessCount: 0,
    disorderCount: 0,
    baseId: student.base ? `base-${student.base === "فرهنگی" ? "farhangi" : student.base === "مدیا" ? "media" : student.base === "نظم" ? "nezm" : student.base === "دانایی" ? "danayi" : "energy"}` : undefined,
    achievements: seedHonors.filter((item) => item.studentId === student.id).map((item) => item.title),
  }));

  const baseMap: Record<string, string[]> = {
    "base-farhangi": students.filter((item) => ["بنیامین ترابی", "پرهام توفیقی", "محمدعرفان ثابت"].includes(item.fullName)).map((item) => item.id),
    "base-media": students.filter((item) => ["محمدسبحان اوحدی", "امیرعلی ربانی", "محمدطاها سلطانی"].includes(item.fullName)).map((item) => item.id),
    "base-nezm": students.filter((item) => ["مجتبی شکیبا", "علی شهبازی", "رضا کاوسی"].includes(item.fullName)).map((item) => item.id),
    "base-danayi": students.filter((item) => ["عرشیا ذوالعدل", "ایلیا ذوالعدل", "محمدپارسا جعفری"].includes(item.fullName)).map((item) => item.id),
    "base-energy": students.filter((item) => ["طاها حسینقلی", "محمدمهدی دادگر", "سیدمهدی حسینی"].includes(item.fullName)).map((item) => item.id),
  };

  return {
    students,
    classes: schoolClasses,
    bases: baseSeeds.map((base) => ({ ...base, memberIds: baseMap[base.id] ?? [] })),
    announcements: seedAnnouncements,
    exams: seedExams,
    honors: seedHonors,
    transactions: [],
    recentActivities: [
      { id: "ra-1", title: "ثبت نسخه نمایشی سامانه", detail: "داشبورد مدرسه برای استفاده مدیران و دانش‌آموزان آماده شد.", date: "۱۴۰۵/۰۸/۰۱" },
      { id: "ra-2", title: "به‌روزرسانی برنامه امتحانات", detail: "آزمون مبتکران در تقویم آموزشی ثبت شد.", date: "۱۴۰۵/۰۸/۱۰" },
      { id: "ra-3", title: "بازنگری گزارش قرارگاه‌ها", detail: "اطلاعات عملکرد هفتگی پنج قرارگاه مرور شد.", date: "۱۴۰۵/۰۸/۱۲" },
    ],
    pendingRegistrations: [],
    demoAccounts,
  };
};
