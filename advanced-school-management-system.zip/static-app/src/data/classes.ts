export type ClassCode = "7/1" | "8/1" | "8/2" | "9/1" | "9/2";

export type SchoolClass = {
  id: string;
  title: string;
  code: ClassCode;
  grade: 7 | 8 | 9;
  room: string;
  advisor: string;
  description: string;
};

export const schoolClasses: SchoolClass[] = [
  {
    id: "c71",
    title: "پایه هفتم، کلاس اول",
    code: "7/1",
    grade: 7,
    room: "طبقه دوم، کلاس ۷/۱",
    advisor: "دفتر آموزش متوسطه اول",
    description: "کلاس آغازین متوسطه اول با تمرکز بر نظم آموزشی، مهارت‌های پایه و رشد فردی.",
  },
  {
    id: "c81",
    title: "پایه هشتم، کلاس اول",
    code: "8/1",
    grade: 8,
    room: "طبقه دوم، کلاس ۸/۱",
    advisor: "دفتر آموزش متوسطه اول",
    description: "کلاس هشتم اول با فضای رقابتی مناسب برای فعالیت‌های علمی و فرهنگی.",
  },
  {
    id: "c82",
    title: "پایه هشتم، کلاس دوم",
    code: "8/2",
    grade: 8,
    room: "طبقه دوم، کلاس ۸/۲",
    advisor: "دفتر آموزش متوسطه اول",
    description: "کلاس هشتم دوم با تأکید بر فعالیت گروهی، رشد آموزشی و مشارکت قرارگاهی.",
  },
  {
    id: "c91",
    title: "پایه نهم، کلاس اول",
    code: "9/1",
    grade: 9,
    room: "طبقه سوم، کلاس ۹/۱",
    advisor: "دفتر آموزش متوسطه اول",
    description: "کلاس نهم اول، آماده‌سازی برای مسیر انتخاب رشته و نقش‌آفرینی مؤثر در مدرسه.",
  },
  {
    id: "c92",
    title: "پایه نهم، کلاس دوم",
    code: "9/2",
    grade: 9,
    room: "طبقه سوم، کلاس ۹/۲",
    advisor: "دفتر آموزش متوسطه اول",
    description: "کلاس نهم دوم با هویت فعال در فعالیت‌های فرهنگی، رسانه‌ای و انضباطی مدرسه.",
  },
];
